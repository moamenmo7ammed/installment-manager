=== Installment Manager ===
Contributors: FWTeam
Donate link: https://future-way.online
Tags: installment, payment, ecommerce, finance, payment plans
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 2.1.0
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A comprehensive WordPress plugin for managing installment plans and payment schedules.

== Description ==

Installment Manager is a powerful WordPress plugin designed to help businesses manage installment payment plans for their products and services. It provides a complete solution for creating, tracking, and managing installment plans with a user-friendly interface for both administrators and customers.

= Key Features =

* **Product Management**: Create and manage products with customizable pricing options.
* **Installment Plan Creation**: Set up flexible installment plans with customizable down payments and installment schedules.
* **Customer Portal**: Frontend interface for customers to view and manage their installment plans.
* **Payment Tracking**: Track payments, due dates, and payment statuses.
* **Payment Proof Upload**: Allow customers to upload payment proof images.
* **Multi-Currency Support**: Configure and use multiple currencies.
* **Payment Method Management**: Add and manage different payment methods.
* **Responsive Design**: Modern, mobile-friendly interface using Bootstrap 5.
* **RTL Support**: Full support for right-to-left languages, including Arabic.
* **Translation Ready**: Fully translatable with .pot file included.

= Use Cases =

* **Retail Businesses**: Offer installment payment options for high-value products.
* **Educational Institutions**: Manage tuition payment plans.
* **Service Providers**: Set up payment schedules for long-term services.
* **Membership Sites**: Offer installment options for premium memberships.
* **Real Estate**: Manage property payment plans and schedules.

= Shortcodes =

The plugin provides a shortcode to display the customer portal on any page or post:

`[installment_customer_portal]`

This shortcode will display a dashboard where logged-in users can view their installment plans, track payment progress, and upload payment proofs.

== Installation ==

1. Upload the `installment-manager` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'Installment Manager' in your WordPress admin menu to configure the plugin
4. Add the `[installment_customer_portal]` shortcode to any page where you want to display the customer portal

== Frequently Asked Questions ==

= Does this plugin process payments automatically? =

No, this plugin is designed for tracking and managing installment plans. It does not process payments automatically but allows customers to upload proof of payment which administrators can then verify.

= Can I customize the payment methods? =

Yes, you can add, edit, and remove payment methods from the plugin settings page.

= Does the plugin support multiple currencies? =

Yes, you can configure and use multiple currencies. Each installment plan can use a specific currency.

= Is the plugin compatible with WooCommerce? =

The plugin works independently of WooCommerce. It has its own product and plan management system.

= Can customers create their own installment plans? =

No, only administrators can create installment plans. Customers can only view and manage plans assigned to them.

= Does the plugin support RTL languages? =

Yes, the plugin fully supports right-to-left languages, including Arabic, with dedicated RTL stylesheets.

== Screenshots ==

1. Admin Dashboard - Overview of installment plans and statistics
2. Product Management - Create and manage products
3. Installment Plan Creation - Set up flexible payment plans
4. Customer Portal - Frontend interface for customers
5. Payment Proof Upload - Interface for uploading payment proofs
6. Settings Page - Configure currencies and payment methods

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release of the Installment Manager plugin.

== Additional Information ==

= Requirements =

* WordPress 5.0 or higher
* PHP 7.2 or higher
* MySQL 5.6 or higher

= Privacy Considerations =

This plugin stores customer information related to installment plans, including:
* Customer name and contact information
* Payment history and statuses
* Payment proof images uploaded by customers

All data is stored in your WordPress database and is not shared with any third parties.

= Security Features =

* File uploads are restricted to images only (jpg, jpeg, png, gif, webp)
* Maximum file size limit of 10MB for uploads
* Users can only view and manage their own installment plans
* Media library access is restricted to user's own uploads

= Support =

For support requests, please visit our [support forum](https://example.com/support) or contact us at support@example.com.

= Documentation =

Comprehensive documentation is available at [https://example.com/docs/installment-manager](https://example.com/docs/installment-manager).

= Credits =

* Bootstrap 5 - [https://getbootstrap.com/](https://getbootstrap.com/)
* Bootstrap Icons - [https://icons.getbootstrap.com/](https://icons.getbootstrap.com/)
* Select2 - [https://select2.org/](https://select2.org/)
* Cairo Font - [https://fonts.google.com/specimen/Cairo](https://fonts.google.com/specimen/Cairo)
