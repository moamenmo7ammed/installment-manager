<?php
/**
 * Admin controller class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Admin controller class.
 */
class Installment_Manager_Admin_Controller {

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Initialize
    }

    /**
     * Register the admin menu.
     *
     * @since    1.0.0
     */
    public function register_admin_menu() {
        // Main menu
        add_menu_page(
            __('Installment Manager', 'installment-manager'),
            __('Installment Manager', 'installment-manager'),
            'manage_installment_plans',
            'installment-manager',
            array($this, 'render_dashboard_page'),
            'dashicons-money-alt',
            30
        );

        // Dashboard submenu
        add_submenu_page(
            'installment-manager',
            __('Dashboard', 'installment-manager'),
            __('Dashboard', 'installment-manager'),
            'manage_installment_plans',
            'installment-manager',
            array($this, 'render_dashboard_page')
        );

        // Products submenu
        add_submenu_page(
            'installment-manager',
            __('Products', 'installment-manager'),
            __('Products', 'installment-manager'),
            'manage_installment_plans',
            'installment-manager-products',
            array($this, 'render_products_page')
        );

        // Plans submenu
        add_submenu_page(
            'installment-manager',
            __('Installment Plans', 'installment-manager'),
            __('Installment Plans', 'installment-manager'),
            'manage_installment_plans',
            'installment-manager-plans',
            array($this, 'render_plans_page')
        );

        // Add/Edit Plan submenu (hidden)
        add_submenu_page(
            null,
            __('Add/Edit Plan', 'installment-manager'),
            __('Add/Edit Plan', 'installment-manager'),
            'manage_installment_plans',
            'installment-manager-edit-plan',
            array($this, 'render_edit_plan_page')
        );

        // Plan Details submenu (hidden)
        add_submenu_page(
            null,
            __('Plan Details', 'installment-manager'),
            __('Plan Details', 'installment-manager'),
            'manage_installment_plans',
            'installment-manager-plan-details',
            array($this, 'render_plan_details_page')
        );

        // Settings submenu
        add_submenu_page(
            'installment-manager',
            __('Settings', 'installment-manager'),
            __('Settings', 'installment-manager'),
            'manage_options',
            'installment-manager-settings',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Enqueue admin assets.
     *
     * @since    1.0.0
     */
    public function enqueue_admin_assets($hook) {
        // Debug info
        error_log('Hook: ' . $hook);
        error_log('Plugin URL: ' . INSTALLMENT_MANAGER_PLUGIN_URL);

        // Only load on plugin pages
        if (strpos($hook, 'installment-manager') === false) {
            error_log('Not loading assets - not on plugin page');
            return;
        }

        // Bootstrap CSS
        wp_enqueue_style(
            'bootstrap',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
            array(),
            '5.3.0'
        );

        // Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css',
            array(),
            '1.10.0'
        );

        // Bootstrap Custom CSS
        wp_enqueue_style(
            'installment-manager-bootstrap-custom',
            INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/css/bootstrap-custom.css',
            array('bootstrap'),
            filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/css/bootstrap-custom.css')
        );

        // Plugin CSS
        wp_enqueue_style(
            'installment-manager-admin',
            INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/css/admin.css',
            array('bootstrap', 'installment-manager-bootstrap-custom'),
            filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/css/admin.css')
        );

        // RTL and Arabic language CSS
        $locale = function_exists('get_locale') ? get_locale() : 'en_US';
        if (strpos($locale, 'ar') === 0) {
            wp_enqueue_style(
                'installment-manager-rtl',
                INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/css/rtl.css',
                array('installment-manager-admin'),
                filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/css/rtl.css')
            );
        }

        // Fallback: Add CSS directly in case enqueue fails
        add_action('admin_head', function() {
            echo '<style>
            body.wp-admin .wrap {
                max-width: 100% !important;
                width: 100% !important;
                padding: 0 20px !important;
            }

            body.wp-admin .wpbody-content {
                max-width: 100% !important;
                width: 100% !important;
                padding: 0 20px !important;
                box-sizing: border-box;
            }

            .im-container {
                width: 100% !important;
                max-width: 100% !important;
                margin: 0 auto !important;
                padding: 20px !important;
                background-color: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            }

            .im-container .card {
                width: 100% !important;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            }

            .im-container .card-body {
                padding: 20px !important;
                overflow-x: auto !important;
            }

            .im-container .table-responsive {
                width: 100% !important;
                overflow-x: auto !important;
                padding: 10px 0 !important;
            }

            .im-container .table {
                width: 100% !important;
                border-collapse: collapse !important;
            }
            </style>';
        });

        // Select2
        wp_enqueue_style(
            'select2',
            'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css',
            array(),
            '4.1.0-rc.0'
        );

        wp_enqueue_script(
            'select2',
            'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js',
            array('jquery'),
            '4.1.0-rc.0',
            true
        );

        // Bootstrap JS
        wp_enqueue_script(
            'bootstrap-bundle',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
            array('jquery'),
            '5.3.0',
            true
        );

        // Chart.js (only on dashboard)
        if ($hook === 'toplevel_page_installment-manager') {
            wp_enqueue_script(
                'chartjs',
                'https://cdn.jsdelivr.net/npm/chart.js',
                array(),
                '3.9.1',
                true
            );
        }

        // WordPress Media Uploader
        wp_enqueue_media();

        // Main admin JS
        wp_enqueue_script(
            'installment-manager-admin',
            INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'select2', 'bootstrap-bundle'),
            filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/js/admin.js'),
            true
        );

        // Admin tables enhancement JS
        wp_enqueue_script(
            'installment-manager-admin-tables',
            INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/js/admin-tables.js',
            array('jquery'),
            INSTALLMENT_MANAGER_VERSION,
            true
        );

        // Localize script
        wp_localize_script(
            'installment-manager-admin',
            'imAdminData',
            array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => wp_create_nonce('installment_manager_nonce'),
                'strings' => array(
                    'confirmDelete'     => __('Are you sure you want to delete this item? This action cannot be undone.', 'installment-manager'),
                    'confirmCancel'     => __('Are you sure you want to cancel this plan? This action cannot be undone.', 'installment-manager'),
                    'confirmMarkAsPaid' => __('Are you sure you want to mark this installment as paid?', 'installment-manager'),
                    'confirmMarkAsUnpaid' => __('Are you sure you want to mark this installment as unpaid?', 'installment-manager'),
                    'selectCustomer'    => __('Select a customer...', 'installment-manager'),
                    'selectProduct'     => __('Select a product...', 'installment-manager'),
                    'selectPaymentMethod' => __('Select payment method...', 'installment-manager'),
                    'searchingCustomers' => __('Searching customers...', 'installment-manager'),
                    'searchingProducts' => __('Searching products...', 'installment-manager'),
                    'noResults'         => __('No results found', 'installment-manager'),
                    'uploadProof'       => __('Upload Payment Proof', 'installment-manager'),
                    'selectImage'       => __('Select Image', 'installment-manager'),
                ),
                'currency' => $this->get_currency_symbol(),
            )
        );
    }

    /**
     * Get currency symbol.
     *
     * @since    1.0.0
     * @return   string    Currency symbol.
     */
    private function get_currency_symbol() {
        $currency = get_option('im_currency', 'USD');

        $symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'EGP' => 'E£',
            'SAR' => 'SR',
            'AED' => 'د.إ',
        );

        return isset($symbols[$currency]) ? $symbols[$currency] : $currency;
    }

    /**
     * Render the dashboard page.
     *
     * @since    1.0.0
     */
    public function render_dashboard_page() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get statistics
        $stats = $db_manager->get_dashboard_stats();

        // Get recent plans
        $recent_plans = $db_manager->get_plans(array(
            'number'  => 5,
            'orderby' => 'id',
            'order'   => 'DESC',
        ));

        // Include template
        include INSTALLMENT_MANAGER_PLUGIN_DIR . 'admin/views/dashboard.php';
    }

    /**
     * Render the products page.
     *
     * @since    1.0.0
     */
    public function render_products_page() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get products
        $products = $db_manager->get_products();

        // Include template
        include INSTALLMENT_MANAGER_PLUGIN_DIR . 'admin/views/products.php';
    }

    /**
     * Render the plans page.
     *
     * @since    1.0.0
     */
    public function render_plans_page() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get plans
        $plans = $db_manager->get_plans();

        // Include template
        include INSTALLMENT_MANAGER_PLUGIN_DIR . 'admin/views/plans.php';
    }

    /**
     * Render the edit plan page.
     *
     * @since    1.0.0
     */
    public function render_edit_plan_page() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get plan ID from URL
        $plan_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Get plan data if editing
        $plan = $plan_id ? $db_manager->get_plan($plan_id) : null;

        // Get products for dropdown
        $products = $db_manager->get_products();

        // Include template
        include INSTALLMENT_MANAGER_PLUGIN_DIR . 'admin/views/edit-plan.php';
    }

    /**
     * Render the plan details page.
     *
     * @since    1.0.0
     */
    public function render_plan_details_page() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get plan ID from URL
        $plan_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Get plan data
        $plan = $db_manager->get_plan($plan_id);

        if (!$plan) {
            wp_die(__('Plan not found.', 'installment-manager'));
        }

        // Include template
        include INSTALLMENT_MANAGER_PLUGIN_DIR . 'admin/views/plan-details.php';
    }

    /**
     * Render the settings page.
     *
     * @since    1.0.0
     */
    public function render_settings_page() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Include template
        include INSTALLMENT_MANAGER_PLUGIN_DIR . 'admin/views/settings.php';
    }
}




