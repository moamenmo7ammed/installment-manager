<?php
/**
 * AJAX handler class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Include utility class
require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-utility.php';

/**
 * AJAX handler class.
 */
class Installment_Manager_Ajax_Handler {

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Initialize
    }

    /**
     * Get dashboard statistics.
     *
     * @since    1.0.0
     */
    public function get_dashboard_stats() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get statistics
        $stats = $db_manager->get_dashboard_stats();

        // Send response
        wp_send_json_success($stats);
    }

    /**
     * Save product.
     *
     * @since    1.0.0
     */
    public function save_product() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Get product data
        $product_data = array(
            'id'           => isset($_POST['id']) ? intval($_POST['id']) : 0,
            'name'         => isset($_POST['name']) ? Installment_Manager_Utility::sanitize_text_field($_POST['name']) : '',
            'description'  => isset($_POST['description']) ? Installment_Manager_Utility::sanitize_textarea_field($_POST['description']) : '',
            'base_price'   => isset($_POST['base_price']) ? floatval($_POST['base_price']) : 0,
            'profit_option' => isset($_POST['profit_option']) ? Installment_Manager_Utility::sanitize_text_field($_POST['profit_option']) : 'fixed',
            'profit_value' => isset($_POST['profit_value']) ? floatval($_POST['profit_value']) : 0,
        );

        // Validate data
        if (empty($product_data['name'])) {
            wp_send_json_error(array('message' => __('Product name is required.', 'installment-manager')));
        }

        if ($product_data['base_price'] <= 0) {
            wp_send_json_error(array('message' => __('Base price must be greater than zero.', 'installment-manager')));
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Save product
        $product_id = $db_manager->save_product($product_data);

        if (!$product_id) {
            wp_send_json_error(array('message' => __('Failed to save product.', 'installment-manager')));
        }

        // Send response
        wp_send_json_success(array(
            'id'      => $product_id,
            'message' => __('Product saved successfully.', 'installment-manager'),
        ));
    }

    /**
     * Delete product.
     *
     * @since    1.0.0
     */
    public function delete_product() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Get product ID
        $product_id = isset($_POST['id']) ? intval($_POST['id']) : 0;

        if (!$product_id) {
            wp_send_json_error(array('message' => __('Invalid product ID.', 'installment-manager')));
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Delete product
        $result = $db_manager->delete_product($product_id);

        if (!$result) {
            wp_send_json_error(array('message' => __('Failed to delete product.', 'installment-manager')));
        }

        // Send response
        wp_send_json_success(array(
            'message' => __('Product deleted successfully.', 'installment-manager'),
        ));
    }

    /**
     * Save plan.
     *
     * @since    1.0.0
     */
    public function save_plan() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Get plan data
        $plan_data = array(
            'id'               => isset($_POST['id']) ? intval($_POST['id']) : 0,
            'customer_id'      => isset($_POST['customer_id']) ? intval($_POST['customer_id']) : 0,
            'product_id'       => isset($_POST['product_id']) ? intval($_POST['product_id']) : 0,
            'total_amount'     => isset($_POST['total_amount']) ? floatval($_POST['total_amount']) : 0,
            'down_payment'     => isset($_POST['down_payment']) ? floatval($_POST['down_payment']) : 0,
            'installment_count' => isset($_POST['installment_count']) ? intval($_POST['installment_count']) : 1,
            'installment_amount' => isset($_POST['installment_amount']) ? floatval($_POST['installment_amount']) : 0,
            'payment_frequency' => isset($_POST['payment_frequency']) ? Installment_Manager_Utility::sanitize_text_field($_POST['payment_frequency']) : 'monthly',
            'start_date'       => isset($_POST['start_date']) ? Installment_Manager_Utility::sanitize_text_field($_POST['start_date']) : date('Y-m-d'),
            'status'           => isset($_POST['status']) ? Installment_Manager_Utility::sanitize_text_field($_POST['status']) : 'active',
            'notes'            => isset($_POST['notes']) ? Installment_Manager_Utility::sanitize_textarea_field($_POST['notes']) : '',
            'recreate_installments' => isset($_POST['recreate_installments']) ? (bool) $_POST['recreate_installments'] : false,
        );

        // Validate data
        if (empty($plan_data['customer_id'])) {
            wp_send_json_error(array('message' => __('Customer is required.', 'installment-manager')));
        }

        if (empty($plan_data['product_id'])) {
            wp_send_json_error(array('message' => __('Product is required.', 'installment-manager')));
        }

        if ($plan_data['total_amount'] <= 0) {
            wp_send_json_error(array('message' => __('Total amount must be greater than zero.', 'installment-manager')));
        }

        if ($plan_data['installment_count'] < 1) {
            wp_send_json_error(array('message' => __('Number of installments must be at least 1.', 'installment-manager')));
        }

        if ($plan_data['installment_amount'] <= 0) {
            wp_send_json_error(array('message' => __('Installment amount must be greater than zero.', 'installment-manager')));
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Enable error logging
        if (!defined('WP_DEBUG_LOG')) {
            define('WP_DEBUG_LOG', true);
        }

        // Log the plan data for debugging
        error_log('Installment Manager: Saving plan with data: ' . print_r($plan_data, true));

        // Save plan
        $plan_id = $db_manager->save_plan($plan_data);

        if (!$plan_id) {
            error_log('Installment Manager: Failed to save plan');
            wp_send_json_error(array('message' => __('Failed to save plan. Please check the error log for details.', 'installment-manager')));
            return;
        }

        // Send response
        wp_send_json_success(array(
            'id'      => $plan_id,
            'message' => __('Plan saved successfully.', 'installment-manager'),
            'redirect' => admin_url('admin.php?page=installment-manager-plan-details&id=' . $plan_id),
        ));
    }

    /**
     * Delete plan.
     *
     * @since    1.0.0
     */
    public function delete_plan() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Get plan ID
        $plan_id = isset($_POST['id']) ? intval($_POST['id']) : 0;

        if (!$plan_id) {
            wp_send_json_error(array('message' => __('Invalid plan ID.', 'installment-manager')));
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Delete plan
        $result = $db_manager->delete_plan($plan_id);

        if (!$result) {
            wp_send_json_error(array('message' => __('Failed to delete plan.', 'installment-manager')));
        }

        // Send response
        wp_send_json_success(array(
            'message' => __('Plan deleted successfully.', 'installment-manager'),
        ));
    }

    /**
     * Update installment status.
     *
     * @since    1.0.0
     */
    public function update_installment_status() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Get installment data
        $installment_id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $status = isset($_POST['status']) ? Installment_Manager_Utility::sanitize_text_field($_POST['status']) : '';
        $payment_method = isset($_POST['payment_method']) ? Installment_Manager_Utility::sanitize_text_field($_POST['payment_method']) : '';
        $payment_proof_id = isset($_POST['payment_proof_id']) ? intval($_POST['payment_proof_id']) : 0;
        $notes = isset($_POST['notes']) ? Installment_Manager_Utility::sanitize_textarea_field($_POST['notes']) : '';

        if (!$installment_id) {
            wp_send_json_error(array('message' => __('Invalid installment ID.', 'installment-manager')));
        }

        if (empty($status)) {
            wp_send_json_error(array('message' => __('Status is required.', 'installment-manager')));
        }

        // Prepare data
        $data = array(
            'status' => $status,
            'notes'  => $notes,
        );

        // Add payment date if status is 'paid'
        if ($status === 'paid') {
            $data['payment_date'] = date('Y-m-d');
            $data['payment_method'] = $payment_method;
            $data['payment_proof_id'] = $payment_proof_id;
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Update installment
        $result = $db_manager->update_installment($installment_id, $data);

        if (!$result) {
            wp_send_json_error(array('message' => __('Failed to update installment.', 'installment-manager')));
        }

        // Get updated installment
        $installment = $db_manager->get_installment($installment_id);

        // Send response
        wp_send_json_success(array(
            'message'     => __('Installment updated successfully.', 'installment-manager'),
            'installment' => $installment,
        ));
    }

    /**
     * Search customers.
     *
     * @since    1.0.0
     */
    public function search_customers() {
        // Check nonce
        if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Check if we should load all users
        $load_all = isset($_GET['load_all']) && $_GET['load_all'] === 'true';

        // Get search term
        $search = isset($_GET['search']) ? Installment_Manager_Utility::sanitize_text_field($_GET['search']) : '';

        // Set up query args
        $args = array(
            'fields' => array('ID', 'user_login', 'user_email', 'display_name'),
        );

        // If loading all users, don't limit the number
        if ($load_all) {
            $args['number'] = 500; // Set a reasonable limit to avoid performance issues
        } else {
            $args['number'] = 20;

            // Only add search if term is provided and not loading all
            if (!empty($search)) {
                $args['search'] = '*' . $search . '*';
                $args['search_columns'] = array('user_login', 'user_email', 'display_name');
            }
        }

        // Execute query
        $user_query = new WP_User_Query($args);
        $users = $user_query->get_results();

        // Format results
        $results = array();

        foreach ($users as $user) {
            $display_name = !empty($user->display_name) ? $user->display_name : $user->user_login;
            $results[] = array(
                'id'   => $user->ID,
                'text' => sprintf('%s (%s)', $display_name, $user->user_email),
            );
        }

        // Send response
        wp_send_json(array(
            'results' => $results,
            'total' => $user_query->get_total(),
        ));
    }

    /**
     * Search products.
     *
     * @since    1.0.0
     */
    public function search_products() {
        // Check nonce
        if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'installment_manager_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check capabilities
        if (!current_user_can('manage_installment_plans')) {
            wp_send_json_error(array('message' => __('You do not have permission to do this.', 'installment-manager')));
        }

        // Check if we should load all products
        $load_all = isset($_GET['load_all']) && $_GET['load_all'] === 'true';

        // Get search term
        $search = isset($_GET['search']) ? Installment_Manager_Utility::sanitize_text_field($_GET['search']) : '';

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Set up query args
        $args = array('number' => -1); // Get all products

        // Only add search if term is provided and not loading all
        if (!empty($search) && !$load_all) {
            $args['search'] = $search;
        }

        // Get products
        $products = $db_manager->get_products($args);

        // Format results
        $results = array();

        foreach ($products as $product) {
            // Calculate total price
            $total_price = $product['base_price'];
            if ($product['profit_option'] === 'fixed') {
                $total_price += $product['profit_value'];
            } else {
                $total_price += $product['base_price'] * $product['profit_value'] / 100;
            }

            $results[] = array(
                'id'   => $product['id'],
                'text' => sprintf(
                    '%s (%s)',
                    $product['name'],
                    Installment_Manager_Helper_Functions::format_price($product['base_price'])
                ),
                'price' => $total_price, // Use total price instead of base price
                'base_price' => $product['base_price'],
                'profit_option' => $product['profit_option'],
                'profit_value' => $product['profit_value'],
            );
        }

        // Send response
        wp_send_json(array(
            'results' => $results,
            'total' => count($products),
        ));
    }

    /**
     * Get customer plans.
     *
     * @since    1.0.0
     */
    public function get_customer_plans() {
        // Check nonce
        if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'installment_manager_public_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => __('You must be logged in to view plans.', 'installment-manager')));
        }

        // Get current user ID
        $user_id = get_current_user_id();

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get user's plans
        $plans = $db_manager->get_plans(array(
            'customer_id' => $user_id,
            'number'      => -1,
        ));

        // Format results
        $results = array();

        foreach ($plans as $plan) {
            $results[] = array(
                'id'   => $plan['id'],
                'text' => sprintf(
                    '%s - %s',
                    $plan['product_name'],
                    Installment_Manager_Helper_Functions::format_price($plan['total_amount'])
                ),
            );
        }

        // Send response
        wp_send_json(array(
            'results' => $results,
        ));
    }

    /**
     * Get plan details.
     *
     * @since    1.0.0
     */
    public function get_plan_details() {
        // Check nonce
        if (!isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'installment_manager_public_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => __('You must be logged in to view plan details.', 'installment-manager')));
        }

        // Get current user ID
        $user_id = get_current_user_id();

        // Get plan ID
        $plan_id = isset($_GET['plan_id']) ? intval($_GET['plan_id']) : 0;

        if (!$plan_id) {
            wp_send_json_error(array('message' => __('Invalid plan ID.', 'installment-manager')));
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get plan
        $plan = $db_manager->get_plan($plan_id);

        if (!$plan) {
            wp_send_json_error(array('message' => __('Plan not found.', 'installment-manager')));
        }

        // Check if plan belongs to current user
        if ($plan['customer_id'] != $user_id) {
            wp_send_json_error(array('message' => __('You do not have permission to view this plan.', 'installment-manager')));
        }

        // Format installments
        foreach ($plan['installments'] as &$installment) {
            $installment['due_date_formatted'] = date_i18n(get_option('date_format'), strtotime($installment['due_date']));
            $installment['amount_formatted'] = Installment_Manager_Helper_Functions::format_price($installment['amount']);
            $installment['status_label'] = Installment_Manager_Helper_Functions::get_status_label($installment['status'], 'installment');

            if ($installment['payment_date']) {
                $installment['payment_date_formatted'] = date_i18n(get_option('date_format'), strtotime($installment['payment_date']));
            } else {
                $installment['payment_date_formatted'] = '';
            }

            if ($installment['payment_proof_id']) {
                $installment['payment_proof_url'] = wp_get_attachment_url($installment['payment_proof_id']);
            } else {
                $installment['payment_proof_url'] = '';
            }
        }

        // Send response
        wp_send_json_success(array(
            'plan' => $plan,
        ));
    }

    /**
     * Upload payment proof.
     *
     * @since    1.0.0
     */
    public function upload_payment_proof() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'installment_manager_public_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'installment-manager')));
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => __('You must be logged in to upload payment proof.', 'installment-manager')));
        }

        // Get current user ID
        $user_id = get_current_user_id();

        // Get installment data
        $installment_id = isset($_POST['installment_id']) ? intval($_POST['installment_id']) : 0;
        $payment_method = isset($_POST['payment_method']) ? Installment_Manager_Utility::sanitize_text_field($_POST['payment_method']) : '';

        if (!$installment_id) {
            wp_send_json_error(array('message' => __('Invalid installment ID.', 'installment-manager')));
        }

        // Check if file was uploaded
        if (empty($_FILES['payment_proof_file']) || !isset($_FILES['payment_proof_file']['tmp_name']) || empty($_FILES['payment_proof_file']['tmp_name'])) {
            wp_send_json_error(array('message' => __('Payment proof image is required.', 'installment-manager')));
        }

        // Validate file type
        $file = $_FILES['payment_proof_file'];
        $file_type = wp_check_filetype(basename($file['name']), array(
            'jpg|jpeg|jpe' => 'image/jpeg',
            'png'          => 'image/png',
            'gif'          => 'image/gif',
            'webp'         => 'image/webp',
        ));

        if (empty($file_type['type'])) {
            wp_send_json_error(array('message' => __('Invalid file type. Please upload a JPG, PNG, GIF, or WEBP image.', 'installment-manager')));
        }

        // Validate file size (max 10MB)
        if ($file['size'] > 10 * 1024 * 1024) {
            wp_send_json_error(array('message' => __('File size exceeds the maximum limit of 10MB.', 'installment-manager')));
        }

        // Upload the file to WordPress media library
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        // Set up custom upload directory for user files
        add_filter('upload_dir', array($this, 'custom_upload_dir'));

        // Handle the upload
        $payment_proof_id = media_handle_upload('payment_proof_file', 0);

        // Remove the filter
        remove_filter('upload_dir', array($this, 'custom_upload_dir'));

        if (is_wp_error($payment_proof_id)) {
            wp_send_json_error(array('message' => $payment_proof_id->get_error_message()));
        }

        // Set the current user as the attachment author
        wp_update_post(array(
            'ID' => $payment_proof_id,
            'post_author' => $user_id
        ));

        // Add custom meta to identify this as a payment proof
        update_post_meta($payment_proof_id, '_im_payment_proof', 'yes');
        update_post_meta($payment_proof_id, '_im_installment_id', $installment_id);
        update_post_meta($payment_proof_id, '_im_user_id', $user_id);

        if (empty($payment_method)) {
            wp_send_json_error(array('message' => __('Payment method is required.', 'installment-manager')));
        }

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get installment
        $installment = $db_manager->get_installment($installment_id);

        if (!$installment) {
            wp_send_json_error(array('message' => __('Installment not found.', 'installment-manager')));
        }

        // Get plan
        $plan = $db_manager->get_plan($installment['plan_id']);

        if (!$plan) {
            wp_send_json_error(array('message' => __('Plan not found.', 'installment-manager')));
        }

        // Check if plan belongs to current user
        if ($plan['customer_id'] != $user_id) {
            wp_send_json_error(array('message' => __('You do not have permission to update this installment.', 'installment-manager')));
        }

        // Update installment
        $data = array(
            'status'           => 'review',
            'payment_proof_id' => $payment_proof_id,
            'payment_method'   => $payment_method,
        );

        $result = $db_manager->update_installment($installment_id, $data);

        if (!$result) {
            wp_send_json_error(array('message' => __('Failed to update installment.', 'installment-manager')));
        }

        // Get updated installment
        $installment = $db_manager->get_installment($installment_id);

        // Format installment
        $installment['due_date_formatted'] = date_i18n(get_option('date_format'), strtotime($installment['due_date']));
        $installment['amount_formatted'] = Installment_Manager_Helper_Functions::format_price($installment['amount']);
        $installment['status_label'] = Installment_Manager_Helper_Functions::get_status_label($installment['status'], 'installment');

        if ($installment['payment_date']) {
            $installment['payment_date_formatted'] = date_i18n(get_option('date_format'), strtotime($installment['payment_date']));
        } else {
            $installment['payment_date_formatted'] = '';
        }

        if ($installment['payment_proof_id']) {
            $installment['payment_proof_url'] = wp_get_attachment_url($installment['payment_proof_id']);
        } else {
            $installment['payment_proof_url'] = '';
        }

        // Send response
        wp_send_json_success(array(
            'message'     => __('Payment proof uploaded successfully. Your payment is under review.', 'installment-manager'),
            'installment' => $installment,
        ));
    }

    /**
     * Custom upload directory for payment proofs.
     *
     * @since    1.0.0
     * @param    array    $uploads    Upload directory data.
     * @return   array                Modified upload directory data.
     */
    public function custom_upload_dir($uploads) {
        // Create a custom directory structure for payment proofs
        $user_id = get_current_user_id();
        $custom_dir = '/payment-proofs/' . $user_id;

        $uploads['subdir'] = $custom_dir;
        $uploads['path'] = $uploads['basedir'] . $custom_dir;
        $uploads['url'] = $uploads['baseurl'] . $custom_dir;

        // Create the directory if it doesn't exist
        if (!file_exists($uploads['path'])) {
            wp_mkdir_p($uploads['path']);
        }

        return $uploads;
    }

    // Using Installment_Manager_Helper_Functions instead
}
