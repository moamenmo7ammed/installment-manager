<?php
/**
 * Helper functions for the Installment Manager plugin.
 *
 * @link       https://example.com
 * @since      1.0.0
 *
 * @package    Installment_Manager
 * @subpackage Installment_Manager/includes
 */

/**
 * Helper functions for the Installment Manager plugin.
 *
 * This class defines all helper functions used throughout the plugin.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 * @subpackage Installment_Manager/includes
 * @author     Your Name <email@example.com>
 */
class Installment_Manager_Helper_Functions {

    /**
     * Get the currency symbol based on the selected currency.
     *
     * @since    1.0.0
     * @return   string    The currency symbol.
     */
    public static function get_currency_symbol() {
        $currency = get_option('im_currency', 'USD');
        $currencies = get_option('im_currencies', array(
            'USD' => array('name' => __('US Dollar', 'installment-manager'), 'symbol' => '$'),
            'EUR' => array('name' => __('Euro', 'installment-manager'), 'symbol' => '€'),
            'GBP' => array('name' => __('British Pound', 'installment-manager'), 'symbol' => '£'),
            'EGP' => array('name' => __('Egyptian Pound', 'installment-manager'), 'symbol' => 'E£'),
            'SAR' => array('name' => __('Saudi Riyal', 'installment-manager'), 'symbol' => 'SR'),
            'AED' => array('name' => __('UAE Dirham', 'installment-manager'), 'symbol' => 'د.إ'),
        ));

        return isset($currencies[$currency]['symbol']) ? $currencies[$currency]['symbol'] : '$';
    }

    /**
     * Format a price with the selected currency symbol.
     *
     * @since    1.0.0
     * @param    float    $price    The price to format.
     * @return   string             The formatted price.
     */
    public static function format_price($price) {
        $symbol = self::get_currency_symbol();
        return $symbol . number_format($price, 2);
    }

    /**
     * Get the status label for a plan or installment.
     *
     * @since    1.0.0
     * @param    string    $status    The status code.
     * @param    string    $type      The type of status (plan or installment).
     * @return   string               The status label.
     */
    public static function get_status_label($status, $type = 'plan') {
        if ($type === 'plan') {
            $labels = array(
                'active' => __('Active', 'installment-manager'),
                'completed' => __('Completed', 'installment-manager'),
                'cancelled' => __('Cancelled', 'installment-manager'),
            );
        } else {
            $labels = array(
                'unpaid' => __('Unpaid', 'installment-manager'),
                'paid' => __('Paid', 'installment-manager'),
                'review' => __('Under Review', 'installment-manager'),
                'late' => __('Late', 'installment-manager'),
            );
        }

        return isset($labels[$status]) ? $labels[$status] : $status;
    }

    /**
     * Get the payment method label.
     *
     * @since    1.0.0
     * @param    string    $method    The payment method code.
     * @return   string               The payment method label.
     */
    public static function get_payment_method_label($method) {
        $payment_methods = get_option('im_payment_methods', array(
            'cash' => __('Cash', 'installment-manager'),
            'visa' => __('Visa/Mastercard', 'installment-manager'),
            'vodafone' => __('Vodafone Cash', 'installment-manager'),
            'etisalat' => __('Etisalat Cash', 'installment-manager'),
            'instapay' => __('InstaPay', 'installment-manager'),
            'bank' => __('Bank Transfer', 'installment-manager'),
            'other' => __('Other', 'installment-manager'),
        ));

        return isset($payment_methods[$method]) ? $payment_methods[$method] : $method;
    }

    /**
     * Get the CSS class for a status.
     *
     * @since    1.0.0
     * @param    string    $status    The status code.
     * @param    string    $type      The type of status (plan or installment).
     * @return   string               The CSS class.
     */
    public static function get_status_class($status, $type = 'plan') {
        if ($type === 'plan') {
            $classes = array(
                'active' => 'primary',
                'completed' => 'success',
                'cancelled' => 'danger',
            );
        } else {
            $classes = array(
                'unpaid' => 'warning',
                'paid' => 'success',
                'review' => 'info',
                'late' => 'danger',
            );
        }

        return isset($classes[$status]) ? $classes[$status] : 'secondary';
    }
}
