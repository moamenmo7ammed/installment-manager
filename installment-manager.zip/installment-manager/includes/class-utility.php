<?php
/**
 * Utility functions for the Installment Manager plugin.
 *
 * @link       https://example.com
 * @since      1.0.0
 *
 * @package    Installment_Manager
 * @subpackage Installment_Manager/includes
 */

/**
 * Utility functions for the Installment Manager plugin.
 *
 * This class defines utility functions used throughout the plugin.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 * @subpackage Installment_Manager/includes
 * @author     Your Name <email@example.com>
 */
class Installment_Manager_Utility {

    /**
     * Safely handle potentially null values for string operations.
     *
     * @since    1.0.0
     * @param    mixed     $value    The value to check.
     * @return   string              The value as a string, or empty string if null.
     */
    public static function safe_string($value) {
        return $value === null ? '' : (string) $value;
    }

    /**
     * Safely get POST value.
     *
     * @since    1.0.0
     * @param    string    $key       The POST key.
     * @param    mixed     $default   Default value if key doesn't exist.
     * @return   mixed                The POST value or default.
     */
    public static function get_post_value($key, $default = '') {
        return $_POST[$key] ?? $default;
    }

    /**
     * Safely sanitize text field, handling null values.
     *
     * @since    1.0.0
     * @param    mixed     $value    The value to sanitize.
     * @return   string              Sanitized value.
     */
    public static function sanitize_text_field($value) {
        $safe_value = self::safe_string($value);
        return function_exists('sanitize_text_field') ? sanitize_text_field($safe_value) : trim(strip_tags($safe_value));
    }

    /**
     * Safely sanitize textarea field, handling null values.
     *
     * @since    1.0.0
     * @param    mixed     $value    The value to sanitize.
     * @return   string              Sanitized value.
     */
    public static function sanitize_textarea_field($value) {
        $safe_value = self::safe_string($value);
        return function_exists('sanitize_textarea_field') ? sanitize_textarea_field($safe_value) : trim(strip_tags($safe_value));
    }

    /**
     * Safely strip tags, handling null values.
     * This is used to fix the deprecation warning in admin-header.php.
     *
     * @since    1.0.0
     * @param    mixed     $value    The value to strip tags from.
     * @return   string              Value with tags stripped.
     */
    public static function safe_strip_tags($value) {
        return strip_tags(self::safe_string($value));
    }
}
