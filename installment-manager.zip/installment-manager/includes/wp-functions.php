<?php
/**
 * WordPress functions for IDE compatibility and fallbacks.
 *
 * This file provides fallback implementations of WordPress functions
 * when the plugin is not running in a WordPress environment.
 *
 * IMPORTANT: This file should only be included when developing outside of WordPress
 * or when specific functions are needed for IDE compatibility.
 *
 * In a normal WordPress environment, these functions should not be loaded
 * as they would conflict with WordPress core functions.
 */

// Only define these functions if we're not in a WordPress environment
// This prevents function redeclaration errors
if (!defined('WPINC')) {

if (!function_exists('esc_html')) {
    /**
     * Escapes HTML for output.
     *
     * @param string $text Text to escape.
     * @return string Escaped text.
     */
    function esc_html($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('esc_html__')) {
    /**
     * Escapes HTML for output and translates text.
     *
     * @param string $text Text to translate and escape.
     * @param string $domain Text domain.
     * @return string Translated and escaped text.
     */
    function esc_html__($text, $domain = 'default') {
        return esc_html($text);
    }
}

if (!function_exists('esc_attr')) {
    /**
     * Escapes HTML attributes.
     *
     * @param string $text Text to escape.
     * @return string Escaped text.
     */
    function esc_attr($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('esc_js')) {
    /**
     * Escapes text for JavaScript.
     *
     * @param string $text Text to escape.
     * @return string Escaped text.
     */
    function esc_js($text) {
        return addslashes($text);
    }
}

if (!function_exists('__')) {
    /**
     * Translates text.
     *
     * @param string $text Text to translate.
     * @param string $domain Text domain.
     * @return string Translated text.
     */
    function __($text, $domain = 'default') {
        return $text;
    }
}

if (!function_exists('get_option')) {
    /**
     * Gets an option value.
     *
     * @param string $option Option name.
     * @param mixed $default Default value.
     * @return mixed Option value.
     */
    function get_option($option, $default = false) {
        return $default;
    }
}

if (!function_exists('wp_create_nonce')) {
    /**
     * Creates a cryptographic token.
     *
     * @param string $action Action name.
     * @return string Token.
     */
    function wp_create_nonce($action = -1) {
        return 'nonce';
    }
}

if (!function_exists('get_current_user_id')) {
    /**
     * Gets the current user ID.
     *
     * @return int User ID.
     */
    function get_current_user_id() {
        return 1;
    }
}

if (!function_exists('is_user_logged_in')) {
    /**
     * Checks if the current user is logged in.
     *
     * @return bool True if user is logged in, false otherwise.
     */
    function is_user_logged_in() {
        return true;
    }
}

if (!function_exists('admin_url')) {
    /**
     * Gets the URL to the admin area.
     *
     * @param string $path Path relative to the admin URL.
     * @return string Admin URL.
     */
    function admin_url($path = '') {
        return '/wp-admin/' . $path;
    }
}

if (!function_exists('wp_enqueue_style')) {
    /**
     * Enqueues a CSS stylesheet.
     *
     * @param string $handle Name of the stylesheet.
     * @param string $src URL to the stylesheet.
     * @param array $deps Array of handles of stylesheets that this stylesheet depends on.
     * @param string|bool|null $ver Stylesheet version number.
     * @param string $media Media for which this stylesheet has been defined.
     */
    function wp_enqueue_style($handle, $src = '', $deps = array(), $ver = false, $media = 'all') {
        // Do nothing
    }
}

if (!function_exists('wp_enqueue_script')) {
    /**
     * Enqueues a script.
     *
     * @param string $handle Name of the script.
     * @param string $src URL to the script.
     * @param array $deps Array of handles of scripts that this script depends on.
     * @param string|bool|null $ver Script version number.
     * @param bool $in_footer Whether to enqueue the script before </body> instead of in the <head>.
     */
    function wp_enqueue_script($handle, $src = '', $deps = array(), $ver = false, $in_footer = false) {
        // Do nothing
    }
}

if (!function_exists('wp_localize_script')) {
    /**
     * Localizes a script.
     *
     * @param string $handle Script handle the data will be attached to.
     * @param string $object_name Name for the JavaScript object.
     * @param array $l10n Array of data to localize.
     * @return bool True if the script was successfully localized, false otherwise.
     */
    function wp_localize_script($handle, $object_name, $l10n) {
        return true;
    }
}

if (!function_exists('wp_enqueue_media')) {
    /**
     * Enqueues all scripts, styles, settings, and templates necessary to use all media JS APIs.
     */
    function wp_enqueue_media() {
        // Do nothing
    }
}

if (!function_exists('add_shortcode')) {
    /**
     * Registers a shortcode.
     *
     * @param string $tag Shortcode tag.
     * @param callable $callback Shortcode callback.
     */
    function add_shortcode($tag, $callback) {
        // Do nothing
    }
}

if (!function_exists('shortcode_atts')) {
    /**
     * Combines user attributes with known attributes and fills in defaults when needed.
     *
     * @param array $pairs Entire list of supported attributes and their defaults.
     * @param array $atts User defined attributes.
     * @param string $shortcode Shortcode name.
     * @return array Combined and filtered attribute list.
     */
    function shortcode_atts($pairs, $atts, $shortcode = '') {
        return $pairs;
    }
}

if (!function_exists('has_shortcode')) {
    /**
     * Checks if a shortcode exists in the content.
     *
     * @param string $content Content to search for shortcodes.
     * @param string $tag Shortcode tag.
     * @return bool True if the shortcode exists, false otherwise.
     */
    function has_shortcode($content, $tag) {
        return false;
    }
}

if (!function_exists('add_action')) {
    /**
     * Hooks a function on to a specific action.
     *
     * @param string $tag The name of the action to which the $function_to_add is hooked.
     * @param callable $function_to_add The name of the function you wish to be called.
     * @param int $priority Optional. Used to specify the order in which the functions
     *                                  associated with a particular action are executed. Default 10.
     * @param int $accepted_args Optional. The number of arguments the function accepts. Default 1.
     * @return true Always returns true.
     */
    function add_action($tag, $function_to_add, $priority = 10, $accepted_args = 1) {
        return true;
    }
}

if (!function_exists('register_setting')) {
    /**
     * Registers a setting and its sanitization callback.
     *
     * @param string $option_group A settings group name.
     * @param string $option_name The name of an option to sanitize and save.
     * @param array $args {
     *     Optional. An array of arguments.
     *
     *     @type string $type              The type of data associated with this setting.
     *                                      Valid values are 'string', 'boolean', 'integer', 'number', 'array', and 'object'.
     *     @type string $description       A description of the data attached to this setting.
     *     @type callable $sanitize_callback A callback function that sanitizes the option's value.
     *     @type bool $show_in_rest        Whether data associated with this setting should be included in the REST API.
     *     @type mixed $default            Default value when calling `get_option()`.
     * }
     * @return array|false The registered setting, if successful.
     */
    function register_setting($option_group, $option_name, $args = array()) {
        return array();
    }
}

if (!function_exists('settings_fields')) {
    /**
     * Outputs nonce, action, and option_page fields for a settings page.
     *
     * @param string $option_group A settings group name.
     */
    function settings_fields($option_group) {
        echo '<input type="hidden" name="option_page" value="' . esc_attr($option_group) . '" />';
        echo '<input type="hidden" name="action" value="update" />';
        echo '<input type="hidden" name="_wpnonce" value="' . wp_create_nonce($option_group . '-options') . '" />';
    }
}

if (!function_exists('do_settings_sections')) {
    /**
     * Prints out all settings sections added to a particular settings page.
     *
     * @param string $page The slug name of the page whose settings sections you want to output.
     */
    function do_settings_sections($page) {
        // Do nothing
    }
}

if (!function_exists('submit_button')) {
    /**
     * Echoes a submit button, with provided text and appropriate class.
     *
     * @param string $text The text of the button.
     * @param string $type The type and CSS class of the button.
     * @param string $name The HTML name of the submit button.
     * @param bool $wrap Whether to wrap the button in a paragraph tag.
     * @param array $other_attributes Other attributes to add to the submit button.
     */
    function submit_button($text = null, $type = 'primary', $name = 'submit', $wrap = true, $other_attributes = null) {
        echo '<button type="submit" class="button button-' . esc_attr($type) . '" name="' . esc_attr($name) . '">' . $text . '</button>';
    }
}

if (!function_exists('selected')) {
    /**
     * Outputs the HTML selected attribute.
     *
     * @param mixed $selected One of the values to compare.
     * @param mixed $current The other value to compare.
     * @param bool $echo Whether to echo or return the output.
     * @return string HTML attribute or empty string.
     */
    function selected($selected, $current = true, $echo = true) {
        $result = $selected == $current ? ' selected="selected"' : '';
        if ($echo) {
            echo $result;
        }
        return $result;
    }
}

if (!function_exists('plugin_dir_path')) {
    /**
     * Gets the filesystem directory path (with trailing slash) for the plugin __FILE__ passed in.
     *
     * @param string $file The filename of the plugin (__FILE__).
     * @return string The filesystem path of the directory that contains the plugin.
     */
    function plugin_dir_path($file) {
        return trailingslashit(dirname($file));
    }
}

if (!function_exists('plugin_dir_url')) {
    /**
     * Gets the URL directory path (with trailing slash) for the plugin __FILE__ passed in.
     *
     * @param string $file The filename of the plugin (__FILE__).
     * @return string The URL path of the directory that contains the plugin.
     */
    function plugin_dir_url($file) {
        return trailingslashit(plugins_url('', $file));
    }
}

if (!function_exists('plugins_url')) {
    /**
     * Gets the URL to the plugins directory or to a specific file within that directory.
     *
     * @param string $path Path relative to the plugins URL.
     * @param string $plugin The plugin file that you want to be relative to.
     * @return string The URL path to the plugins directory.
     */
    function plugins_url($path = '', $plugin = '') {
        return 'https://example.org/wp-content/plugins/' . ltrim($path, '/');
    }
}

if (!function_exists('plugin_basename')) {
    /**
     * Gets the basename of a plugin.
     *
     * @param string $file The filename of the plugin (__FILE__).
     * @return string The name of the plugin as a basename.
     */
    function plugin_basename($file) {
        return basename(dirname($file)) . '/' . basename($file);
    }
}

if (!function_exists('trailingslashit')) {
    /**
     * Appends a trailing slash to a string if it doesn't already have one.
     *
     * @param string $string What to add the trailing slash to.
     * @return string String with trailing slash added.
     */
    function trailingslashit($string) {
        return rtrim($string, '/\\') . '/';
    }
}

if (!function_exists('register_activation_hook')) {
    /**
     * Registers a plugin activation hook.
     *
     * @param string $file The filename of the plugin including the path.
     * @param callable $callback The function to be run when the plugin is activated.
     */
    function register_activation_hook($file, $callback) {
        // Call the callback directly for testing
        call_user_func($callback);
    }
}

if (!function_exists('register_deactivation_hook')) {
    /**
     * Registers a plugin deactivation hook.
     *
     * @param string $file The filename of the plugin including the path.
     * @param callable $callback The function to be run when the plugin is deactivated.
     */
    function register_deactivation_hook($file, $callback) {
        // Do nothing in test environment
    }
}

if (!function_exists('get_role')) {
    /**
     * Gets a role object.
     *
     * @param string $role Role name.
     * @return object|null Role object if found, null otherwise.
     */
    function get_role($role) {
        // Return a mock role object
        return new class {
            public function add_cap($cap) {
                // Do nothing
            }

            public function remove_cap($cap) {
                // Do nothing
            }
        };
    }
}

if (!function_exists('flush_rewrite_rules')) {
    /**
     * Flushes the rewrite rules.
     *
     * @param bool $hard Whether to update .htaccess (hard flush) or just update rewrite_rules option (soft flush).
     */
    function flush_rewrite_rules($hard = true) {
        // Do nothing in test environment
    }
}

if (!function_exists('wp_die')) {
    /**
     * Kills WordPress execution and displays an error message.
     *
     * @param string|WP_Error $message Error message or WP_Error object.
     * @param string $title Error title.
     * @param array $args Optional arguments to control behavior.
     */
    function wp_die($message = '', $title = '', $args = array()) {
        echo $message;
        exit;
    }
}

if (!function_exists('wp_trim_words')) {
    /**
     * Trims text to a certain number of words.
     *
     * @param string $text Text to trim.
     * @param int $num_words Number of words. Default 55.
     * @param string $more What to append if $text needs to be trimmed. Default '&hellip;'.
     * @return string Trimmed text.
     */
    function wp_trim_words($text, $num_words = 55, $more = '&hellip;') {
        $text = strip_tags($text);
        $words = explode(' ', $text, $num_words + 1);
        if (count($words) > $num_words) {
            array_pop($words);
            $text = implode(' ', $words);
            $text = $text . $more;
        }
        return $text;
    }
}

if (!function_exists('date_i18n')) {
    /**
     * Retrieves the date in localized format.
     *
     * @param string $format Format to display the date.
     * @param int|bool $timestamp_with_offset Optional. Unix timestamp. Default false.
     * @param bool $gmt Optional. Whether to use GMT timezone. Default false.
     * @return string The date, translated if locale specifies it.
     */
    function date_i18n($format, $timestamp_with_offset = false, $gmt = false) {
        if (!$timestamp_with_offset) {
            $timestamp_with_offset = time();
        }
        return date($format, $timestamp_with_offset);
    }
}

if (!function_exists('wp_get_attachment_url')) {
    /**
     * Gets the URL for an attachment.
     *
     * @param int $attachment_id Attachment ID.
     * @return string|false Attachment URL or false if not found.
     */
    function wp_get_attachment_url($attachment_id) {
        return 'https://example.org/wp-content/uploads/attachment-' . $attachment_id . '.jpg';
    }
}

if (!function_exists('esc_url')) {
    /**
     * Checks and cleans a URL.
     *
     * @param string $url The URL to be cleaned.
     * @param array $protocols Optional. An array of acceptable protocols.
     * @param string $_context Private. Use esc_url_raw() for database usage.
     * @return string The cleaned URL.
     */
    function esc_url($url, $protocols = null, $_context = 'display') {
        return $url;
    }
}

if (!function_exists('esc_textarea')) {
    /**
     * Escapes text for textarea.
     *
     * @param string $text Text to escape.
     * @return string Escaped text.
     */
    function esc_textarea($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('load_plugin_textdomain')) {
    /**
     * Loads the plugin's translated strings.
     *
     * @param string $domain Unique identifier for retrieving translated strings.
     * @param bool $deprecated Whether to load the domain from the WordPress language directory.
     * @param string $plugin_rel_path Optional. Relative path to WP_PLUGIN_DIR where the .mo file resides.
     * @return bool True when textdomain is successfully loaded, false otherwise.
     */
    function load_plugin_textdomain($domain, $deprecated = false, $plugin_rel_path = false) {
        return true;
    }
}

} // End of !defined('WPINC') condition
