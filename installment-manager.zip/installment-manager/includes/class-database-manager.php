<?php
/**
 * Database manager class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Include utility class if not already included
if (!class_exists('Installment_Manager_Utility')) {
    require_once plugin_dir_path(__FILE__) . 'class-utility.php';
}

/**
 * Database manager class.
 */
class Installment_Manager_Database_Manager {

    /**
     * The database charset.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $charset    The database charset.
     */
    private $charset;

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        global $wpdb;
        $this->charset = $wpdb->get_charset_collate();
    }

    /**
     * Create the database tables.
     *
     * @since    1.0.0
     */
    public function create_tables() {
        global $wpdb;

        // Products table
        $table_products = $wpdb->prefix . 'im_products';

        // Plans table
        $table_plans = $wpdb->prefix . 'im_plans';

        // Installments table
        $table_installments = $wpdb->prefix . 'im_installments';

        // SQL for creating tables
        $sql = "CREATE TABLE $table_products (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            description text,
            base_price decimal(15,2) NOT NULL,
            profit_option varchar(50) DEFAULT 'fixed',
            profit_value decimal(15,2) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $this->charset;

        CREATE TABLE $table_plans (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            customer_id bigint(20) NOT NULL,
            product_id bigint(20) NOT NULL,
            total_amount decimal(15,2) NOT NULL,
            down_payment decimal(15,2) DEFAULT 0,
            installment_count int NOT NULL,
            installment_amount decimal(15,2) NOT NULL,
            payment_frequency varchar(50) DEFAULT 'monthly',
            start_date date NOT NULL,
            status varchar(50) DEFAULT 'active',
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY customer_id (customer_id),
            KEY product_id (product_id)
        ) $this->charset;

        CREATE TABLE $table_installments (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            plan_id bigint(20) NOT NULL,
            amount decimal(15,2) NOT NULL,
            due_date date NOT NULL,
            status varchar(50) DEFAULT 'unpaid',
            payment_date date DEFAULT NULL,
            payment_method varchar(50) DEFAULT NULL,
            payment_proof_id bigint(20) DEFAULT NULL,
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY plan_id (plan_id),
            KEY status (status),
            KEY due_date (due_date)
        ) $this->charset;";

        // Check if ABSPATH is defined, if not define it
        if (!defined('ABSPATH')) {
            define('ABSPATH', dirname(__FILE__) . '/../../../');
        }

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        if (function_exists('dbDelta')) {
            dbDelta($sql);
        } else {
            // Fallback if dbDelta is not available
            $wpdb->query($sql);
        }

        // Add version to options
        if (function_exists('update_option')) {
            update_option('im_db_version', INSTALLMENT_MANAGER_VERSION);
        } else {
            // Fallback if update_option is not available
            global $wpdb;
            $options_table = $wpdb->prefix . 'options';
            $option_exists = $wpdb->get_var($wpdb->prepare("SELECT option_id FROM $options_table WHERE option_name = %s", 'im_db_version'));

            if ($option_exists) {
                $wpdb->update(
                    $options_table,
                    ['option_value' => INSTALLMENT_MANAGER_VERSION],
                    ['option_name' => 'im_db_version']
                );
            } else {
                $wpdb->insert(
                    $options_table,
                    [
                        'option_name' => 'im_db_version',
                        'option_value' => INSTALLMENT_MANAGER_VERSION,
                        'autoload' => 'yes'
                    ]
                );
            }
        }
    }

    /**
     * Get products from the database.
     *
     * @since    1.0.0
     * @param    array    $args    Query arguments.
     * @return   array             Array of products.
     */
    public function get_products($args = array()) {
        global $wpdb;

        $defaults = array(
            'number'     => 20,
            'offset'     => 0,
            'orderby'    => 'id',
            'order'      => 'DESC',
            'search'     => '',
        );

        // Implement wp_parse_args functionality if not available
        if (function_exists('wp_parse_args')) {
            $args = wp_parse_args($args, $defaults);
        } else {
            // Simple implementation of wp_parse_args
            $args = array_merge($defaults, $args);
        }

        $table = $wpdb->prefix . 'im_products';

        $sql = "SELECT * FROM $table";

        // Search condition
        if (!empty($args['search'])) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $sql .= $wpdb->prepare(" WHERE name LIKE %s OR description LIKE %s", $search, $search);
        }

        // Order
        if (function_exists('sanitize_sql_orderby')) {
            $sql .= " ORDER BY " . sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']);
        } else {
            // Simple implementation of sanitize_sql_orderby
            $orderby = strtolower($args['orderby']);
            $order = strtoupper($args['order']);

            // Validate orderby
            $valid_orderby = ['id', 'name', 'base_price', 'created_at', 'updated_at'];
            if (!in_array($orderby, $valid_orderby)) {
                $orderby = 'id';
            }

            // Validate order
            $order = ($order === 'ASC' || $order === 'DESC') ? $order : 'DESC';

            $sql .= " ORDER BY " . $orderby . ' ' . $order;
        }

        // Limit
        if ($args['number'] != -1) {
            $sql .= $wpdb->prepare(" LIMIT %d, %d", $args['offset'], $args['number']);
        }

        $results = $wpdb->get_results($sql, ARRAY_A);

        return $results;
    }

    /**
     * Get a single product from the database.
     *
     * @since    1.0.0
     * @param    int      $id    Product ID.
     * @return   array           Product data.
     */
    public function get_product($id) {
        global $wpdb;

        $table = $wpdb->prefix . 'im_products';

        $sql = $wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id);

        $result = $wpdb->get_row($sql, ARRAY_A);

        return $result;
    }

    /**
     * Insert or update a product.
     *
     * @since    1.0.0
     * @param    array    $data    Product data.
     * @return   int               Product ID.
     */
    public function save_product($data) {
        global $wpdb;

        $table = $wpdb->prefix . 'im_products';

        $defaults = array(
            'name'          => '',
            'description'   => '',
            'base_price'    => 0,
            'profit_option' => 'fixed',
            'profit_value'  => 0,
        );

        // Implement wp_parse_args functionality if not available
        if (function_exists('wp_parse_args')) {
            $data = wp_parse_args($data, $defaults);
        } else {
            // Simple implementation of wp_parse_args
            $data = array_merge($defaults, $data);
        }

        // Sanitize data
        $data['name'] = Installment_Manager_Utility::sanitize_text_field($data['name']);
        $data['profit_option'] = Installment_Manager_Utility::sanitize_text_field($data['profit_option']);
        $data['description'] = Installment_Manager_Utility::sanitize_textarea_field($data['description']);

        $data['base_price'] = floatval($data['base_price']);
        $data['profit_value'] = floatval($data['profit_value']);

        // Check if we need to update or insert
        if (!empty($data['id'])) {
            $wpdb->update(
                $table,
                $data,
                array('id' => $data['id'])
            );

            return $data['id'];
        } else {
            $wpdb->insert($table, $data);

            return $wpdb->insert_id;
        }
    }

    /**
     * Delete a product.
     *
     * @since    1.0.0
     * @param    int      $id    Product ID.
     * @return   bool            True if successful, false otherwise.
     */
    public function delete_product($id) {
        global $wpdb;

        $table = $wpdb->prefix . 'im_products';

        return $wpdb->delete($table, array('id' => $id));
    }

    /**
     * Get plans from the database.
     *
     * @since    1.0.0
     * @param    array    $args    Query arguments.
     * @return   array             Array of plans.
     */
    public function get_plans($args = array()) {
        global $wpdb;

        $defaults = array(
            'number'      => 20,
            'offset'      => 0,
            'orderby'     => 'id',
            'order'       => 'DESC',
            'customer_id' => 0,
            'product_id'  => 0,
            'status'      => '',
        );

        // Implement wp_parse_args functionality if not available
        if (function_exists('wp_parse_args')) {
            $args = wp_parse_args($args, $defaults);
        } else {
            // Simple implementation of wp_parse_args
            $args = array_merge($defaults, $args);
        }

        $table_plans = $wpdb->prefix . 'im_plans';
        $table_products = $wpdb->prefix . 'im_products';

        $sql = "SELECT p.*, pr.name as product_name
                FROM $table_plans p
                LEFT JOIN $table_products pr ON p.product_id = pr.id";

        $where = array();

        // Filter by customer
        if (!empty($args['customer_id'])) {
            $where[] = $wpdb->prepare("p.customer_id = %d", $args['customer_id']);
        }

        // Filter by product
        if (!empty($args['product_id'])) {
            $where[] = $wpdb->prepare("p.product_id = %d", $args['product_id']);
        }

        // Filter by status
        if (!empty($args['status'])) {
            $where[] = $wpdb->prepare("p.status = %s", $args['status']);
        }

        // Add WHERE clause if needed
        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }

        // Order
        $orderby = strtolower($args['orderby']);
        $order = strtoupper($args['order']);

        // Validate orderby
        $valid_orderby = ['id', 'customer_id', 'product_id', 'total_amount', 'installment_count', 'start_date', 'status', 'created_at', 'updated_at'];
        if (!in_array($orderby, $valid_orderby)) {
            $orderby = 'id';
        }

        // Validate order
        $order = ($order === 'ASC' || $order === 'DESC') ? $order : 'DESC';

        $sql .= " ORDER BY p." . $orderby . ' ' . $order;

        // Limit
        if ($args['number'] != -1) {
            $sql .= $wpdb->prepare(" LIMIT %d, %d", $args['offset'], $args['number']);
        }

        $results = $wpdb->get_results($sql, ARRAY_A);

        // Get customer data for each plan
        foreach ($results as &$plan) {
            // Always use direct database query for customer data
            global $wpdb;
            $user_table = $wpdb->prefix . 'users';
            $user = $wpdb->get_row($wpdb->prepare("SELECT display_name, user_email FROM $user_table WHERE ID = %d", $plan['customer_id']));

            if ($user) {
                $plan['customer_name'] = $user->display_name;
                $plan['customer_email'] = $user->user_email;
            } else {
                $plan['customer_name'] = __('Unknown Customer', 'installment-manager');
                $plan['customer_email'] = '';
            }
        }

        return $results;
    }

    /**
     * Get a single plan from the database.
     *
     * @since    1.0.0
     * @param    int      $id    Plan ID.
     * @return   array           Plan data.
     */
    public function get_plan($id) {
        global $wpdb;

        $table_plans = $wpdb->prefix . 'im_plans';
        $table_products = $wpdb->prefix . 'im_products';

        $sql = $wpdb->prepare(
            "SELECT p.*, pr.name as product_name, pr.description as product_description
            FROM $table_plans p
            LEFT JOIN $table_products pr ON p.product_id = pr.id
            WHERE p.id = %d",
            $id
        );

        $plan = $wpdb->get_row($sql, ARRAY_A);

        if ($plan) {
            // Get customer data - always use direct database query
            global $wpdb;
            $user_table = $wpdb->prefix . 'users';
            $user = $wpdb->get_row($wpdb->prepare("SELECT display_name, user_email FROM $user_table WHERE ID = %d", $plan['customer_id']));

            if ($user) {
                $plan['customer_name'] = $user->display_name;
                $plan['customer_email'] = $user->user_email;
            } else {
                $plan['customer_name'] = __('Unknown Customer', 'installment-manager');
                $plan['customer_email'] = '';
            }

            // Get installments
            $plan['installments'] = $this->get_installments(array('plan_id' => $id));
        }

        return $plan;
    }

    /**
     * Insert or update a plan.
     *
     * @since    1.0.0
     * @param    array    $data    Plan data.
     * @return   int               Plan ID.
     */
    public function save_plan($data) {
        global $wpdb;

        $table_plans = $wpdb->prefix . 'im_plans';
        $table_installments = $wpdb->prefix . 'im_installments';

        $defaults = array(
            'customer_id'       => 0,
            'product_id'        => 0,
            'total_amount'      => 0,
            'down_payment'      => 0,
            'installment_count' => 1,
            'installment_amount' => 0,
            'payment_frequency' => 'monthly',
            'start_date'        => date('Y-m-d'),
            'status'            => 'active',
            'notes'             => '',
        );

        // Implement wp_parse_args functionality if not available
        if (function_exists('wp_parse_args')) {
            $data = wp_parse_args($data, $defaults);
        } else {
            // Simple implementation of wp_parse_args
            $data = array_merge($defaults, $data);
        }

        // Sanitize data
        $data['customer_id'] = intval($data['customer_id']);
        $data['product_id'] = intval($data['product_id']);
        $data['total_amount'] = floatval($data['total_amount']);
        $data['down_payment'] = floatval($data['down_payment']);
        $data['installment_count'] = intval($data['installment_count']);
        $data['installment_amount'] = floatval($data['installment_amount']);

        // Sanitize text fields using utility functions
        $data['payment_frequency'] = isset($data['payment_frequency']) ?
            Installment_Manager_Utility::sanitize_text_field($data['payment_frequency']) : 'monthly';
        $data['start_date'] = isset($data['start_date']) ?
            Installment_Manager_Utility::sanitize_text_field($data['start_date']) : date('Y-m-d');
        $data['status'] = isset($data['status']) ?
            Installment_Manager_Utility::sanitize_text_field($data['status']) : 'active';

        // Sanitize textarea fields using utility functions
        $data['notes'] = isset($data['notes']) ?
            Installment_Manager_Utility::sanitize_textarea_field($data['notes']) : '';

        // Store recreate_installments flag but remove it from the data array before database operation
        $recreate_installments = !empty($data['recreate_installments']);
        unset($data['recreate_installments']);

        // Start transaction
        $wpdb->query('START TRANSACTION');

        try {
            // Check if we need to update or insert
            if (!empty($data['id'])) {
                $result = $wpdb->update(
                    $table_plans,
                    $data,
                    array('id' => $data['id'])
                );

                if ($result === false) {
                    error_log('Installment Manager: Failed to update plan - ' . $wpdb->last_error);
                    throw new Exception('Failed to update plan');
                }

                $plan_id = $data['id'];

                // Delete existing installments if requested
                if ($recreate_installments) {
                    $delete_result = $wpdb->delete($table_installments, array('plan_id' => $plan_id));

                    if ($delete_result === false) {
                        error_log('Installment Manager: Failed to delete existing installments - ' . $wpdb->last_error);
                        throw new Exception('Failed to delete existing installments');
                    }

                    $create_result = $this->create_installments($plan_id);

                    if ($create_result === false) {
                        error_log('Installment Manager: Failed to create new installments');
                        throw new Exception('Failed to create new installments');
                    }
                }
            } else {
                $result = $wpdb->insert($table_plans, $data);

                if ($result === false) {
                    error_log('Installment Manager: Failed to insert plan - ' . $wpdb->last_error);
                    throw new Exception('Failed to insert plan');
                }

                $plan_id = $wpdb->insert_id;

                if (!$plan_id) {
                    error_log('Installment Manager: Failed to get insert ID');
                    throw new Exception('Failed to get insert ID');
                }

                // Create installments
                $create_result = $this->create_installments($plan_id);

                if ($create_result === false) {
                    error_log('Installment Manager: Failed to create installments');
                    throw new Exception('Failed to create installments');
                }
            }

            // Commit transaction
            $wpdb->query('COMMIT');

            return $plan_id;
        } catch (Exception $e) {
            // Rollback transaction
            $wpdb->query('ROLLBACK');

            error_log('Installment Manager: Exception in save_plan - ' . $e->getMessage());

            return false;
        }
    }

    /**
     * Create installments for a plan.
     *
     * @since    1.0.0
     * @param    int      $plan_id    Plan ID.
     * @return   bool                 True if successful, false otherwise.
     */
    private function create_installments($plan_id) {
        global $wpdb;

        $table_installments = $wpdb->prefix . 'im_installments';

        // Get plan data
        $plan = $this->get_plan($plan_id);

        if (!$plan) {
            error_log('Installment Manager: Failed to create installments - plan not found');
            return false;
        }

        try {
            // Ensure start_date is a valid date
            $start_date_str = Installment_Manager_Utility::sanitize_text_field($plan['start_date']);
            if (empty($start_date_str) || !strtotime($start_date_str)) {
                // If start_date is invalid, use current date
                $start_date_str = date('Y-m-d');
            }

            // Calculate installment dates and amounts
            $start_date = new DateTime($start_date_str);
            $installment_amount = floatval($plan['installment_amount']);
            $installment_count = intval($plan['installment_count']);
            $frequency = Installment_Manager_Utility::sanitize_text_field($plan['payment_frequency']);

            // Validate installment count
            if ($installment_count < 1) {
                $installment_count = 1;
            }

            // Create installments
            for ($i = 0; $i < $installment_count; $i++) {
                // Calculate due date based on frequency
                $due_date = clone $start_date;

                if ($i > 0) {
                    switch ($frequency) {
                        case 'weekly':
                            $due_date->modify('+' . $i . ' week');
                            break;
                        case 'biweekly':
                            $due_date->modify('+' . ($i * 2) . ' week');
                            break;
                        case 'monthly':
                            $due_date->modify('+' . $i . ' month');
                            break;
                        case 'quarterly':
                            $due_date->modify('+' . ($i * 3) . ' month');
                            break;
                        default:
                            // Default to monthly if frequency is invalid
                            $due_date->modify('+' . $i . ' month');
                    }
                }

                // Format due date
                $due_date_str = $due_date->format('Y-m-d');

                // Insert installment
                $result = $wpdb->insert(
                    $table_installments,
                    array(
                        'plan_id'  => $plan_id,
                        'amount'   => $installment_amount,
                        'due_date' => $due_date_str,
                        'status'   => 'unpaid',
                    )
                );

                if ($result === false) {
                    error_log('Installment Manager: Failed to insert installment - ' . $wpdb->last_error);
                    return false;
                }
            }

            return true;
        } catch (Exception $e) {
            error_log('Installment Manager: Exception in create_installments - ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete a plan.
     *
     * @since    1.0.0
     * @param    int      $id    Plan ID.
     * @return   bool            True if successful, false otherwise.
     */
    public function delete_plan($id) {
        global $wpdb;

        $table_plans = $wpdb->prefix . 'im_plans';
        $table_installments = $wpdb->prefix . 'im_installments';

        // Start transaction
        $wpdb->query('START TRANSACTION');

        try {
            // Delete installments
            $wpdb->delete($table_installments, array('plan_id' => $id));

            // Delete plan
            $wpdb->delete($table_plans, array('id' => $id));

            // Commit transaction
            $wpdb->query('COMMIT');

            return true;
        } catch (Exception $e) {
            // Rollback transaction
            $wpdb->query('ROLLBACK');

            return false;
        }
    }

    /**
     * Get installments from the database.
     *
     * @since    1.0.0
     * @param    array    $args    Query arguments.
     * @return   array             Array of installments.
     */
    public function get_installments($args = array()) {
        global $wpdb;

        $defaults = array(
            'number'  => -1,
            'offset'  => 0,
            'orderby' => 'due_date',
            'order'   => 'ASC',
            'plan_id' => 0,
            'status'  => '',
        );

        // Implement wp_parse_args functionality if not available
        if (function_exists('wp_parse_args')) {
            $args = wp_parse_args($args, $defaults);
        } else {
            // Simple implementation of wp_parse_args
            $args = array_merge($defaults, $args);
        }

        $table = $wpdb->prefix . 'im_installments';

        $sql = "SELECT * FROM $table";

        $where = array();

        // Filter by plan
        if (!empty($args['plan_id'])) {
            $where[] = $wpdb->prepare("plan_id = %d", $args['plan_id']);
        }

        // Filter by status
        if (!empty($args['status'])) {
            $where[] = $wpdb->prepare("status = %s", $args['status']);
        }

        // Add WHERE clause if needed
        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }

        // Order
        if (function_exists('sanitize_sql_orderby')) {
            $sql .= " ORDER BY " . sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']);
        } else {
            // Simple implementation of sanitize_sql_orderby
            $orderby = strtolower($args['orderby']);
            $order = strtoupper($args['order']);

            // Validate orderby
            $valid_orderby = ['id', 'plan_id', 'amount', 'due_date', 'status', 'payment_date', 'created_at', 'updated_at'];
            if (!in_array($orderby, $valid_orderby)) {
                $orderby = 'due_date';
            }

            // Validate order
            $order = ($order === 'ASC' || $order === 'DESC') ? $order : 'ASC';

            $sql .= " ORDER BY " . $orderby . ' ' . $order;
        }

        // Limit
        if ($args['number'] != -1) {
            $sql .= $wpdb->prepare(" LIMIT %d, %d", $args['offset'], $args['number']);
        }

        $results = $wpdb->get_results($sql, ARRAY_A);

        return $results;
    }

    /**
     * Get a single installment from the database.
     *
     * @since    1.0.0
     * @param    int      $id    Installment ID.
     * @return   array           Installment data.
     */
    public function get_installment($id) {
        global $wpdb;

        $table = $wpdb->prefix . 'im_installments';

        $sql = $wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id);

        $result = $wpdb->get_row($sql, ARRAY_A);

        return $result;
    }

    /**
     * Update an installment.
     *
     * @since    1.0.0
     * @param    int      $id      Installment ID.
     * @param    array    $data    Installment data.
     * @return   bool              True if successful, false otherwise.
     */
    public function update_installment($id, $data) {
        global $wpdb;

        $table = $wpdb->prefix . 'im_installments';

        // Sanitize data using utility functions
        if (isset($data['status'])) {
            $data['status'] = Installment_Manager_Utility::sanitize_text_field($data['status']);
        }

        if (isset($data['payment_date'])) {
            $data['payment_date'] = Installment_Manager_Utility::sanitize_text_field($data['payment_date']);
        }

        if (isset($data['payment_method'])) {
            $data['payment_method'] = Installment_Manager_Utility::sanitize_text_field($data['payment_method']);
        }

        if (isset($data['payment_proof_id'])) {
            $data['payment_proof_id'] = intval($data['payment_proof_id']);
        }

        if (isset($data['notes'])) {
            $data['notes'] = Installment_Manager_Utility::sanitize_textarea_field($data['notes']);
        }

        return $wpdb->update(
            $table,
            $data,
            array('id' => $id)
        );
    }

    /**
     * Get dashboard statistics.
     *
     * @since    1.0.0
     * @return   array    Statistics data.
     */
    public function get_dashboard_stats() {
        global $wpdb;

        $table_plans = $wpdb->prefix . 'im_plans';
        $table_installments = $wpdb->prefix . 'im_installments';

        // Total active plans
        $active_plans = $wpdb->get_var("SELECT COUNT(*) FROM $table_plans WHERE status = 'active'");

        // Total amount of all plans
        $total_amount = $wpdb->get_var("SELECT SUM(total_amount) FROM $table_plans");

        // Total paid amount
        $paid_amount = $wpdb->get_var("
            SELECT SUM(i.amount)
            FROM $table_installments i
            JOIN $table_plans p ON i.plan_id = p.id
            WHERE i.status = 'paid'
        ");

        // Total due amount
        $due_amount = $wpdb->get_var("
            SELECT SUM(i.amount)
            FROM $table_installments i
            JOIN $table_plans p ON i.plan_id = p.id
            WHERE i.status = 'unpaid' AND i.due_date <= CURDATE()
        ");

        // Upcoming installments (next 30 days)
        $upcoming_installments = $wpdb->get_var("
            SELECT COUNT(*)
            FROM $table_installments i
            JOIN $table_plans p ON i.plan_id = p.id
            WHERE i.status = 'unpaid'
            AND i.due_date > CURDATE()
            AND i.due_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
        ");

        // Overdue installments
        $overdue_installments = $wpdb->get_var("
            SELECT COUNT(*)
            FROM $table_installments i
            JOIN $table_plans p ON i.plan_id = p.id
            WHERE i.status = 'unpaid' AND i.due_date < CURDATE()
        ");

        return array(
            'active_plans'         => intval($active_plans),
            'total_amount'         => floatval($total_amount),
            'paid_amount'          => floatval($paid_amount),
            'due_amount'           => floatval($due_amount),
            'upcoming_installments' => intval($upcoming_installments),
            'overdue_installments' => intval($overdue_installments),
        );
    }
}
