<?php
/**
 * Frontend controller class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Frontend controller class.
 */
class Installment_Manager_Frontend_Controller {

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Initialize
    }

    /**
     * Register shortcodes.
     *
     * @since    1.0.0
     */
    public function register_shortcodes() {
        // Remove existing shortcode if it exists (to prevent conflicts)
        if (shortcode_exists('installment_customer_portal')) {
            remove_shortcode('installment_customer_portal');
        }

        // Add our shortcode
        add_shortcode('installment_customer_portal', array($this, 'render_customer_portal'));

        // Log for debugging
        error_log('Installment Manager: Shortcode registered');
    }

    /**
     * Enqueue public assets.
     *
     * @since    1.0.0
     */
    public function enqueue_public_assets() {
        global $post;

        // Check if our shortcode is used on this page - improved detection
        if (is_a($post, 'WP_Post') &&
            (has_shortcode($post->post_content, 'installment_customer_portal') ||
             stripos($post->post_content, '[installment_customer_portal') !== false)) {
            // Bootstrap CSS
            wp_enqueue_style(
                'bootstrap',
                'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
                array(),
                '5.3.0'
            );

            // Bootstrap Icons
            wp_enqueue_style(
                'bootstrap-icons',
                'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css',
                array(),
                '1.10.0'
            );

            // Bootstrap Custom CSS
            wp_enqueue_style(
                'installment-manager-bootstrap-custom',
                INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/css/bootstrap-custom.css',
                array('bootstrap'),
                filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/css/bootstrap-custom.css')
            );

            // Plugin CSS
            wp_enqueue_style(
                'installment-manager-public',
                INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/css/public.css',
                array('bootstrap', 'installment-manager-bootstrap-custom'),
                filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/css/public.css')
            );

            // RTL and Arabic language CSS
            $locale = function_exists('get_locale') ? get_locale() : 'en_US';
            if (strpos($locale, 'ar') === 0) {
                wp_enqueue_style(
                    'installment-manager-rtl',
                    INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/css/rtl.css',
                    array('installment-manager-public'),
                    filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/css/rtl.css')
                );
            }

            // Select2
            wp_enqueue_style(
                'select2',
                'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css',
                array(),
                '4.1.0-rc.0'
            );

            wp_enqueue_script(
                'select2',
                'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js',
                array('jquery'),
                '4.1.0-rc.0',
                true
            );

            // Bootstrap JS
            wp_enqueue_script(
                'bootstrap-bundle',
                'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
                array('jquery'),
                '5.3.0',
                true
            );

            // WordPress Media Uploader
            wp_enqueue_media();

            // Main public JS
            wp_enqueue_script(
                'installment-manager-public',
                INSTALLMENT_MANAGER_PLUGIN_URL . 'assets/js/public.js',
                array('jquery', 'select2', 'bootstrap-bundle'),
                filemtime(INSTALLMENT_MANAGER_PLUGIN_DIR . 'assets/js/public.js'),
                true
            );

            // Localize script
            wp_localize_script(
                'installment-manager-public',
                'imPublicData',
                array(
                    'ajaxUrl'  => admin_url('admin-ajax.php'),
                    'nonce'    => wp_create_nonce('installment_manager_public_nonce'),
                    'strings'  => array(
                        'selectPlan'        => __('Select a plan...', 'installment-manager'),
                        'loading'           => __('Loading...', 'installment-manager'),
                        'noPlans'           => __('You have no installment plans.', 'installment-manager'),
                        'selectPaymentMethod' => __('Select payment method...', 'installment-manager'),
                        'uploadProof'       => __('Upload Payment Proof', 'installment-manager'),
                        'selectImage'       => __('Select Image', 'installment-manager'),
                        'processing'        => __('Processing...', 'installment-manager'),
                        'viewProof'         => __('View Proof', 'installment-manager'),
                        'uploadPayment'     => __('Upload Payment', 'installment-manager'),
                        'invalidFileType'   => __('Please select a valid image file (JPG, PNG, GIF, WEBP).', 'installment-manager'),
                        'fileTooLarge'      => __('The selected file is too large. Maximum size is 10MB.', 'installment-manager'),
                        'selectProofImage'  => __('Please select a payment proof image.', 'installment-manager'),
                        'active'            => __('Active', 'installment-manager'),
                        'completed'         => __('Completed', 'installment-manager'),
                        'cancelled'         => __('Cancelled', 'installment-manager'),
                        'unpaid'            => __('Unpaid', 'installment-manager'),
                        'paid'              => __('Paid', 'installment-manager'),
                        'underReview'       => __('Under Review', 'installment-manager'),
                        'late'              => __('Late', 'installment-manager'),
                        'cash'              => __('Cash', 'installment-manager'),
                        'visa'              => __('Visa/Mastercard', 'installment-manager'),
                        'vodafoneCash'      => __('Vodafone Cash', 'installment-manager'),
                        'etisalatCash'      => __('Etisalat Cash', 'installment-manager'),
                        'instapay'          => __('InstaPay', 'installment-manager'),
                        'bankTransfer'      => __('Bank Transfer', 'installment-manager'),
                        'other'             => __('Other', 'installment-manager'),
                    ),
                    'currency' => Installment_Manager_Helper_Functions::get_currency_symbol(),
                    'userId'   => get_current_user_id(),
                )
            );
        }
    }

    // Using Installment_Manager_Helper_Functions::get_currency_symbol() instead

    /**
     * Render the customer portal shortcode.
     *
     * @since    1.0.0
     * @param    array     $atts    Shortcode attributes.
     * @return   string             Shortcode output.
     */
    public function render_customer_portal($atts) {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: 0");
        // Parse attributes
        $atts = shortcode_atts(
            array(
                'title' => __('My Installment Plans', 'installment-manager'),
            ),
            $atts,
            'installment_customer_portal'
        );

        // Check if user is logged in
        if (!is_user_logged_in()) {
            return '<div class="im-error">' . __('Please log in to view your installment plans.', 'installment-manager') . '</div>';
        }

        // Get current user ID
        $user_id = get_current_user_id();

        // Get database manager
        $db_manager = new Installment_Manager_Database_Manager();

        // Get user's plans
        $plans = $db_manager->get_plans(array(
            'customer_id' => $user_id,
            'number'      => -1,
        ));

        // Start output buffering
        ob_start();

        // Include template
        include INSTALLMENT_MANAGER_PLUGIN_DIR . 'public/views/customer-portal.php';

        // Return the buffered content
        return ob_get_clean();
    }
}
