<?php
/**
 * The core plugin class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * The core plugin class.
 */
class Installment_Manager {

    /**
     * The loader that's responsible for maintaining and registering all hooks.
     *
     * @since    1.0.0
     * @access   protected
     * @var      array    $loaders    Maintains all hooks for the plugin.
     */
    protected $loaders = array();

    /**
     * Define the core functionality of the plugin.
     *
     * @since    1.0.0
     */
    public function __construct() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
        $this->define_ajax_hooks();
        $this->define_media_hooks();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {
        // Helper functions
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-helper-functions.php';

        // Database manager
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-database-manager.php';

        // Admin controller
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-admin-controller.php';

        // Frontend controller
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-frontend-controller.php';

        // AJAX handler
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-ajax-handler.php';

        // Media handler
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-media-handler.php';

        // Models
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/models/class-product.php';
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/models/class-plan.php';
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/models/class-installment.php';
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale() {
        add_action('plugins_loaded', array($this, 'load_plugin_textdomain'));
    }

    /**
     * Load the plugin text domain for translation.
     *
     * @since    1.0.0
     */
    public function load_plugin_textdomain() {
        load_plugin_textdomain(
            'installment-manager',
            false,
            dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );
    }

    /**
     * Register all of the hooks related to the admin area functionality.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        $admin_controller = new Installment_Manager_Admin_Controller();

        // Admin menu
        add_action('admin_menu', array($admin_controller, 'register_admin_menu'));

        // Admin scripts and styles
        add_action('admin_enqueue_scripts', array($admin_controller, 'enqueue_admin_assets'));
    }

    /**
     * Register all of the hooks related to the public-facing functionality.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {
        $frontend_controller = new Installment_Manager_Frontend_Controller();

        // Register shortcodes - higher priority to ensure it runs early
        add_action('init', array($frontend_controller, 'register_shortcodes'), 5);

        // Enqueue public scripts and styles
        add_action('wp_enqueue_scripts', array($frontend_controller, 'enqueue_public_assets'));
    }

    /**
     * Register all of the hooks related to AJAX functionality.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_ajax_hooks() {
        $ajax_handler = new Installment_Manager_Ajax_Handler();

        // Admin AJAX actions
        add_action('wp_ajax_im_get_dashboard_stats', array($ajax_handler, 'get_dashboard_stats'));
        add_action('wp_ajax_im_save_product', array($ajax_handler, 'save_product'));
        add_action('wp_ajax_im_delete_product', array($ajax_handler, 'delete_product'));
        add_action('wp_ajax_im_save_plan', array($ajax_handler, 'save_plan'));
        add_action('wp_ajax_im_delete_plan', array($ajax_handler, 'delete_plan'));
        add_action('wp_ajax_im_update_installment_status', array($ajax_handler, 'update_installment_status'));
        add_action('wp_ajax_im_search_customers', array($ajax_handler, 'search_customers'));
        add_action('wp_ajax_im_search_products', array($ajax_handler, 'search_products'));

        // Public AJAX actions
        add_action('wp_ajax_im_get_customer_plans', array($ajax_handler, 'get_customer_plans'));
        add_action('wp_ajax_im_get_plan_details', array($ajax_handler, 'get_plan_details'));
        add_action('wp_ajax_im_upload_payment_proof', array($ajax_handler, 'upload_payment_proof'));
    }

    /**
     * Register plugin settings.
     *
     * @since    1.0.0
     * @access   private
     */
    private function register_settings() {
        add_action('admin_init', array($this, 'register_plugin_settings'));
    }

    /**
     * Register plugin settings with WordPress.
     *
     * @since    1.0.0
     */
    public function register_plugin_settings() {
        register_setting('installment_manager_settings', 'im_currency', array(
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'USD'
        ));
        register_setting('installment_manager_settings', 'im_payment_methods', array(
            'sanitize_callback' => array($this, 'sanitize_json_field'),
            'default' => '[]'
        ));
        register_setting('installment_manager_settings', 'im_currencies', array(
            'sanitize_callback' => array($this, 'sanitize_json_field'),
            'default' => '[]'
        ));
    }

    /**
     * Sanitize JSON data from settings fields.
     *
     * @since    1.0.0
     * @param    string    $input    The input JSON string.
     * @return   array               The sanitized array.
     */
    public function sanitize_json_field($input) {
        if (empty($input)) {
            return array();
        }

        // If already an array, return it
        if (is_array($input)) {
            return $input;
        }

        // Decode JSON string
        $decoded = json_decode($input, true);

        // If JSON is invalid, return empty array
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array();
        }

        return $decoded;
    }

    /**
     * Register all of the hooks related to media handling.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_media_hooks() {
        $media_handler = new Installment_Manager_Media_Handler();

        // Register media hooks
        $media_handler->register_hooks();
    }

    /**
     * Run the plugin.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->register_settings();
    }
}
