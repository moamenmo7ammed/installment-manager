<?php
/**
 * Media handler class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Media handler class.
 */
class Installment_Manager_Media_Handler {

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Initialize
    }

    /**
     * Register hooks.
     *
     * @since    1.0.0
     */
    public function register_hooks() {
        // Restrict media library access for non-admin users
        add_filter('ajax_query_attachments_args', array($this, 'restrict_media_library_access'));

        // Filter media upload types and size
        add_filter('upload_mimes', array($this, 'restrict_upload_mimes'));
        add_filter('wp_handle_upload_prefilter', array($this, 'restrict_file_size'));

        // Set custom media library states
        add_filter('media_view_settings', array($this, 'set_media_view_settings'), 10, 2);

        // Customize media uploader for frontend
        add_filter('media_view_strings', array($this, 'customize_media_strings'), 10, 1);

        // Add custom upload size limit for non-admin users
        add_filter('upload_size_limit', array($this, 'set_upload_size_limit'), 10, 3);

        // Modify plupload config for frontend
        add_filter('plupload_init', array($this, 'modify_plupload_config'));

        // Ensure users can only delete their own attachments
        add_filter('user_has_cap', array($this, 'restrict_attachment_deletion'), 10, 4);
    }

    /**
     * Restrict media library access for non-admin users.
     * Users can only see their own uploads.
     *
     * @since    1.0.0
     * @param    array    $query    The query arguments.
     * @return   array              Modified query arguments.
     */
    public function restrict_media_library_access($query) {
        // If not admin, only show user's own uploads
        if (!current_user_can('manage_installment_plans')) {
            $query['author'] = get_current_user_id();
        }

        return $query;
    }

    /**
     * Restrict upload mime types to images only.
     *
     * @since    1.0.0
     * @param    array    $mimes    Allowed mime types.
     * @return   array              Modified mime types.
     */
    public function restrict_upload_mimes($mimes) {
        // Only allow image uploads for payment proofs
        if (!current_user_can('manage_installment_plans')) {
            // Only allow common image formats
            return array(
                'jpg|jpeg|jpe' => 'image/jpeg',
                'png'          => 'image/png',
                'gif'          => 'image/gif',
                'webp'         => 'image/webp',
                'heic'         => 'image/heic',
            );
        }

        return $mimes;
    }

    /**
     * Restrict file size to 10MB.
     *
     * @since    1.0.0
     * @param    array    $file    File data.
     * @return   array             Modified file data.
     */
    public function restrict_file_size($file) {
        // Only apply size restriction to non-admin users
        if (!current_user_can('manage_installment_plans')) {
            // 10MB in bytes
            $max_size = 10 * 1024 * 1024;

            // Check if file size exceeds the limit
            if ($file['size'] > $max_size) {
                $file['error'] = sprintf(
                    __('File size limit exceeded. The maximum allowed size is %s.', 'installment-manager'),
                    size_format($max_size)
                );
            }
        }

        return $file;
    }

    /**
     * Set media view settings.
     *
     * @since    1.0.0
     * @param    array    $settings    Media view settings.
     * @param    WP_Post  $post        Post object.
     * @return   array                 Modified settings.
     */
    public function set_media_view_settings($settings, $post) {
        // For non-admin users, set default view to uploaded
        if (!current_user_can('manage_installment_plans')) {
            $settings['mediaTrash'] = false;
            $settings['labels']['filterByType'] = __('Filter by type', 'installment-manager');
            $settings['labels']['searchMediaLabel'] = __('Search Images', 'installment-manager');
            $settings['labels']['uploadFilesTitle'] = __('Upload Payment Proof', 'installment-manager');
            $settings['labels']['selectMediaTitle'] = __('Select Payment Proof', 'installment-manager');

            // Set default tab to 'uploaded' to show user's own uploads
            if (!isset($settings['tabs'])) {
                $settings['tabs'] = array();
            }
            $settings['tabs']['uploaded'] = true;
            $settings['defaultTab'] = 'uploaded';
        }

        return $settings;
    }

    /**
     * Customize media strings.
     *
     * @since    1.0.0
     * @param    array    $strings    Media view strings.
     * @return   array                Modified strings.
     */
    public function customize_media_strings($strings) {
        // For non-admin users, customize media strings
        if (!current_user_can('manage_installment_plans')) {
            $strings['uploadImagesTitle'] = __('Upload Payment Proof', 'installment-manager');
            $strings['uploadMediaTitle'] = __('Upload Payment Proof', 'installment-manager');
            $strings['insertMediaTitle'] = __('Select Payment Proof', 'installment-manager');
            $strings['createGalleryTitle'] = __('Select Payment Proof', 'installment-manager');
            $strings['filterByType'] = __('Filter by type', 'installment-manager');
            $strings['searchMediaLabel'] = __('Search Images', 'installment-manager');
            $strings['noItemsFound'] = __('No payment proofs found.', 'installment-manager');
            $strings['insertIntoPost'] = __('Select as Payment Proof', 'installment-manager');
            $strings['allMediaItems'] = __('All Payment Proofs', 'installment-manager');
            $strings['allUploaded'] = __('Your Payment Proofs', 'installment-manager');
            $strings['maxFileSizeError'] = __('This file exceeds the maximum upload size for this site (10MB).', 'installment-manager');
        }

        return $strings;
    }

    /**
     * Set upload size limit for non-admin users.
     *
     * @since    1.0.0
     * @param    int       $size            Current upload size limit.
     * @param    int       $file_size       File size in bytes.
     * @param    int|null  $upload_id       Upload ID.
     * @return   int                        Modified upload size limit.
     */
    public function set_upload_size_limit($size, $file_size, $upload_id) {
        // For non-admin users, set upload size limit to 10MB
        if (!current_user_can('manage_installment_plans')) {
            // 10MB in bytes
            return 10 * 1024 * 1024;
        }

        return $size;
    }

    /**
     * Modify plupload config for frontend.
     *
     * @since    1.0.0
     * @param    array    $plupload_init    Plupload init config.
     * @return   array                      Modified config.
     */
    public function modify_plupload_config($plupload_init) {
        // For non-admin users, modify plupload config
        if (!current_user_can('manage_installment_plans')) {
            // Set max file size to 10MB
            $plupload_init['max_file_size'] = '10mb';

            // Only allow image files
            $plupload_init['filters']['mime_types'] = array(
                array(
                    'title' => __('Image files', 'installment-manager'),
                    'extensions' => 'jpg,jpeg,png,gif,webp,heic',
                ),
            );
        }

        return $plupload_init;
    }

    /**
     * Restrict attachment deletion to owner only.
     *
     * @since    1.0.0
     * @param    array     $allcaps    All capabilities of the user.
     * @param    array     $caps       Required capabilities.
     * @param    array     $args       Arguments.
     * @param    WP_User   $user       User object.
     * @return   array                 Modified capabilities.
     */
    public function restrict_attachment_deletion($allcaps, $caps, $args, $user) {
        // Only process delete_post capability
        if (isset($args[0]) && $args[0] === 'delete_post' && isset($args[2])) {
            $post_id = $args[2];
            $post = get_post($post_id);

            // If it's an attachment and user is not an admin
            if ($post && $post->post_type === 'attachment' && !current_user_can('manage_installment_plans')) {
                // Only allow deletion if user is the author
                if ($post->post_author != $user->ID) {
                    $allcaps['delete_post'] = false;
                }
            }
        }

        return $allcaps;
    }
}
