<?php
/**
 * Installment model class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Installment model class.
 */
class Installment_Manager_Installment {

    /**
     * Installment ID.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $id    Installment ID.
     */
    public $id;

    /**
     * Plan ID.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $plan_id    Plan ID.
     */
    public $plan_id;

    /**
     * Amount.
     *
     * @since    1.0.0
     * @access   public
     * @var      float    $amount    Amount.
     */
    public $amount;

    /**
     * Due date.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $due_date    Due date.
     */
    public $due_date;

    /**
     * Status.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $status    Status.
     */
    public $status;

    /**
     * Payment date.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $payment_date    Payment date.
     */
    public $payment_date;

    /**
     * Payment method.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $payment_method    Payment method.
     */
    public $payment_method;

    /**
     * Payment proof ID.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $payment_proof_id    Payment proof ID.
     */
    public $payment_proof_id;

    /**
     * Notes.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $notes    Notes.
     */
    public $notes;

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     * @param    array    $data    Installment data.
     */
    public function __construct($data = array()) {
        $this->id = isset($data['id']) ? intval($data['id']) : 0;
        $this->plan_id = isset($data['plan_id']) ? intval($data['plan_id']) : 0;
        $this->amount = isset($data['amount']) ? floatval($data['amount']) : 0;
        $this->due_date = isset($data['due_date']) ? $data['due_date'] : '';
        $this->status = isset($data['status']) ? $data['status'] : 'unpaid';
        $this->payment_date = isset($data['payment_date']) ? $data['payment_date'] : '';
        $this->payment_method = isset($data['payment_method']) ? $data['payment_method'] : '';
        $this->payment_proof_id = isset($data['payment_proof_id']) ? intval($data['payment_proof_id']) : 0;
        $this->notes = isset($data['notes']) ? $data['notes'] : '';
    }

    /**
     * Get installment by ID.
     *
     * @since    1.0.0
     * @param    int       $id    Installment ID.
     * @return   object|false     Installment object or false if not found.
     */
    public static function get($id) {
        $db_manager = new Installment_Manager_Database_Manager();
        $data = $db_manager->get_installment($id);

        if (!$data) {
            return false; // Return false instead of null to match expected return type
        }

        return new self($data);
    }

    /**
     * Get all installments.
     *
     * @since    1.0.0
     * @param    array     $args    Query arguments.
     * @return   array              Array of installment objects.
     */
    public static function get_all($args = array()) {
        $db_manager = new Installment_Manager_Database_Manager();
        $installments_data = $db_manager->get_installments($args);

        $installments = array();

        foreach ($installments_data as $data) {
            $installments[] = new self($data);
        }

        return $installments;
    }

    /**
     * Update installment.
     *
     * @since    1.0.0
     * @return   bool      True if successful, false otherwise.
     */
    public function update() {
        if (!$this->id) {
            return false;
        }

        $db_manager = new Installment_Manager_Database_Manager();

        $data = array(
            'status'           => $this->status,
            'payment_date'     => $this->payment_date,
            'payment_method'   => $this->payment_method,
            'payment_proof_id' => $this->payment_proof_id,
            'notes'            => $this->notes,
        );

        return $db_manager->update_installment($this->id, $data);
    }

    /**
     * Mark as paid.
     *
     * @since    1.0.0
     * @param    string    $payment_method    Payment method.
     * @param    int       $payment_proof_id  Payment proof ID.
     * @return   bool                         True if successful, false otherwise.
     */
    public function mark_as_paid($payment_method = '', $payment_proof_id = 0) {
        $this->status = 'paid';
        $this->payment_date = date('Y-m-d');

        if (!empty($payment_method)) {
            $this->payment_method = $payment_method;
        }

        if (!empty($payment_proof_id)) {
            $this->payment_proof_id = $payment_proof_id;
        }

        return $this->update();
    }

    /**
     * Mark as unpaid.
     *
     * @since    1.0.0
     * @return   bool      True if successful, false otherwise.
     */
    public function mark_as_unpaid() {
        $this->status = 'unpaid';
        $this->payment_date = '';
        $this->payment_method = '';
        $this->payment_proof_id = 0;

        return $this->update();
    }

    /**
     * Mark as under review.
     *
     * @since    1.0.0
     * @param    string    $payment_method    Payment method.
     * @param    int       $payment_proof_id  Payment proof ID.
     * @return   bool                         True if successful, false otherwise.
     */
    public function mark_as_review($payment_method = '', $payment_proof_id = 0) {
        $this->status = 'review';

        if (!empty($payment_method)) {
            $this->payment_method = $payment_method;
        }

        if (!empty($payment_proof_id)) {
            $this->payment_proof_id = $payment_proof_id;
        }

        return $this->update();
    }

    /**
     * Is overdue.
     *
     * @since    1.0.0
     * @return   bool      True if overdue, false otherwise.
     */
    public function is_overdue() {
        if ($this->status !== 'unpaid') {
            return false;
        }

        $today = new DateTime();
        $due_date = new DateTime($this->due_date);

        return $due_date < $today;
    }

    /**
     * Get status label.
     *
     * @since    1.0.0
     * @return   string    Status label.
     */
    public function get_status_label() {
        $labels = array(
            'unpaid' => __('Unpaid', 'installment-manager'),
            'paid'   => __('Paid', 'installment-manager'),
            'review' => __('Under Review', 'installment-manager'),
            'late'   => __('Late', 'installment-manager'),
        );

        return isset($labels[$this->status]) ? $labels[$this->status] : $this->status;
    }

    /**
     * Get payment method label.
     *
     * @since    1.0.0
     * @return   string    Payment method label.
     */
    public function get_payment_method_label() {
        $labels = array(
            'cash'      => __('Cash', 'installment-manager'),
            'visa'      => __('Visa/Mastercard', 'installment-manager'),
            'vodafone'  => __('Vodafone Cash', 'installment-manager'),
            'etisalat'  => __('Etisalat Cash', 'installment-manager'),
            'instapay'  => __('InstaPay', 'installment-manager'),
            'bank'      => __('Bank Transfer', 'installment-manager'),
            'other'     => __('Other', 'installment-manager'),
        );

        return isset($labels[$this->payment_method]) ? $labels[$this->payment_method] : $this->payment_method;
    }

    /**
     * Get payment proof URL.
     *
     * @since    1.0.0
     * @return   string    Payment proof URL.
     */
    public function get_payment_proof_url() {
        if (!$this->payment_proof_id) {
            return '';
        }

        if (function_exists('wp_get_attachment_url')) {
            return wp_get_attachment_url($this->payment_proof_id);
        } else {
            // Fallback if wp_get_attachment_url is not available
            global $wpdb;
            $attachment_table = $wpdb->prefix . 'posts';
            $attachment = $wpdb->get_var($wpdb->prepare("SELECT guid FROM $attachment_table WHERE ID = %d AND post_type = 'attachment'", $this->payment_proof_id));

            return $attachment ? $attachment : '';
        }
    }

    /**
     * Get formatted due date.
     *
     * @since    1.0.0
     * @return   string    Formatted due date.
     */
    public function get_formatted_due_date() {
        if (empty($this->due_date)) {
            return '';
        }

        if (function_exists('date_i18n') && function_exists('get_option')) {
            return date_i18n(get_option('date_format'), strtotime($this->due_date));
        } else {
            // Fallback if date_i18n is not available
            return date('Y-m-d', strtotime($this->due_date));
        }
    }

    /**
     * Get formatted payment date.
     *
     * @since    1.0.0
     * @return   string    Formatted payment date.
     */
    public function get_formatted_payment_date() {
        if (empty($this->payment_date)) {
            return '';
        }

        if (function_exists('date_i18n') && function_exists('get_option')) {
            return date_i18n(get_option('date_format'), strtotime($this->payment_date));
        } else {
            // Fallback if date_i18n is not available
            return date('Y-m-d', strtotime($this->payment_date));
        }
    }

    /**
     * Get formatted amount.
     *
     * @since    1.0.0
     * @return   string    Formatted amount.
     */
    public function get_formatted_amount() {
        $currency = get_option('im_currency', 'USD');
        $symbol = $this->get_currency_symbol($currency);

        return $symbol . number_format($this->amount, 2);
    }

    /**
     * Get currency symbol.
     *
     * @since    1.0.0
     * @param    string    $currency    Currency code.
     * @return   string                 Currency symbol.
     */
    private function get_currency_symbol($currency = '') {
        if (empty($currency)) {
            $currency = get_option('im_currency', 'USD');
        }

        $symbols = array(
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'EGP' => 'E£',
            'SAR' => 'SR',
            'AED' => 'د.إ',
        );

        return isset($symbols[$currency]) ? $symbols[$currency] : $currency;
    }
}
