<?php
/**
 * Plan model class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Plan model class.
 */
class Installment_Manager_Plan {

    /**
     * Plan ID.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $id    Plan ID.
     */
    public $id;

    /**
     * Customer ID.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $customer_id    Customer ID.
     */
    public $customer_id;

    /**
     * Product ID.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $product_id    Product ID.
     */
    public $product_id;

    /**
     * Total amount.
     *
     * @since    1.0.0
     * @access   public
     * @var      float    $total_amount    Total amount.
     */
    public $total_amount;

    /**
     * Down payment.
     *
     * @since    1.0.0
     * @access   public
     * @var      float    $down_payment    Down payment.
     */
    public $down_payment;

    /**
     * Installment count.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $installment_count    Installment count.
     */
    public $installment_count;

    /**
     * Installment amount.
     *
     * @since    1.0.0
     * @access   public
     * @var      float    $installment_amount    Installment amount.
     */
    public $installment_amount;

    /**
     * Payment frequency.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $payment_frequency    Payment frequency.
     */
    public $payment_frequency;

    /**
     * Start date.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $start_date    Start date.
     */
    public $start_date;

    /**
     * Status.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $status    Status.
     */
    public $status;

    /**
     * Notes.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $notes    Notes.
     */
    public $notes;

    /**
     * Installments.
     *
     * @since    1.0.0
     * @access   public
     * @var      array    $installments    Installments.
     */
    public $installments = array();

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     * @param    array    $data    Plan data.
     */
    public function __construct($data = array()) {
        $this->id = isset($data['id']) ? intval($data['id']) : 0;
        $this->customer_id = isset($data['customer_id']) ? intval($data['customer_id']) : 0;
        $this->product_id = isset($data['product_id']) ? intval($data['product_id']) : 0;
        $this->total_amount = isset($data['total_amount']) ? floatval($data['total_amount']) : 0;
        $this->down_payment = isset($data['down_payment']) ? floatval($data['down_payment']) : 0;
        $this->installment_count = isset($data['installment_count']) ? intval($data['installment_count']) : 1;
        $this->installment_amount = isset($data['installment_amount']) ? floatval($data['installment_amount']) : 0;
        $this->payment_frequency = isset($data['payment_frequency']) ? $data['payment_frequency'] : 'monthly';
        $this->start_date = isset($data['start_date']) ? $data['start_date'] : date('Y-m-d');
        $this->status = isset($data['status']) ? $data['status'] : 'active';
        $this->notes = isset($data['notes']) ? $data['notes'] : '';

        // Load installments if ID is set
        if ($this->id && empty($this->installments)) {
            $this->load_installments();
        }
    }

    /**
     * Load installments.
     *
     * @since    1.0.0
     */
    public function load_installments() {
        if (!$this->id) {
            return;
        }

        $db_manager = new Installment_Manager_Database_Manager();
        $installments_data = $db_manager->get_installments(array('plan_id' => $this->id));

        $this->installments = array();

        foreach ($installments_data as $data) {
            $this->installments[] = new Installment_Manager_Installment($data);
        }
    }

    /**
     * Calculate installment amount.
     *
     * @since    1.0.0
     * @return   float    Installment amount.
     */
    public function calculate_installment_amount() {
        if ($this->installment_count <= 0) {
            return 0;
        }

        $amount_to_pay = $this->total_amount - $this->down_payment;

        return $amount_to_pay / $this->installment_count;
    }

    /**
     * Get plan by ID.
     *
     * @since    1.0.0
     * @param    int       $id    Plan ID.
     * @return   object|false     Plan object or false if not found.
     */
    public static function get($id) {
        $db_manager = new Installment_Manager_Database_Manager();
        $data = $db_manager->get_plan($id);

        if (!$data) {
            return false; // Return false instead of null to match expected return type
        }

        return new self($data);
    }

    /**
     * Get all plans.
     *
     * @since    1.0.0
     * @param    array     $args    Query arguments.
     * @return   array              Array of plan objects.
     */
    public static function get_all($args = array()) {
        $db_manager = new Installment_Manager_Database_Manager();
        $plans_data = $db_manager->get_plans($args);

        $plans = array();

        foreach ($plans_data as $data) {
            $plans[] = new self($data);
        }

        return $plans;
    }

    /**
     * Save plan.
     *
     * @since    1.0.0
     * @param    bool      $recreate_installments    Whether to recreate installments.
     * @return   int                                 Plan ID.
     */
    public function save($recreate_installments = false) {
        $db_manager = new Installment_Manager_Database_Manager();

        $data = array(
            'id'               => $this->id,
            'customer_id'      => $this->customer_id,
            'product_id'       => $this->product_id,
            'total_amount'     => $this->total_amount,
            'down_payment'     => $this->down_payment,
            'installment_count' => $this->installment_count,
            'installment_amount' => $this->installment_amount,
            'payment_frequency' => $this->payment_frequency,
            'start_date'       => $this->start_date,
            'status'           => $this->status,
            'notes'            => $this->notes,
            'recreate_installments' => $recreate_installments,
        );

        $this->id = $db_manager->save_plan($data);

        return $this->id;
    }

    /**
     * Delete plan.
     *
     * @since    1.0.0
     * @return   bool      True if successful, false otherwise.
     */
    public function delete() {
        if (!$this->id) {
            return false;
        }

        $db_manager = new Installment_Manager_Database_Manager();

        return $db_manager->delete_plan($this->id);
    }

    /**
     * Get customer name.
     *
     * @since    1.0.0
     * @return   string    Customer name.
     */
    public function get_customer_name() {
        if (function_exists('get_userdata')) {
            $customer = get_userdata($this->customer_id);

            if ($customer) {
                return $customer->display_name;
            }
        } else {
            // Fallback if get_userdata is not available
            global $wpdb;
            $user_table = $wpdb->prefix . 'users';
            $user = $wpdb->get_row($wpdb->prepare("SELECT display_name FROM $user_table WHERE ID = %d", $this->customer_id));

            if ($user) {
                return $user->display_name;
            }
        }

        return __('Unknown Customer', 'installment-manager');
    }

    /**
     * Get customer email.
     *
     * @since    1.0.0
     * @return   string    Customer email.
     */
    public function get_customer_email() {
        if (function_exists('get_userdata')) {
            $customer = get_userdata($this->customer_id);

            if ($customer) {
                return $customer->user_email;
            }
        } else {
            // Fallback if get_userdata is not available
            global $wpdb;
            $user_table = $wpdb->prefix . 'users';
            $user = $wpdb->get_row($wpdb->prepare("SELECT user_email FROM $user_table WHERE ID = %d", $this->customer_id));

            if ($user) {
                return $user->user_email;
            }
        }

        return '';
    }

    /**
     * Get product name.
     *
     * @since    1.0.0
     * @return   string    Product name.
     */
    public function get_product_name() {
        $product = Installment_Manager_Product::get($this->product_id);

        if ($product) {
            return $product->name;
        }

        return __('Unknown Product', 'installment-manager');
    }

    /**
     * Get total paid amount.
     *
     * @since    1.0.0
     * @return   float    Total paid amount.
     */
    public function get_total_paid() {
        $total = $this->down_payment;

        foreach ($this->installments as $installment) {
            if ($installment->status === 'paid') {
                $total += $installment->amount;
            }
        }

        return $total;
    }

    /**
     * Get total remaining amount.
     *
     * @since    1.0.0
     * @return   float    Total remaining amount.
     */
    public function get_total_remaining() {
        return $this->total_amount - $this->get_total_paid();
    }

    /**
     * Get payment progress percentage.
     *
     * @since    1.0.0
     * @return   float    Payment progress percentage.
     */
    public function get_payment_progress() {
        if ($this->total_amount <= 0) {
            return 0;
        }

        return ($this->get_total_paid() / $this->total_amount) * 100;
    }

    /**
     * Get next installment.
     *
     * @since    1.0.0
     * @return   object|false    Next installment or false if none found.
     */
    public function get_next_installment() {
        foreach ($this->installments as $installment) {
            if ($installment->status === 'unpaid') {
                return $installment;
            }
        }

        return false; // Return false instead of null to match expected return type
    }

    /**
     * Get status label.
     *
     * @since    1.0.0
     * @return   string    Status label.
     */
    public function get_status_label() {
        $labels = array(
            'active'   => __('Active', 'installment-manager'),
            'completed' => __('Completed', 'installment-manager'),
            'cancelled' => __('Cancelled', 'installment-manager'),
        );

        return isset($labels[$this->status]) ? $labels[$this->status] : $this->status;
    }

    /**
     * Get payment frequency label.
     *
     * @since    1.0.0
     * @return   string    Payment frequency label.
     */
    public function get_payment_frequency_label() {
        $labels = array(
            'weekly'    => __('Weekly', 'installment-manager'),
            'biweekly'  => __('Bi-weekly', 'installment-manager'),
            'monthly'   => __('Monthly', 'installment-manager'),
            'quarterly' => __('Quarterly', 'installment-manager'),
        );

        return isset($labels[$this->payment_frequency]) ? $labels[$this->payment_frequency] : $this->payment_frequency;
    }
}
