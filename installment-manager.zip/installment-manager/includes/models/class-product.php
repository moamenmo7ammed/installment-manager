<?php
/**
 * Product model class.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Product model class.
 */
class Installment_Manager_Product {

    /**
     * Product ID.
     *
     * @since    1.0.0
     * @access   public
     * @var      int    $id    Product ID.
     */
    public $id;

    /**
     * Product name.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $name    Product name.
     */
    public $name;

    /**
     * Product description.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $description    Product description.
     */
    public $description;

    /**
     * Product base price.
     *
     * @since    1.0.0
     * @access   public
     * @var      float    $base_price    Product base price.
     */
    public $base_price;

    /**
     * Product profit option.
     *
     * @since    1.0.0
     * @access   public
     * @var      string    $profit_option    Product profit option.
     */
    public $profit_option;

    /**
     * Product profit value.
     *
     * @since    1.0.0
     * @access   public
     * @var      float    $profit_value    Product profit value.
     */
    public $profit_value;

    /**
     * Initialize the class.
     *
     * @since    1.0.0
     * @param    array    $data    Product data.
     */
    public function __construct($data = array()) {
        $this->id = isset($data['id']) ? intval($data['id']) : 0;
        $this->name = isset($data['name']) ? $data['name'] : '';
        $this->description = isset($data['description']) ? $data['description'] : '';
        $this->base_price = isset($data['base_price']) ? floatval($data['base_price']) : 0;
        $this->profit_option = isset($data['profit_option']) ? $data['profit_option'] : 'fixed';
        $this->profit_value = isset($data['profit_value']) ? floatval($data['profit_value']) : 0;
    }

    /**
     * Calculate total price with profit.
     *
     * @since    1.0.0
     * @return   float    Total price.
     */
    public function calculate_total_price() {
        $total = $this->base_price;

        if ($this->profit_option === 'fixed') {
            $total += $this->profit_value;
        } elseif ($this->profit_option === 'percentage') {
            $total += $this->base_price * $this->profit_value / 100;
        }

        return $total;
    }

    /**
     * Get product by ID.
     *
     * @since    1.0.0
     * @param    int       $id    Product ID.
     * @return   object|false     Product object or false if not found.
     */
    public static function get($id) {
        $db_manager = new Installment_Manager_Database_Manager();
        $data = $db_manager->get_product($id);

        if (!$data) {
            return false; // Return false instead of null to match expected return type
        }

        return new self($data);
    }

    /**
     * Get all products.
     *
     * @since    1.0.0
     * @param    array     $args    Query arguments.
     * @return   array              Array of product objects.
     */
    public static function get_all($args = array()) {
        $db_manager = new Installment_Manager_Database_Manager();
        $products_data = $db_manager->get_products($args);

        $products = array();

        foreach ($products_data as $data) {
            $products[] = new self($data);
        }

        return $products;
    }

    /**
     * Save product.
     *
     * @since    1.0.0
     * @return   int       Product ID.
     */
    public function save() {
        $db_manager = new Installment_Manager_Database_Manager();

        $data = array(
            'id'           => $this->id,
            'name'         => $this->name,
            'description'  => $this->description,
            'base_price'   => $this->base_price,
            'profit_option' => $this->profit_option,
            'profit_value' => $this->profit_value,
        );

        $this->id = $db_manager->save_product($data);

        return $this->id;
    }

    /**
     * Delete product.
     *
     * @since    1.0.0
     * @return   bool      True if successful, false otherwise.
     */
    public function delete() {
        if (!$this->id) {
            return false;
        }

        $db_manager = new Installment_Manager_Database_Manager();

        return $db_manager->delete_product($this->id);
    }
}
