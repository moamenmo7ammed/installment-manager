<?php
/**
 * Customer portal view.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}
?>

<div class="im-customer-portal container py-4">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm mb-4">
                <div class="card-header text-white" style="background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));">
                    <h2 class="h4 mb-0"><i class="bi bi-credit-card-2-front me-2"></i><?php echo esc_html($atts['title']); ?></h2>
                </div>

                <?php if (empty($plans)) : ?>
                    <div class="card-body text-center py-5">
                        <i class="bi bi-exclamation-circle text-muted" style="font-size: 3rem;"></i>
                        <p class="mt-3 mb-0"><?php echo esc_html__('You have no installment plans.', 'installment-manager'); ?></p>
                    </div>
                <?php else : ?>
                    <div class="card-body">
                        <div class="mb-4">
                            <h3 class="h5 mb-3"><?php echo esc_html__('Your Installment Plans', 'installment-manager'); ?></h3>
                            <div class="row g-3">
                                <?php foreach ($plans as $plan) :
                                    // Get first, next, and last installment dates
                                    $db_manager = new Installment_Manager_Database_Manager();
                                    $plan_details = $db_manager->get_plan($plan['id']);
                                    $installments = $plan_details['installments'];

                                    $first_installment_date = '';
                                    $next_installment_date = '';
                                    $last_installment_date = '';

                                    if (!empty($installments)) {
                                        // Sort installments by due date
                                        usort($installments, function($a, $b) {
                                            return strtotime($a['due_date']) - strtotime($b['due_date']);
                                        });

                                        // First installment date
                                        $first_installment_date = date_i18n(get_option('date_format'), strtotime($installments[0]['due_date']));

                                        // Last installment date
                                        $last_installment_date = date_i18n(get_option('date_format'), strtotime(end($installments)['due_date']));

                                        // Next installment date (first unpaid installment)
                                        $next_installment = null;
                                        foreach ($installments as $installment) {
                                            if ($installment['status'] === 'unpaid') {
                                                $next_installment = $installment;
                                                break;
                                            }
                                        }

                                        if ($next_installment) {
                                            $next_installment_date = date_i18n(get_option('date_format'), strtotime($next_installment['due_date']));
                                        } else {
                                            $next_installment_date = __('All installments paid', 'installment-manager');
                                        }
                                    }
                                ?>
                                    <div class="col-md-6 col-lg-4">
                                        <div class="card h-100 im-plan-card" data-plan-id="<?php echo esc_attr($plan['id']); ?>">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo esc_html($plan['product_name']); ?></h5>
                                                <div class="card-text">
                                                    <div class="d-flex justify-content-between mb-2">
                                                        <span class="text-muted"><?php echo esc_html__('Total Amount:', 'installment-manager'); ?></span>
                                                        <span class="fw-bold"><?php echo esc_html(Installment_Manager_Helper_Functions::format_price($plan['total_amount'])); ?></span>
                                                    </div>
                                                    <div class="d-flex justify-content-between mb-2">
                                                        <span class="text-muted"><?php echo esc_html__('First Installment:', 'installment-manager'); ?></span>
                                                        <span><?php echo esc_html($first_installment_date); ?></span>
                                                    </div>
                                                    <div class="d-flex justify-content-between mb-2">
                                                        <span class="text-muted"><?php echo esc_html__('Next Installment:', 'installment-manager'); ?></span>
                                                        <span><?php echo esc_html($next_installment_date); ?></span>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <span class="text-muted"><?php echo esc_html__('Last Installment:', 'installment-manager'); ?></span>
                                                        <span><?php echo esc_html($last_installment_date); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-footer bg-white border-top-0">
                                                <button class="btn btn-primary btn-sm w-100 im-view-plan-details">
                                                    <i class="bi bi-eye me-1"></i><?php echo esc_html__('View Details', 'installment-manager'); ?>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div id="im-plan-details" class="mt-4" style="display: none;">
                            <div class="im-loading text-center py-5">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden"><?php echo esc_html__('Loading...', 'installment-manager'); ?></span>
                                </div>
                                <p class="mt-3"><?php echo esc_html__('Loading plan details...', 'installment-manager'); ?></p>
                            </div>

                            <div class="im-plan-content" style="display: none;">
                                <!-- Plan Summary -->
                                <div class="card shadow-sm mb-4">
                                    <div class="card-header bg-light">
                                        <h3 class="h5 mb-0"><i class="bi bi-info-circle me-2"></i><?php echo esc_html__('Plan Summary', 'installment-manager'); ?></h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-md-4">
                                                <div class="card h-100">
                                                    <div class="card-body">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Product', 'installment-manager'); ?></h6>
                                                        <p class="card-text fw-bold im-product-name"></p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="card h-100">
                                                    <div class="card-body">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Total Amount', 'installment-manager'); ?></h6>
                                                        <p class="card-text fw-bold im-total-amount"></p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="card h-100">
                                                    <div class="card-body">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Down Payment', 'installment-manager'); ?></h6>
                                                        <p class="card-text fw-bold im-down-payment"></p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="card h-100">
                                                    <div class="card-body">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Installments', 'installment-manager'); ?></h6>
                                                        <p class="card-text fw-bold im-installments"></p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="card h-100">
                                                    <div class="card-body">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Start Date', 'installment-manager'); ?></h6>
                                                        <p class="card-text fw-bold im-start-date"></p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="card h-100">
                                                    <div class="card-body">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Status', 'installment-manager'); ?></h6>
                                                        <p class="card-text im-status"></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Payment Progress -->
                                <div class="card shadow-sm mb-4">
                                    <div class="card-header bg-light">
                                        <h3 class="h5 mb-0"><i class="bi bi-graph-up me-2"></i><?php echo esc_html__('Payment Progress', 'installment-manager'); ?></h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="progress mb-4" style="height: 25px;">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated im-progress-fill" role="progressbar" style="width: 0%"></div>
                                        </div>

                                        <div class="row text-center g-3">
                                            <div class="col-md-4">
                                                <div class="card bg-light">
                                                    <div class="card-body py-3">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Total Paid', 'installment-manager'); ?></h6>
                                                        <p class="card-text h5 text-success im-total-paid"></p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="card bg-light">
                                                    <div class="card-body py-3">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Remaining', 'installment-manager'); ?></h6>
                                                        <p class="card-text h5 text-danger im-total-remaining"></p>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="card bg-light">
                                                    <div class="card-body py-3">
                                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo esc_html__('Progress', 'installment-manager'); ?></h6>
                                                        <p class="card-text h5 text-primary im-progress-percentage"></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Installments -->
                                <div class="card shadow-sm">
                                    <div class="card-header bg-light">
                                        <h3 class="h5 mb-0"><i class="bi bi-calendar-check me-2"></i><?php echo esc_html__('Installments', 'installment-manager'); ?></h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th><?php echo esc_html__('Due Date', 'installment-manager'); ?></th>
                                                        <th><?php echo esc_html__('Amount', 'installment-manager'); ?></th>
                                                        <th><?php echo esc_html__('Status', 'installment-manager'); ?></th>
                                                        <th><?php echo esc_html__('Payment Date', 'installment-manager'); ?></th>
                                                        <th><?php echo esc_html__('Payment Method', 'installment-manager'); ?></th>
                                                        <th><?php echo esc_html__('Payment Proof', 'installment-manager'); ?></th>
                                                        <th><?php echo esc_html__('Actions', 'installment-manager'); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody id="im-installments-body">
                                                    <!-- Installments will be loaded here -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="im-payment-modal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header text-white" style="background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));">
                <h5 class="modal-title" id="paymentModalLabel"><i class="bi bi-upload me-2"></i><?php echo esc_html__('Upload Payment Proof', 'installment-manager'); ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="im-payment-form" class="needs-validation" novalidate>
                    <input type="hidden" id="im-installment-id" name="installment_id" value="0">

                    <div class="mb-3">
                        <label for="im-payment-method" class="form-label"><?php echo esc_html__('Payment Method', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                        <select id="im-payment-method" name="payment_method" class="form-select" required>
                            <option value="" disabled selected><?php echo esc_html__('Select payment method...', 'installment-manager'); ?></option>
                            <?php
                            $payment_methods = get_option('im_payment_methods', array(
                                'cash' => __('Cash', 'installment-manager'),
                                'visa' => __('Visa/Mastercard', 'installment-manager'),
                                'vodafone' => __('Vodafone Cash', 'installment-manager'),
                                'etisalat' => __('Etisalat Cash', 'installment-manager'),
                                'instapay' => __('InstaPay', 'installment-manager'),
                                'bank' => __('Bank Transfer', 'installment-manager'),
                                'other' => __('Other', 'installment-manager'),
                            ));

                            foreach ($payment_methods as $code => $name) :
                            ?>
                                <option value="<?php echo esc_attr($code); ?>"><?php echo esc_html($name); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">
                            <?php echo esc_html__('Please select a payment method.', 'installment-manager'); ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="im-payment-proof" class="form-label"><?php echo esc_html__('Payment Proof', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                        <div class="mb-3">
                            <input type="file" class="form-control" id="im-payment-proof-file" name="payment_proof_file" accept="image/*" required>
                            <input type="hidden" id="im-payment-proof-id" name="payment_proof_id" value="0">
                            <div class="form-text">
                                <?php echo esc_html__('Accepted formats: JPG, PNG, GIF. Max size: 10MB', 'installment-manager'); ?>
                            </div>
                            <div class="invalid-feedback">
                                <?php echo esc_html__('Please select a payment proof image.', 'installment-manager'); ?>
                            </div>
                        </div>
                        <div id="im-proof-preview" class="mt-2 border rounded p-2 text-center" style="display: none;">
                            <!-- Preview will be shown here -->
                        </div>
                        <div id="im-upload-progress" class="progress mt-2" style="display: none;">
                            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%"></div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-circle me-2"></i><?php echo esc_html__('Cancel', 'installment-manager'); ?>
                </button>
                <button type="button" id="im-submit-payment" class="btn btn-primary">
                    <i class="bi bi-check-circle me-2"></i><?php echo esc_html__('Submit Payment', 'installment-manager'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Add hover effect to plan cards
    $('.im-plan-card').hover(
        function() {
            $(this).addClass('shadow-sm');
            $(this).css('transform', 'translateY(-5px)');
        },
        function() {
            $(this).removeClass('shadow-sm');
            $(this).css('transform', 'translateY(0)');
        }
    );

    // Load plan details when a plan card is clicked
    $('.im-view-plan-details').on('click', function() {
        var planId = $(this).closest('.im-plan-card').data('plan-id');

        if (!planId) {
            return;
        }

        // Scroll to plan details
        $('html, body').animate({
            scrollTop: $('#im-plan-details').offset().top - 20
        }, 500);

        $('#im-plan-details').fadeIn();
        $('#im-plan-details .im-loading').show();
        $('#im-plan-details .im-plan-content').hide();

        $.ajax({
            url: imPublicData.ajaxUrl,
            type: 'GET',
            data: {
                action: 'im_get_plan_details',
                plan_id: planId,
                nonce: imPublicData.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayPlanDetails(response.data.plan);
                } else {
                    // Show Bootstrap alert instead of browser alert
                    var alertHtml = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
                        '<i class="bi bi-exclamation-triangle-fill me-2"></i>' + response.data.message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                        '</div>';

                    $('#im-plan-details').html(alertHtml).show();
                }
            },
            error: function() {
                // Show Bootstrap alert instead of browser alert
                var alertHtml = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
                    '<i class="bi bi-exclamation-triangle-fill me-2"></i>Error loading plan details. Please try again.' +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                    '</div>';

                $('#im-plan-details').html(alertHtml).show();
            }
        });
    });

    // Display plan details
    function displayPlanDetails(plan) {
        // Plan summary
        $('.im-product-name').text(plan.product_name);
        $('.im-total-amount').text(imPublicData.currency + Number(plan.total_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        $('.im-down-payment').text(imPublicData.currency + Number(plan.down_payment).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        $('.im-installments').text(plan.installment_count + ' x ' + imPublicData.currency + Number(plan.installment_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        $('.im-start-date').text(new Date(plan.start_date).toLocaleDateString());

        // Status
        var statusLabels = {
            'active': imPublicData.strings.active,
            'completed': imPublicData.strings.completed,
            'cancelled': imPublicData.strings.cancelled
        };

        var statusClasses = {
            'active': 'primary',
            'completed': 'success',
            'cancelled': 'danger'
        };

        var statusClass = statusClasses[plan.status] || 'secondary';
        var statusLabel = statusLabels[plan.status] || plan.status;

        $('.im-status').html('<span class="badge bg-' + statusClass + '">' + statusLabel + '</span>');

        // Calculate payment progress
        var totalPaid = parseFloat(plan.down_payment);
        var totalAmount = parseFloat(plan.total_amount);

        plan.installments.forEach(function(installment) {
            if (installment.status === 'paid') {
                totalPaid += parseFloat(installment.amount);
            }
        });

        var totalRemaining = totalAmount - totalPaid;
        var progressPercentage = (totalPaid / totalAmount) * 100;

        // Update progress bar
        $('.im-progress-fill').css('width', progressPercentage + '%')
            .attr('aria-valuenow', progressPercentage)
            .text(Math.round(progressPercentage) + '%');

        $('.im-total-paid').text(imPublicData.currency + Number(totalPaid).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        $('.im-total-remaining').text(imPublicData.currency + Number(totalRemaining).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
        $('.im-progress-percentage').text(Number(progressPercentage).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) + '%');

        // Installments
        var installmentsHtml = '';

        plan.installments.forEach(function(installment) {
            var isOverdue = (installment.status === 'unpaid' && new Date(installment.due_date) < new Date());
            var statusClass = isOverdue ? 'danger' :
                              (installment.status === 'paid' ? 'success' :
                              (installment.status === 'review' ? 'info' :
                              (installment.status === 'unpaid' ? 'warning' : 'secondary')));

            var statusLabels = {
                'unpaid': imPublicData.strings.unpaid,
                'paid': imPublicData.strings.paid,
                'review': imPublicData.strings.underReview,
                'late': imPublicData.strings.late
            };

            var statusLabel = isOverdue ? statusLabels['late'] : (statusLabels[installment.status] || installment.status);

            // Get payment method labels from PHP
            var paymentMethodLabels = <?php echo json_encode(get_option('im_payment_methods', array(
                'cash' => __('Cash', 'installment-manager'),
                'visa' => __('Visa/Mastercard', 'installment-manager'),
                'vodafone' => __('Vodafone Cash', 'installment-manager'),
                'etisalat' => __('Etisalat Cash', 'installment-manager'),
                'instapay' => __('InstaPay', 'installment-manager'),
                'bank' => __('Bank Transfer', 'installment-manager'),
                'other' => __('Other', 'installment-manager'),
            ))); ?>;

            installmentsHtml += '<tr>';
            installmentsHtml += '<td>' + installment.due_date_formatted + '</td>';
            installmentsHtml += '<td>' + installment.amount_formatted + '</td>';
            installmentsHtml += '<td><span class="badge bg-' + statusClass + '">' + statusLabel + '</span></td>';
            installmentsHtml += '<td>' + (installment.payment_date_formatted || '&mdash;') + '</td>';
            installmentsHtml += '<td>' + (installment.payment_method ? (paymentMethodLabels[installment.payment_method] || installment.payment_method) : '&mdash;') + '</td>';

            if (installment.payment_proof_url) {
                installmentsHtml += '<td><a href="' + installment.payment_proof_url + '" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye me-1"></i>' + imPublicData.strings.viewProof + '</a></td>';
            } else {
                installmentsHtml += '<td>&mdash;</td>';
            }

            if (installment.status === 'unpaid') {
                installmentsHtml += '<td><button class="btn btn-sm btn-primary im-upload-payment" data-id="' + installment.id + '" data-bs-toggle="modal" data-bs-target="#im-payment-modal"><i class="bi bi-upload me-1"></i>' + imPublicData.strings.uploadPayment + '</button></td>';
            } else {
                installmentsHtml += '<td>&mdash;</td>';
            }

            installmentsHtml += '</tr>';
        });

        $('#im-installments-body').html(installmentsHtml);

        // Show plan content
        $('#im-plan-details .im-loading').hide();
        $('#im-plan-details .im-plan-content').show();

        // Upload payment button
        $('.im-upload-payment').on('click', function() {
            var installmentId = $(this).data('id');

            $('#im-installment-id').val(installmentId);
            $('#im-payment-method').val('');
            $('#im-payment-proof-id').val(0);
            $('#im-proof-preview').empty().hide();

            // Bootstrap modal is handled by data attributes
        });
    }

    // Initialize Bootstrap modal
    var paymentModal = new bootstrap.Modal(document.getElementById('im-payment-modal'), {
        backdrop: 'static',
        keyboard: false
    });

    // Handle file input change for payment proof
    $('#im-payment-proof-file').on('change', function(e) {
        var file = this.files[0];

        if (file) {
            // Validate file type
            var fileType = file.type;
            var validImageTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

            if (validImageTypes.indexOf(fileType) === -1) {
                // Invalid file type
                alert(imPublicData.strings.invalidFileType || 'Please select a valid image file (JPG, PNG, GIF, WEBP).');
                $(this).val('');
                $('#im-proof-preview').hide();
                return;
            }

            // Validate file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                alert(imPublicData.strings.fileTooLarge || 'The selected file is too large. Maximum size is 10MB.');
                $(this).val('');
                $('#im-proof-preview').hide();
                return;
            }

            // Show preview
            var reader = new FileReader();
            reader.onload = function(e) {
                var previewHtml = '<img src="' + e.target.result + '" alt="Payment Proof" class="img-fluid" style="max-height: 200px;">';
                $('#im-proof-preview').html(previewHtml).show();
            };
            reader.readAsDataURL(file);
        } else {
            $('#im-proof-preview').hide();
        }
    });

    // Submit payment
    $('#im-submit-payment').on('click', function() {
        // Form validation
        var form = document.getElementById('im-payment-form');

        if (!form.checkValidity()) {
            // Trigger Bootstrap validation
            form.classList.add('was-validated');
            return;
        }

        // Check if file is selected
        var fileInput = document.getElementById('im-payment-proof-file');
        if (!fileInput.files || !fileInput.files[0]) {
            alert(imPublicData.strings.selectProofImage || 'Please select a payment proof image.');
            return;
        }

        // Create FormData object for file upload
        var formData = new FormData(form);
        formData.append('action', 'im_upload_payment_proof');
        formData.append('nonce', imPublicData.nonce);

        // Show loading state
        var submitBtn = $(this);
        var originalHtml = submitBtn.html();
        submitBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + imPublicData.strings.processing);
        submitBtn.prop('disabled', true);

        // Show progress bar
        $('#im-upload-progress').show();
        $('#im-upload-progress .progress-bar').css('width', '0%');

        $.ajax({
            url: imPublicData.ajaxUrl,
            type: 'POST',
            data: formData,
            contentType: false, // Required for file upload
            processData: false, // Required for file upload
            cache: false,       // Disable caching
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                // Upload progress
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = (evt.loaded / evt.total) * 100;
                        $('#im-upload-progress .progress-bar').css('width', percentComplete + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                // Hide modal
                paymentModal.hide();

                // Reset button and progress
                submitBtn.html(originalHtml);
                submitBtn.prop('disabled', false);
                $('#im-upload-progress').hide();

                if (response.success) {
                    // Show success message
                    var successHtml = '<div class="alert alert-success alert-dismissible fade show" role="alert">' +
                        '<i class="bi bi-check-circle-fill me-2"></i>' + response.data.message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                        '</div>';

                    $('#im-plan-details').prepend(successHtml);

                    // Refresh plan details by reloading the current plan
                    var planId = $('.im-plan-card.active').data('plan-id');
                    if (planId) {
                        $.ajax({
                            url: imPublicData.ajaxUrl,
                            type: 'GET',
                            data: {
                                action: 'im_get_plan_details',
                                plan_id: planId,
                                nonce: imPublicData.nonce
                            },
                            success: function(response) {
                                if (response.success) {
                                    displayPlanDetails(response.data.plan);
                                }
                            }
                        });
                    }
                } else {
                    // Show error message
                    var errorHtml = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
                        '<i class="bi bi-exclamation-triangle-fill me-2"></i>' + response.data.message +
                        '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                        '</div>';

                    $('#im-plan-details').prepend(errorHtml);
                }
            },
            error: function() {
                // Hide modal
                paymentModal.hide();

                // Reset button and progress
                submitBtn.html(originalHtml);
                submitBtn.prop('disabled', false);
                $('#im-upload-progress').hide();

                // Show error message
                var errorHtml = '<div class="alert alert-danger alert-dismissible fade show" role="alert">' +
                    '<i class="bi bi-exclamation-triangle-fill me-2"></i>Error processing your request. Please try again.' +
                    '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                    '</div>';

                $('#im-plan-details').prepend(errorHtml);
            }
        });
    });
});
</script>
