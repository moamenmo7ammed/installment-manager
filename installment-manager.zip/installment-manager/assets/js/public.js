/**
 * Public scripts for Installment Manager.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

(function($) {
    'use strict';

    /**
     * Initialize all public functionality.
     */
    function initPublic() {
        // Initialize Select2 for all select elements with the 'select2' class
        if ($.fn.select2) {
            $('.select2').select2();
        }

        // Fix for media library in WordPress
        initMediaLibraryFixes();
    }

    /**
     * Initialize fixes for WordPress media library
     */
    function initMediaLibraryFixes() {
        // Listen for media modal opening
        $(document).on('click', '#im-upload-proof', function() {
            // Set a timeout to fix any stuck spinners
            setTimeout(function() {
                $('.media-frame-content .spinner.is-active').addClass('timeout-reached');
            }, 5000);

            // Fix for media frame content visibility
            $(document).on('media:frame:content:ready', function() {
                $('.media-frame-content').css('overflow', 'auto');
                $('.attachments-browser .attachments').css({
                    'position': 'relative',
                    'overflow': 'auto'
                });
            });

            // Fix for media modal in RTL mode
            if ($('html').attr('lang') === 'ar') {
                $(document).on('media:frame:ready', function() {
                    $('.media-modal-content').css('direction', 'rtl');
                    $('.media-frame-content').css({
                        'left': '0',
                        'right': '0',
                        'width': 'auto'
                    });
                });
            }
        });
    }

    // Initialize when document is ready
    $(document).ready(function() {
        initPublic();
    });

})(jQuery);
