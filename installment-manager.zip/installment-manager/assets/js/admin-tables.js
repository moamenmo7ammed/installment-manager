/**
 * Admin tables enhancement script
 * 
 * @since      1.0.0
 * @package    Installment_Manager
 */

(function($) {
    'use strict';

    /**
     * Check if table has horizontal scroll and add class
     */
    function checkTableScroll() {
        $('.table-responsive').each(function() {
            var $this = $(this);
            var tableWidth = $this.find('table').width();
            var containerWidth = $this.width();
            
            if (tableWidth > containerWidth) {
                $this.addClass('has-scroll');
            } else {
                $this.removeClass('has-scroll');
            }
        });
    }

    /**
     * Initialize table enhancements
     */
    function initTables() {
        // Check for scroll on load
        checkTableScroll();
        
        // Check for scroll on window resize
        $(window).on('resize', function() {
            checkTableScroll();
        });
        
        // Check for scroll when scrolling the table
        $('.table-responsive').on('scroll', function() {
            var $this = $(this);
            if ($this.scrollLeft() > 0) {
                $this.addClass('is-scrolling');
            } else {
                $this.removeClass('is-scrolling');
            }
        });
    }

    // Initialize when document is ready
    $(document).ready(function() {
        initTables();
    });

})(jQuery);
