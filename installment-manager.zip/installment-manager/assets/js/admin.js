/**
 * Admin scripts for Installment Manager.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

(function($) {
    'use strict';
    
    /**
     * Initialize all admin functionality.
     */
    function initAdmin() {
        // Initialize Select2 for all select elements with the 'select2' class
        if ($.fn.select2) {
            $('.select2').select2();
        }
    }
    
    // Initialize when document is ready
    $(document).ready(function() {
        initAdmin();
    });
    
})(jQuery);
