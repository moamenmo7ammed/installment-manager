<?php
/**
 * Plugin Name: Installment Manager
 * Plugin URI: https://future-way.online
 * Description: A comprehensive WordPress plugin for managing installment plans and payment schedules.
 * Version: 2.1.0
 * Author: FWTeam
 * Author URI: https://mo2men.site
 * Text Domain: installment-manager
 * Domain Path: /languages
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Make sure we have access to WordPress functions
if (!function_exists('add_action')) {
    require_once dirname(__FILE__) . '/../../../wp-load.php';
}

// Define plugin constants
define('INSTALLMENT_MANAGER_VERSION', '2.1.0');
define('INSTALLMENT_MANAGER_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Make sure plugin URL is correctly defined
$plugin_url = plugin_dir_url(__FILE__);
if (empty($plugin_url) || $plugin_url === '/') {
    // Fallback if plugin_dir_url fails
    $site_url = site_url();
    $plugin_dir = basename(dirname(__FILE__));
    $plugin_url = trailingslashit($site_url . '/wp-content/plugins/' . $plugin_dir);
}
define('INSTALLMENT_MANAGER_PLUGIN_URL', $plugin_url);
define('INSTALLMENT_MANAGER_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Define WordPress constants if not already defined
if (!defined('ARRAY_A')) {
    define('ARRAY_A', 'ARRAY_A');
}

// Include WordPress function fallbacks only for development/IDE compatibility
// In a normal WordPress environment, these functions are already defined
// and including them would cause conflicts
if (!defined('WPINC')) {
    require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/wp-functions.php';
} else {
    // Make sure we're not in a WordPress environment that's missing these functions
    if (!function_exists('wp_enqueue_style')) {
        require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/wp-functions.php';
    }
}

// Include the utility class
require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-utility.php';

// Include the core plugin class
require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-installment-manager.php';

// Fix for PHP 8.1+ deprecation warnings
if (!function_exists('im_fix_strip_tags')) {
    /**
     * Wrapper for strip_tags that handles null values
     * This fixes the PHP 8.1+ deprecation warning
     */
    function im_fix_strip_tags($string) {
        return strip_tags(Installment_Manager_Utility::safe_string($string));
    }

    // Override WordPress strip_tags function if it's causing deprecation warnings
    if (!function_exists('strip_tags_filter')) {
        function strip_tags_filter($string) {
            return im_fix_strip_tags($string);
        }
        add_filter('strip_tags', 'strip_tags_filter');
    }
}

// Fix for strpos deprecation warning
if (!function_exists('im_fix_strpos')) {
    /**
     * Wrapper for strpos that handles null values
     * This fixes the PHP 8.1+ deprecation warning
     */
    function im_fix_strpos($haystack, $needle, $offset = 0) {
        return strpos(Installment_Manager_Utility::safe_string($haystack), $needle, $offset);
    }

    // Override WordPress strpos function if it's causing deprecation warnings
    if (!function_exists('strpos_filter')) {
        function strpos_filter($haystack, $needle, $offset = 0) {
            return im_fix_strpos($haystack, $needle, $offset);
        }
        add_filter('strpos', 'strpos_filter');
    }
}

// Fix for str_replace deprecation warning
if (!function_exists('im_fix_str_replace')) {
    /**
     * Wrapper for str_replace that handles null values
     * This fixes the PHP 8.1+ deprecation warning
     */
    function im_fix_str_replace($search, $replace, $subject, $count = null) {
        if (is_array($subject)) {
            foreach ($subject as $key => $val) {
                $subject[$key] = Installment_Manager_Utility::safe_string($val);
            }
        } else {
            $subject = Installment_Manager_Utility::safe_string($subject);
        }
        return str_replace($search, $replace, $subject, $count);
    }

    // Override WordPress str_replace function if it's causing deprecation warnings
    if (!function_exists('str_replace_filter')) {
        function str_replace_filter($search, $replace, $subject, $count = null) {
            return im_fix_str_replace($search, $replace, $subject, $count);
        }
        add_filter('str_replace', 'str_replace_filter');
    }
}

/**
 * Begins execution of the plugin.
 */
function run_installment_manager() {
    $plugin = new Installment_Manager();
    $plugin->run();
}

// Activation hook
register_activation_hook(__FILE__, 'installment_manager_activate');
function installment_manager_activate() {
    require_once INSTALLMENT_MANAGER_PLUGIN_DIR . 'includes/class-database-manager.php';
    $database_manager = new Installment_Manager_Database_Manager();
    $database_manager->create_tables();

    // Add capabilities to administrator role
    $admin_role = get_role('administrator');
    if ($admin_role) {
        $admin_role->add_cap('manage_installment_plans');
    }

    // Flush rewrite rules
    flush_rewrite_rules();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'installment_manager_deactivate');
function installment_manager_deactivate() {
    // Remove capabilities from administrator role
    $admin_role = get_role('administrator');
    if ($admin_role) {
        $admin_role->remove_cap('manage_installment_plans');
    }

    // Flush rewrite rules
    flush_rewrite_rules();
}

// Run the plugin
run_installment_manager();
