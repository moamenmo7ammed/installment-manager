<?php
/**
 * Plans admin view.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}
?>

<div class="wrap">
    <div class="im-container">
        <div class="im-header mb-4 d-flex justify-content-between align-items-center">
            <h2><i class="bi bi-calendar-check me-2"></i><?php echo esc_html__('Installment Plans', 'installment-manager'); ?></h2>
            <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-edit-plan')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i><?php echo esc_html__('Add New Plan', 'installment-manager'); ?>
            </a>
        </div>

        <!-- Plans List Card -->
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-list-ul me-2"></i><?php echo esc_html__('Plans List', 'installment-manager'); ?></h5>
            </div>
            <div class="card-body">
                <?php if (empty($plans)) : ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i><?php echo esc_html__('No plans found.', 'installment-manager'); ?>
                    </div>
                <?php else : ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" style="width: 100% !important; table-layout: auto !important;">
                            <thead class="table-light">
                                <tr>
                                    <th><?php echo esc_html__('ID', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Customer', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Product', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Total Amount', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Installments', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Start Date', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Status', 'installment-manager'); ?></th>
                                    <th class="text-end"><?php echo esc_html__('Actions', 'installment-manager'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($plans as $plan) : ?>
                                    <tr>
                                        <td><?php echo esc_html($plan['id']); ?></td>
                                        <td>
                                            <strong><?php echo esc_html($plan['customer_name']); ?></strong>
                                            <div class="small text-muted"><?php echo esc_html($plan['customer_email']); ?></div>
                                        </td>
                                        <td><?php echo esc_html($plan['product_name']); ?></td>
                                        <td><?php echo esc_html(Installment_Manager_Helper_Functions::format_price($plan['total_amount'])); ?></td>
                                        <td>
                                            <span class="badge bg-info">
                                                <?php
                                                echo esc_html(sprintf(
                                                    __('%d x %s', 'installment-manager'),
                                                    $plan['installment_count'],
                                                    Installment_Manager_Helper_Functions::format_price($plan['installment_amount'])
                                                ));
                                                ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($plan['start_date']))); ?></td>
                                        <td>
                                            <?php
                                            $status_class = Installment_Manager_Helper_Functions::get_status_class($plan['status'], 'plan');
                                            $status_label = Installment_Manager_Helper_Functions::get_status_label($plan['status'], 'plan');
                                            ?>
                                            <span class="badge bg-<?php echo esc_attr($status_class); ?>">
                                                <?php echo esc_html($status_label); ?>
                                            </span>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group">
                                                <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-plan-details&id=' . $plan['id'])); ?>" class="btn btn-sm btn-primary">
                                                    <i class="bi bi-eye me-1"></i><?php echo esc_html__('View', 'installment-manager'); ?>
                                                </a>
                                                <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-edit-plan&id=' . $plan['id'])); ?>" class="btn btn-sm btn-info">
                                                    <i class="bi bi-pencil-square me-1"></i><?php echo esc_html__('Edit', 'installment-manager'); ?>
                                                </a>
                                                <button class="btn btn-sm btn-danger im-delete-plan" data-id="<?php echo esc_attr($plan['id']); ?>">
                                                    <i class="bi bi-trash me-1"></i><?php echo esc_html__('Delete', 'installment-manager'); ?>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Delete plan - use Bootstrap modal instead of confirm
    $('.im-delete-plan').on('click', function() {
        var planId = $(this).data('id');
        var planName = $(this).closest('tr').find('td:nth-child(3)').text().trim();
        var customerName = $(this).closest('tr').find('td:nth-child(2) strong').text().trim();

        // Create modal if it doesn't exist
        if ($('#delete-plan-modal').length === 0) {
            var modalHtml = `
                <div class="modal fade" id="delete-plan-modal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title"><i class="bi bi-exclamation-triangle me-2"></i>${imAdminData.strings.confirmDelete}</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="delete-confirm-message"></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    <i class="bi bi-x-circle me-2"></i><?php echo esc_js(__('Cancel', 'installment-manager')); ?>
                                </button>
                                <button type="button" class="btn btn-danger" id="confirm-delete-plan">
                                    <i class="bi bi-trash me-2"></i><?php echo esc_js(__('Delete', 'installment-manager')); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            $('body').append(modalHtml);

            // Handle delete confirmation
            $('#confirm-delete-plan').on('click', function() {
                var deleteId = $('#delete-plan-modal').data('plan-id');

                // Show loading state
                var $btn = $(this);
                var originalHtml = $btn.html();
                $btn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + originalHtml);
                $btn.prop('disabled', true);

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'im_delete_plan',
                        id: deleteId,
                        nonce: imAdminData.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            // Hide modal
                            var deleteModal = bootstrap.Modal.getInstance(document.getElementById('delete-plan-modal'));
                            deleteModal.hide();

                            // Show error message
                            var errorHtml = `
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-triangle-fill me-2"></i>${response.data.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            `;
                            $('.im-container').prepend(errorHtml);

                            // Reset button
                            $btn.html(originalHtml);
                            $btn.prop('disabled', false);
                        }
                    },
                    error: function() {
                        // Hide modal
                        var deleteModal = bootstrap.Modal.getInstance(document.getElementById('delete-plan-modal'));
                        deleteModal.hide();

                        // Show error message
                        var errorHtml = `
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo esc_js(__('An error occurred. Please try again.', 'installment-manager')); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        `;
                        $('.im-container').prepend(errorHtml);

                        // Reset button
                        $btn.html(originalHtml);
                        $btn.prop('disabled', false);
                    }
                });
            });
        }

        // Set plan ID and message
        $('#delete-plan-modal').data('plan-id', planId);
        $('.delete-confirm-message').html('<?php echo esc_js(__('Are you sure you want to delete the installment plan for', 'installment-manager')); ?> <strong>' + customerName + '</strong> <?php echo esc_js(__('for product', 'installment-manager')); ?> <strong>' + planName + '</strong>? <?php echo esc_js(__('This action cannot be undone and will delete all associated installments.', 'installment-manager')); ?>');

        // Show modal
        var deleteModal = new bootstrap.Modal(document.getElementById('delete-plan-modal'));
        deleteModal.show();
    });
});
</script>
