<?php
/**
 * Plan details admin view.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Calculate totals
$total_paid = $plan['down_payment'];

foreach ($plan['installments'] as $installment) {
    if ($installment['status'] === 'paid') {
        $total_paid += $installment['amount'];
    }
}

// Calculate remaining amount correctly
$total_remaining = $plan['total_amount'] - $total_paid;

$payment_progress = ($total_paid / $plan['total_amount']) * 100;
?>

<div class="wrap" style="width: 100% !important; max-width: 100% !important; padding: 0 !important; margin: 0 !important;">
    <div class="im-container" style="width: 100% !important; max-width: 100% !important; display: block !important; box-sizing: border-box !important;">
    <div class="im-plan-details">
        <div class="im-plan-header">
            <h1><i class="bi bi-clipboard-data me-2"></i><?php echo esc_html__('Plan Details', 'installment-manager'); ?></h1>
            <div class="im-plan-actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-edit-plan&id=' . $plan['id'])); ?>" class="button">
                    <i class="bi bi-pencil-square"></i>
                    <?php echo esc_html__('Edit Plan', 'installment-manager'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-plans')); ?>" class="button">
                    <i class="bi bi-arrow-left"></i>
                    <?php echo esc_html__('Back to Plans', 'installment-manager'); ?>
                </a>
            </div>
        </div>

        <div class="im-plan-info">
            <div class="im-plan-summary">
                <h2><i class="bi bi-info-circle me-2"></i><?php echo esc_html__('Plan Summary', 'installment-manager'); ?></h2>

                <div class="card mb-4">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold"><?php echo esc_html($plan['product_name']); ?></span>
                            <span class="im-status im-status-<?php echo esc_attr($plan['status']); ?>">
                                <?php
                                $status_labels = [
                                    'active'    => __('Active', 'installment-manager'),
                                    'completed' => __('Completed', 'installment-manager'),
                                    'cancelled' => __('Cancelled', 'installment-manager'),
                                ];
                                echo esc_html($status_labels[$plan['status']] ?? $plan['status']);
                                ?>
                            </span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="im-info-grid">
                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-hash me-1"></i>
                                    <?php echo esc_html__('Plan ID', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value"><?php echo esc_html($plan['id']); ?></div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-person me-1"></i>
                                    <?php echo esc_html__('Customer', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value">
                                    <?php echo esc_html($plan['customer_name']); ?>
                                    <div class="im-info-subtitle"><?php echo esc_html($plan['customer_email']); ?></div>
                                </div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-box me-1"></i>
                                    <?php echo esc_html__('Product', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value">
                                    <?php echo esc_html($plan['product_name']); ?>
                                    <?php if (!empty($plan['product_description'])) : ?>
                                        <div class="im-info-subtitle"><?php echo esc_html(wp_trim_words($plan['product_description'], 10)); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-cash-stack me-1"></i>
                                    <?php echo esc_html__('Total Amount', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value"><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($plan['total_amount'], 2)); ?></div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-cash me-1"></i>
                                    <?php echo esc_html__('Down Payment', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value"><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($plan['down_payment'], 2)); ?></div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-credit-card me-1"></i>
                                    <?php echo esc_html__('Installments', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value">
                                    <?php
                                    echo esc_html(sprintf(
                                        __('%d x %s', 'installment-manager'),
                                        $plan['installment_count'],
                                        Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($plan['installment_amount'], 2)
                                    ));
                                    ?>
                                </div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-calendar-event me-1"></i>
                                    <?php echo esc_html__('Payment Frequency', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value">
                                    <?php
                                    $frequency_labels = [
                                        'weekly'    => __('Weekly', 'installment-manager'),
                                        'biweekly'  => __('Bi-weekly', 'installment-manager'),
                                        'monthly'   => __('Monthly', 'installment-manager'),
                                        'quarterly' => __('Quarterly', 'installment-manager'),
                                    ];
                                    echo esc_html($frequency_labels[$plan['payment_frequency']] ?? $plan['payment_frequency']);
                                    ?>
                                </div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-calendar-check me-1"></i>
                                    <?php echo esc_html__('Start Date', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($plan['start_date']))); ?></div>
                            </div>

                            <div class="im-info-item">
                                <div class="im-info-label">
                                    <i class="bi bi-clock-history me-1"></i>
                                    <?php echo esc_html__('Created', 'installment-manager'); ?>
                                </div>
                                <div class="im-info-value"><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($plan['created_at']))); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if (!empty($plan['notes'])) : ?>
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="bi bi-sticky me-2"></i><?php echo esc_html__('Notes', 'installment-manager'); ?>
                        </div>
                        <div class="card-body">
                            <div class="im-notes-content"><?php echo esc_html($plan['notes']); ?></div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="im-payment-progress">
                <h2><i class="bi bi-graph-up me-2"></i><?php echo esc_html__('Payment Progress', 'installment-manager'); ?></h2>

                <div class="card">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="fw-bold"><?php echo esc_html(number_format($payment_progress, 2) . '%'); ?> <?php echo esc_html__('Complete', 'installment-manager'); ?></span>
                                <span class="text-muted"><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($total_paid, 2)); ?> / <?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($plan['total_amount'], 2)); ?></span>
                            </div>
                            <div class="im-progress-bar">
                                <div class="im-progress-fill" style="width: <?php echo esc_attr($payment_progress); ?>%;"></div>
                            </div>
                        </div>

                        <div class="im-progress-stats">
                            <div class="im-stat">
                                <i class="bi bi-check-circle text-success fs-3 mb-2"></i>
                                <div class="im-stat-label"><?php echo esc_html__('Total Paid', 'installment-manager'); ?></div>
                                <div class="im-stat-value text-success"><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($total_paid, 2)); ?></div>
                            </div>

                            <div class="im-stat">
                                <i class="bi bi-hourglass-split text-danger fs-3 mb-2"></i>
                                <div class="im-stat-label"><?php echo esc_html__('Remaining', 'installment-manager'); ?></div>
                                <div class="im-stat-value text-danger"><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($total_remaining, 2)); ?></div>
                            </div>

                            <div class="im-stat">
                                <i class="bi bi-pie-chart text-primary fs-3 mb-2"></i>
                                <div class="im-stat-label"><?php echo esc_html__('Progress', 'installment-manager'); ?></div>
                                <div class="im-stat-value text-primary"><?php echo esc_html(number_format($payment_progress, 2) . '%'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="im-installments">
            <h2><i class="bi bi-list-check me-2"></i><?php echo esc_html__('Installments', 'installment-manager'); ?></h2>

            <div class="card">
                <div class="card-body">
                    <?php if (empty($plan['installments'])) : ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i><?php echo esc_html__('No installments found.', 'installment-manager'); ?>
                        </div>
                    <?php else : ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo esc_html__('ID', 'installment-manager'); ?></th>
                                        <th><?php echo esc_html__('Due Date', 'installment-manager'); ?></th>
                                        <th><?php echo esc_html__('Amount', 'installment-manager'); ?></th>
                                        <th><?php echo esc_html__('Status', 'installment-manager'); ?></th>
                                        <th><?php echo esc_html__('Payment Date', 'installment-manager'); ?></th>
                                        <th><?php echo esc_html__('Payment Method', 'installment-manager'); ?></th>
                                        <th><?php echo esc_html__('Payment Proof', 'installment-manager'); ?></th>
                                        <th><?php echo esc_html__('Actions', 'installment-manager'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($plan['installments'] as $installment) : ?>
                                        <?php
                                        $is_overdue = $installment['status'] === 'unpaid' && strtotime($installment['due_date']) < time();
                                        $status_class = $is_overdue ? 'late' : $installment['status'];

                                        $payment_method_labels = [
                                            'cash'      => __('Cash', 'installment-manager'),
                                            'visa'      => __('Visa/Mastercard', 'installment-manager'),
                                            'vodafone'  => __('Vodafone Cash', 'installment-manager'),
                                            'etisalat'  => __('Etisalat Cash', 'installment-manager'),
                                            'instapay'  => __('InstaPay', 'installment-manager'),
                                            'bank'      => __('Bank Transfer', 'installment-manager'),
                                            'other'     => __('Other', 'installment-manager'),
                                        ];

                                        $status_labels = [
                                            'unpaid' => __('Unpaid', 'installment-manager'),
                                            'paid'   => __('Paid', 'installment-manager'),
                                            'review' => __('Under Review', 'installment-manager'),
                                            'late'   => __('Late', 'installment-manager'),
                                        ];

                                        $status_label = $is_overdue ? $status_labels['late'] : ($status_labels[$installment['status']] ?? $installment['status']);

                                        // Get status icon
                                        $status_icons = [
                                            'unpaid' => 'bi-exclamation-circle',
                                            'paid'   => 'bi-check-circle',
                                            'review' => 'bi-hourglass-split',
                                            'late'   => 'bi-clock-history',
                                        ];
                                        $status_icon = $is_overdue ? $status_icons['late'] : ($status_icons[$installment['status']] ?? 'bi-circle');
                                        ?>
                                        <tr>
                                            <td><?php echo esc_html($installment['id']); ?></td>
                                            <td>
                                                <i class="bi bi-calendar-date me-1"></i>
                                                <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($installment['due_date']))); ?>
                                            </td>
                                            <td>
                                                <strong><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($installment['amount'], 2)); ?></strong>
                                            </td>
                                            <td>
                                                <span class="im-status im-status-<?php echo esc_attr($status_class); ?>">
                                                    <i class="bi <?php echo esc_attr($status_icon); ?> me-1"></i>
                                                    <?php echo esc_html($status_label); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if (!empty($installment['payment_date'])) : ?>
                                                    <i class="bi bi-calendar-check me-1"></i>
                                                    <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($installment['payment_date']))); ?>
                                                <?php else : ?>
                                                    <span class="text-muted">&mdash;</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!empty($installment['payment_method'])) : ?>
                                                    <?php
                                                    $method_icons = [
                                                        'cash'      => 'bi-cash',
                                                        'visa'      => 'bi-credit-card',
                                                        'vodafone'  => 'bi-phone',
                                                        'etisalat'  => 'bi-phone',
                                                        'instapay'  => 'bi-phone',
                                                        'bank'      => 'bi-bank',
                                                        'other'     => 'bi-wallet2',
                                                    ];
                                                    $method_icon = $method_icons[$installment['payment_method']] ?? 'bi-wallet2';
                                                    ?>
                                                    <i class="bi <?php echo esc_attr($method_icon); ?> me-1"></i>
                                                    <?php echo esc_html($payment_method_labels[$installment['payment_method']] ?? $installment['payment_method']); ?>
                                                <?php else : ?>
                                                    <span class="text-muted">&mdash;</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!empty($installment['payment_proof_id'])) : ?>
                                                    <a href="<?php echo esc_url(wp_get_attachment_url($installment['payment_proof_id'])); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-image me-1"></i><?php echo esc_html__('View Proof', 'installment-manager'); ?>
                                                    </a>
                                                <?php else : ?>
                                                    <span class="text-muted">&mdash;</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($installment['status'] === 'unpaid' || $installment['status'] === 'review') : ?>
                                                    <button class="btn btn-sm btn-success im-mark-as-paid" data-id="<?php echo esc_attr($installment['id']); ?>">
                                                        <i class="bi bi-check-circle me-1"></i><?php echo esc_html__('Mark as Paid', 'installment-manager'); ?>
                                                    </button>
                                                <?php elseif ($installment['status'] === 'paid') : ?>
                                                    <button class="btn btn-sm btn-warning im-mark-as-unpaid" data-id="<?php echo esc_attr($installment['id']); ?>">
                                                        <i class="bi bi-x-circle me-1"></i><?php echo esc_html__('Mark as Unpaid', 'installment-manager'); ?>
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="im-payment-modal" class="im-modal">
    <div class="im-modal-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="m-0"><i class="bi bi-credit-card me-2"></i><?php echo esc_html__('Update Payment Status', 'installment-manager'); ?></h2>
            <span class="im-modal-close"><i class="bi bi-x-lg"></i></span>
        </div>

        <form id="im-payment-form" class="im-form">
            <input type="hidden" id="im-installment-id" name="id" value="0">
            <input type="hidden" id="im-payment-status" name="status" value="paid">

            <div class="im-form-group mb-4">
                <label for="im-payment-method" class="form-label"><?php echo esc_html__('Payment Method', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                <select id="im-payment-method" name="payment_method" class="form-select im-form-control" required>
                    <option value="" disabled selected><?php echo esc_html__('Select payment method...', 'installment-manager'); ?></option>
                    <?php
                    $payment_methods = get_option('im_payment_methods', array(
                        'cash' => __('Cash', 'installment-manager'),
                        'visa' => __('Visa/Mastercard', 'installment-manager'),
                        'vodafone' => __('Vodafone Cash', 'installment-manager'),
                        'etisalat' => __('Etisalat Cash', 'installment-manager'),
                        'instapay' => __('InstaPay', 'installment-manager'),
                        'bank' => __('Bank Transfer', 'installment-manager'),
                        'other' => __('Other', 'installment-manager'),
                    ));

                    foreach ($payment_methods as $code => $name) :
                    ?>
                        <option value="<?php echo esc_attr($code); ?>"><?php echo esc_html($name); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="im-form-group mb-4">
                <label for="im-payment-proof" class="form-label"><?php echo esc_html__('Payment Proof', 'installment-manager'); ?></label>
                <div class="im-media-uploader">
                    <input type="hidden" id="im-payment-proof-id" name="payment_proof_id" value="0">
                    <button type="button" id="im-upload-proof" class="btn btn-outline-primary">
                        <i class="bi bi-upload me-2"></i><?php echo esc_html__('Upload Image', 'installment-manager'); ?>
                    </button>
                    <div id="im-proof-preview" class="im-proof-preview mt-3 p-2 border rounded text-center" style="display: none;"></div>
                </div>
            </div>

            <div class="im-form-group mb-4">
                <label for="im-payment-notes" class="form-label"><?php echo esc_html__('Notes', 'installment-manager'); ?></label>
                <textarea id="im-payment-notes" name="notes" class="form-control im-form-control" rows="3" placeholder="<?php echo esc_attr(esc_html__('Enter any additional notes about this payment...', 'installment-manager')); ?>"></textarea>
            </div>

            <div class="im-form-actions">
                <button type="submit" class="btn btn-primary im-btn-primary">
                    <i class="bi bi-check-circle me-2"></i><?php echo esc_html__('Save Payment', 'installment-manager'); ?>
                </button>
                <button type="button" class="btn btn-secondary im-btn-secondary im-modal-cancel">
                    <i class="bi bi-x-circle me-2"></i><?php echo esc_html__('Cancel', 'installment-manager'); ?>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Mark as paid
    $('.im-mark-as-paid').on('click', function() {
        var installmentId = $(this).data('id');

        $('#im-installment-id').val(installmentId);
        $('#im-payment-status').val('paid');
        $('#im-payment-method').val('');
        $('#im-payment-proof-id').val(0);
        $('#im-proof-preview').empty();
        $('#im-payment-notes').val('');

        $('#im-payment-modal').show();
    });

    // Mark as unpaid
    $('.im-mark-as-unpaid').on('click', function() {
        var installmentId = $(this).data('id');

        if (confirm(imAdminData.strings.confirmMarkAsUnpaid)) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'im_update_installment_status',
                    id: installmentId,
                    status: 'unpaid',
                    nonce: imAdminData.nonce
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data.message);
                    }
                }
            });
        }
    });

    // Close modal
    $('.im-modal-close, .im-modal-cancel').on('click', function() {
        $('#im-payment-modal').hide();
    });

    // Upload proof
    $('#im-upload-proof').on('click', function(e) {
        e.preventDefault();

        var mediaUploader = wp.media({
            title: imAdminData.strings.uploadProof,
            button: {
                text: imAdminData.strings.selectImage
            },
            multiple: false,
            library: {
                type: 'image'
            },
            // For admin users, we don't need to restrict to their own uploads
            <?php if (!current_user_can('manage_installment_plans')) : ?>
            states: [
                new wp.media.controller.Library({
                    library: wp.media.query({
                        type: 'image',
                        author: <?php echo get_current_user_id(); ?>
                    }),
                    multiple: false,
                    priority: 20,
                    filterable: 'uploaded'
                })
            ]
            <?php endif; ?>
        });

        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            $('#im-payment-proof-id').val(attachment.id);

            var previewHtml = '<img src="' + attachment.url + '" alt="Payment Proof">';
            $('#im-proof-preview').html(previewHtml);
        });

        mediaUploader.open();
    });

    // Save payment
    $('#im-payment-form').on('submit', function(e) {
        e.preventDefault();

        var formData = $(this).serializeArray();
        formData.push({name: 'action', value: 'im_update_installment_status'});
        formData.push({name: 'nonce', value: imAdminData.nonce});

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message);
                }
            }
        });
    });
});
</script>
    </div>
