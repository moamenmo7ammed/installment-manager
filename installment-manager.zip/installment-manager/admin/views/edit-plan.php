<?php
/**
 * Edit plan admin view.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}
?>

<div class="wrap">
    <div class="im-container">
        <div class="im-header mb-4">
            <h2>
                <i class="bi bi-<?php echo $plan ? 'pencil-square' : 'plus-circle'; ?> me-2"></i>
                <?php echo $plan ? esc_html__('Edit Installment Plan', 'installment-manager') : esc_html__('Add New Installment Plan', 'installment-manager'); ?>
            </h2>
        </div>

        <!-- Error Alert Container -->
        <div id="im-alert-container"></div>

        <!-- Plan Form Card -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="bi bi-file-earmark-text me-2"></i>
                    <?php echo esc_html__('Plan Details', 'installment-manager'); ?>
                </h5>
            </div>
            <div class="card-body">
                <form id="im-plan-form" class="needs-validation" novalidate>
                    <input type="hidden" id="im-plan-id" name="id" value="<?php echo $plan ? esc_attr($plan['id']) : '0'; ?>">

                    <!-- Customer & Product Information -->
                    <div class="mb-4">
                        <h5 class="border-bottom pb-2 mb-3">
                            <i class="bi bi-person-badge me-2"></i>
                            <?php echo esc_html__('Customer & Product Information', 'installment-manager'); ?>
                        </h5>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-customer" class="form-label">
                                        <?php echo esc_html__('Customer', 'installment-manager'); ?>
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select id="im-customer" name="customer_id" class="form-select" required>
                                        <?php if ($plan) : ?>
                                            <option value="<?php echo esc_attr($plan['customer_id']); ?>" selected>
                                                <?php echo esc_html($plan['customer_name'] . ' (' . $plan['customer_email'] . ')'); ?>
                                            </option>
                                        <?php endif; ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        <?php echo esc_html__('Please select a customer.', 'installment-manager'); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-product" class="form-label">
                                        <?php echo esc_html__('Product', 'installment-manager'); ?>
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select id="im-product" name="product_id" class="form-select" required>
                                        <?php if ($plan) : ?>
                                            <option value="<?php echo esc_attr($plan['product_id']); ?>" selected>
                                                <?php
                                                $currency_symbol = function_exists('Installment_Manager_Helper_Functions::get_currency_symbol') ?
                                                    Installment_Manager_Helper_Functions::get_currency_symbol() : '$';
                                                echo esc_html($plan['product_name'] . ' (' . $currency_symbol . number_format($plan['total_amount'], 2) . ')');
                                                ?>
                                            </option>
                                        <?php elseif (!empty($products)) : ?>
                                            <option value="" disabled selected><?php echo esc_html__('Select a product...', 'installment-manager'); ?></option>
                                            <?php foreach ($products as $product) : ?>
                                                <?php
                                                $total_price = $product['base_price'];
                                                if ($product['profit_option'] === 'fixed') {
                                                    $total_price += $product['profit_value'];
                                                } else {
                                                    $total_price += $product['base_price'] * $product['profit_value'] / 100;
                                                }
                                                ?>
                                                <option value="<?php echo esc_attr($product['id']); ?>"
                                                        data-price="<?php echo esc_attr($total_price); ?>"
                                                        data-base-price="<?php echo esc_attr($product['base_price']); ?>"
                                                        data-profit-option="<?php echo esc_attr($product['profit_option']); ?>"
                                                        data-profit-value="<?php echo esc_attr($product['profit_value']); ?>">
                                                    <?php
                                                    $currency_symbol = function_exists('Installment_Manager_Helper_Functions::get_currency_symbol') ?
                                                        Installment_Manager_Helper_Functions::get_currency_symbol() : '$';
                                                    echo esc_html($product['name'] . ' (' . $currency_symbol . number_format($total_price, 2) . ')');
                                                    ?>
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        <?php echo esc_html__('Please select a product.', 'installment-manager'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Details -->
                    <div class="mb-4">
                        <h5 class="border-bottom pb-2 mb-3">
                            <i class="bi bi-cash-stack me-2"></i>
                            <?php echo esc_html__('Payment Details', 'installment-manager'); ?>
                        </h5>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-total-amount" class="form-label">
                                        <?php echo esc_html__('Total Amount', 'installment-manager'); ?>
                                        <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text"><?php
                                            $currency_symbol = function_exists('Installment_Manager_Helper_Functions::get_currency_symbol') ?
                                                Installment_Manager_Helper_Functions::get_currency_symbol() : '$';
                                            echo esc_html($currency_symbol);
                                        ?></span>
                                        <input type="number" class="form-control" id="im-total-amount" name="total_amount" step="0.01" min="0" required value="<?php echo $plan ? esc_attr($plan['total_amount']) : ''; ?>">
                                        <div class="invalid-feedback">
                                            <?php echo esc_html__('Please enter a valid total amount.', 'installment-manager'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-down-payment" class="form-label">
                                        <?php echo esc_html__('Down Payment', 'installment-manager'); ?>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text"><?php
                                            $currency_symbol = function_exists('Installment_Manager_Helper_Functions::get_currency_symbol') ?
                                                Installment_Manager_Helper_Functions::get_currency_symbol() : '$';
                                            echo esc_html($currency_symbol);
                                        ?></span>
                                        <input type="number" class="form-control" id="im-down-payment" name="down_payment" step="0.01" min="0" value="<?php echo $plan ? esc_attr($plan['down_payment']) : '0'; ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-installment-count" class="form-label">
                                        <?php echo esc_html__('Number of Installments', 'installment-manager'); ?>
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input type="number" class="form-control" id="im-installment-count" name="installment_count" min="1" required value="<?php echo $plan ? esc_attr($plan['installment_count']) : '1'; ?>">
                                    <div class="invalid-feedback">
                                        <?php echo esc_html__('Please enter a valid number of installments.', 'installment-manager'); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-installment-amount" class="form-label">
                                        <?php echo esc_html__('Installment Amount', 'installment-manager'); ?>
                                        <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text"><?php
                                            $currency_symbol = function_exists('Installment_Manager_Helper_Functions::get_currency_symbol') ?
                                                Installment_Manager_Helper_Functions::get_currency_symbol() : '$';
                                            echo esc_html($currency_symbol);
                                        ?></span>
                                        <input type="number" class="form-control" id="im-installment-amount" name="installment_amount" step="0.01" min="0" required value="<?php echo $plan ? esc_attr($plan['installment_amount']) : ''; ?>">
                                        <div class="invalid-feedback">
                                            <?php echo esc_html__('Please enter a valid installment amount.', 'installment-manager'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-payment-frequency" class="form-label">
                                        <?php echo esc_html__('Payment Frequency', 'installment-manager'); ?>
                                    </label>
                                    <select class="form-select" id="im-payment-frequency" name="payment_frequency">
                                        <option value="weekly" <?php echo ($plan && $plan['payment_frequency'] === 'weekly') ? 'selected' : ''; ?>><?php echo esc_html__('Weekly', 'installment-manager'); ?></option>
                                        <option value="biweekly" <?php echo ($plan && $plan['payment_frequency'] === 'biweekly') ? 'selected' : ''; ?>><?php echo esc_html__('Bi-weekly', 'installment-manager'); ?></option>
                                        <option value="monthly" <?php echo (!$plan || $plan['payment_frequency'] === 'monthly') ? 'selected' : ''; ?>><?php echo esc_html__('Monthly', 'installment-manager'); ?></option>
                                        <option value="quarterly" <?php echo ($plan && $plan['payment_frequency'] === 'quarterly') ? 'selected' : ''; ?>><?php echo esc_html__('Quarterly', 'installment-manager'); ?></option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-start-date" class="form-label">
                                        <?php echo esc_html__('Start Date', 'installment-manager'); ?>
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input type="date" class="form-control" id="im-start-date" name="start_date" required pattern="\d{4}-\d{2}-\d{2}" value="<?php echo $plan ? esc_attr($plan['start_date']) : date('Y-m-d'); ?>">
                                    <div class="invalid-feedback">
                                        <?php echo esc_html__('Please select a valid start date in YYYY-MM-DD format.', 'installment-manager'); ?>
                                    </div>
                                    <small class="form-text text-muted"><?php echo esc_html__('Date format: YYYY-MM-DD', 'installment-manager'); ?></small>
                                </div>
                            </div>

                            <?php if ($plan) : ?>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="im-status" class="form-label">
                                        <?php echo esc_html__('Status', 'installment-manager'); ?>
                                    </label>
                                    <select class="form-select" id="im-status" name="status">
                                        <option value="active" <?php echo ($plan['status'] === 'active') ? 'selected' : ''; ?>><?php echo esc_html__('Active', 'installment-manager'); ?></option>
                                        <option value="completed" <?php echo ($plan['status'] === 'completed') ? 'selected' : ''; ?>><?php echo esc_html__('Completed', 'installment-manager'); ?></option>
                                        <option value="cancelled" <?php echo ($plan['status'] === 'cancelled') ? 'selected' : ''; ?>><?php echo esc_html__('Cancelled', 'installment-manager'); ?></option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-12">
                                <div class="mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="im-recreate-installments" name="recreate_installments" value="1">
                                        <label class="form-check-label" for="im-recreate-installments">
                                            <?php echo esc_html__('Recreate all installments based on the new settings', 'installment-manager'); ?>
                                        </label>
                                    </div>
                                    <div class="form-text text-danger">
                                        <i class="bi bi-exclamation-triangle me-1"></i>
                                        <?php echo esc_html__('Warning: This will delete all existing installments and create new ones. Any payment history will be lost.', 'installment-manager'); ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Additional Information -->
                    <div class="mb-4">
                        <h5 class="border-bottom pb-2 mb-3">
                            <i class="bi bi-info-circle me-2"></i>
                            <?php echo esc_html__('Additional Information', 'installment-manager'); ?>
                        </h5>

                        <div class="row">
                            <div class="col-12">
                                <div class="mb-3">
                                    <label for="im-notes" class="form-label">
                                        <?php echo esc_html__('Notes', 'installment-manager'); ?>
                                    </label>
                                    <textarea class="form-control" id="im-notes" name="notes" rows="3"><?php echo $plan ? esc_textarea($plan['notes']) : ''; ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="d-flex justify-content-end mt-4">
                        <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-plans')); ?>" class="btn btn-secondary me-2">
                            <i class="bi bi-x-circle me-2"></i><?php echo esc_html__('Cancel', 'installment-manager'); ?>
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i><?php echo esc_html__('Save Plan', 'installment-manager'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Bootstrap form validation
    (function() {
        'use strict';

        // Fetch all forms we want to apply validation to
        var forms = document.querySelectorAll('.needs-validation');

        // Loop over them and prevent submission
        Array.prototype.slice.call(forms).forEach(function(form) {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    })();

    // Load all WordPress users directly
    $.ajax({
        url: ajaxurl,
        type: 'GET',
        dataType: 'json',
        data: {
            action: 'im_search_customers',
            nonce: imAdminData.nonce,
            load_all: true
        },
        success: function(response) {
            if (response && response.results) {
                // Clear existing options
                $('#im-customer').empty();

                // Add placeholder option
                $('#im-customer').append('<option value="" disabled selected>' + imAdminData.strings.selectCustomer + '</option>');

                // Add all users
                $.each(response.results, function(i, user) {
                    $('#im-customer').append('<option value="' + user.id + '">' + user.text + '</option>');
                });

                // Initialize Select2
                $('#im-customer').select2({
                    placeholder: imAdminData.strings.selectCustomer,
                    allowClear: true,
                    width: '100%',
                    dropdownParent: $('#im-customer').parent()
                });

                // Set selected value if editing
                <?php if ($plan) : ?>
                $('#im-customer').val('<?php echo esc_js($plan['customer_id']); ?>').trigger('change');
                <?php endif; ?>
            } else {
                showAlert('danger', 'Failed to load customers. Please refresh the page and try again.');
                console.error('Failed to load customers');
            }
        },
        error: function() {
            showAlert('danger', 'Failed to load customers. Please refresh the page and try again.');
            console.error('AJAX error when loading customers');
        }
    });

    // Load all products directly
    $.ajax({
        url: ajaxurl,
        type: 'GET',
        dataType: 'json',
        data: {
            action: 'im_search_products',
            nonce: imAdminData.nonce,
            load_all: true
        },
        success: function(response) {
            if (response && response.results) {
                // Clear existing options except the first one if editing
                if (!$('#im-product').val()) {
                    $('#im-product').empty();

                    // Add placeholder option
                    $('#im-product').append('<option value="" disabled selected>' + imAdminData.strings.selectProduct + '</option>');
                }

                // Add all products
                $.each(response.results, function(i, product) {
                    $('#im-product').append('<option value="' + product.id + '" ' +
                        'data-price="' + product.price + '" ' +
                        'data-base-price="' + product.base_price + '" ' +
                        'data-profit-option="' + product.profit_option + '" ' +
                        'data-profit-value="' + product.profit_value + '">' +
                        product.text + '</option>');
                });

                // Initialize Select2
                $('#im-product').select2({
                    placeholder: imAdminData.strings.selectProduct,
                    allowClear: true,
                    width: '100%',
                    dropdownParent: $('#im-product').parent()
                });

                // Set selected value if editing
                <?php if ($plan) : ?>
                $('#im-product').val('<?php echo esc_js($plan['product_id']); ?>').trigger('change');
                <?php endif; ?>
            } else {
                showAlert('danger', 'Failed to load products. Please refresh the page and try again.');
                console.error('Failed to load products');
            }
        },
        error: function() {
            showAlert('danger', 'Failed to load products. Please refresh the page and try again.');
            console.error('AJAX error when loading products');
        }
    });

    // Update total amount when product changes
    $('#im-product').on('change', function() {
        var selectedOption = $(this).find('option:selected');
        var price = selectedOption.data('price');

        if (price) {
            $('#im-total-amount').val(price);
            calculateInstallmentAmount();
        }
    });

    // Calculate installment amount
    function calculateInstallmentAmount() {
        var totalAmount = parseFloat($('#im-total-amount').val()) || 0;
        var downPayment = parseFloat($('#im-down-payment').val()) || 0;
        var installmentCount = parseInt($('#im-installment-count').val()) || 1;

        if (installmentCount < 1) {
            installmentCount = 1;
            $('#im-installment-count').val(1);
        }

        var amountToPay = totalAmount - downPayment;

        // Ensure amount to pay is not negative
        if (amountToPay < 0) {
            amountToPay = 0;
            $('#im-down-payment').val(totalAmount);
        }

        var installmentAmount = amountToPay / installmentCount;

        $('#im-installment-amount').val(installmentAmount.toFixed(2));
    }

    // Recalculate when values change
    $('#im-total-amount, #im-down-payment, #im-installment-count').on('change', function() {
        calculateInstallmentAmount();
    });

    // Helper function to show alerts
    function showAlert(type, message) {
        var icon = type === 'success' ? 'check-circle-fill' : 'exclamation-triangle-fill';
        var alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                <i class="bi bi-${icon} me-2"></i>${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        $('#im-alert-container').html(alertHtml);

        // Scroll to alert
        $('html, body').animate({
            scrollTop: $('#im-alert-container').offset().top - 100
        }, 500);
    }

    // Save plan
    $('#im-plan-form').on('submit', function(e) {
        e.preventDefault();

        // Check form validity
        if (!this.checkValidity()) {
            return;
        }

        // Validate required fields manually
        var customer = $('#im-customer').val();
        var product = $('#im-product').val();
        var totalAmount = parseFloat($('#im-total-amount').val()) || 0;
        var installmentCount = parseInt($('#im-installment-count').val()) || 0;
        var installmentAmount = parseFloat($('#im-installment-amount').val()) || 0;
        var startDate = $('#im-start-date').val();

        var errors = [];

        if (!customer) {
            errors.push('Customer is required.');
        }

        if (!product) {
            errors.push('Product is required.');
        }

        if (totalAmount <= 0) {
            errors.push('Total amount must be greater than zero.');
        }

        if (installmentCount < 1) {
            errors.push('Number of installments must be at least 1.');
        }

        if (installmentAmount <= 0) {
            errors.push('Installment amount must be greater than zero.');
        }

        // Validate start date format
        if (!startDate) {
            errors.push('Start date is required.');
        } else {
            // Check if date is in YYYY-MM-DD format
            var dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!dateRegex.test(startDate)) {
                errors.push('Start date must be in YYYY-MM-DD format.');
            }
        }

        // Display validation errors if any
        if (errors.length > 0) {
            var errorMessage = '<ul><li>' + errors.join('</li><li>') + '</li></ul>';
            showAlert('danger', 'Please fix the following errors:' + errorMessage);
            return;
        }

        // Show loading state
        var submitBtn = $(this).find('button[type="submit"]');
        var originalHtml = submitBtn.html();
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + originalHtml);

        // Clear previous alerts
        $('#im-alert-container').empty();

        var formData = $(this).serializeArray();
        formData.push({name: 'action', value: 'im_save_plan'});
        formData.push({name: 'nonce', value: imAdminData.nonce});

        // Log form data for debugging
        console.log('Submitting plan data:', formData);

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            success: function(response) {
                console.log('Server response:', response);

                if (response.success) {
                    // Show success message before redirect
                    showAlert('success', response.data.message);

                    // Redirect after a short delay
                    setTimeout(function() {
                        window.location.href = response.data.redirect;
                    }, 1000);
                } else {
                    // Display error message
                    var errorMsg = response.data && response.data.message ? response.data.message : 'An unknown error occurred.';
                    showAlert('danger', errorMsg);
                    console.error('Error from server:', response);

                    // Reset button
                    submitBtn.prop('disabled', false).html(originalHtml);
                }
            },
            error: function(xhr, status, error) {
                // Try to parse error response
                var errorMessage = 'An error occurred while saving the plan. Please try again.';
                console.error('AJAX Error - Status:', status);
                console.error('AJAX Error - Error:', error);
                console.error('AJAX Error - Response Text:', xhr.responseText);

                // Check for database error in the response text
                var dbErrorMatch = xhr.responseText.match(/WordPress database error.*?\[(.*?)\]/);
                if (dbErrorMatch && dbErrorMatch[1]) {
                    errorMessage = 'Database error: ' + dbErrorMatch[1];
                    console.error('Database error detected:', dbErrorMatch[1]);
                }

                // Try to parse JSON part of the response
                try {
                    // Extract JSON part from the response if it contains HTML
                    var jsonText = xhr.responseText;
                    var jsonStartPos = jsonText.indexOf('{');
                    if (jsonStartPos > 0) {
                        jsonText = jsonText.substring(jsonStartPos);
                    }

                    var response = JSON.parse(jsonText);
                    console.log('Parsed error response:', response);
                    if (response && response.data && response.data.message) {
                        // Only use the JSON error message if we didn't find a more specific database error
                        if (!dbErrorMatch) {
                            errorMessage = response.data.message;
                        }
                    }
                } catch (e) {
                    console.error('Error parsing response:', e);
                }

                // Display error message
                showAlert('danger', errorMessage);

                // Reset button
                submitBtn.prop('disabled', false).html(originalHtml);

                // Suggest troubleshooting steps
                var troubleshootingHtml = `
                    <div class="alert alert-info mt-3">
                        <h5><i class="bi bi-info-circle me-2"></i>Troubleshooting Tips:</h5>
                        <ul>
                            <li>Check that all required fields are filled correctly</li>
                            <li>Ensure the start date is in a valid format (YYYY-MM-DD)</li>
                            <li>Try refreshing the page and submitting again</li>
                            <li>Check the browser console for more detailed error information</li>
                        </ul>
                    </div>
                `;
                $('#im-alert-container').append(troubleshootingHtml);
            }
        });
    });
});
</script>
