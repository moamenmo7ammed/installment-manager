<?php
/**
 * Settings admin view.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get settings
$currency = get_option('im_currency', 'USD');

// Get payment methods
$payment_methods = get_option('im_payment_methods', array(
    'cash' => __('Cash', 'installment-manager'),
    'visa' => __('Visa/Mastercard', 'installment-manager'),
    'vodafone' => __('Vodafone Cash', 'installment-manager'),
    'etisalat' => __('Etisalat Cash', 'installment-manager'),
    'instapay' => __('InstaPay', 'installment-manager'),
    'bank' => __('Bank Transfer', 'installment-manager'),
    'other' => __('Other', 'installment-manager'),
));

// Get currencies
$currencies = get_option('im_currencies', array(
    'USD' => array('name' => __('US Dollar', 'installment-manager'), 'symbol' => '$'),
    'EUR' => array('name' => __('Euro', 'installment-manager'), 'symbol' => '€'),
    'GBP' => array('name' => __('British Pound', 'installment-manager'), 'symbol' => '£'),
    'EGP' => array('name' => __('Egyptian Pound', 'installment-manager'), 'symbol' => 'E£'),
    'SAR' => array('name' => __('Saudi Riyal', 'installment-manager'), 'symbol' => 'SR'),
    'AED' => array('name' => __('UAE Dirham', 'installment-manager'), 'symbol' => 'د.إ'),
));
?>

<div class="wrap">
    <div class="im-container">
        <div class="im-header">
            <h2><i class="bi bi-gear-fill me-2"></i><?php echo esc_html__('Installment Manager Settings', 'installment-manager'); ?></h2>
        </div>

        <form method="post" action="options.php" class="im-settings-form">
            <?php settings_fields('installment_manager_settings'); ?>
            <?php do_settings_sections('installment_manager_settings'); ?>

            <!-- Shortcode Section -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0"><i class="bi bi-code-square me-2"></i><?php echo esc_html__('Frontend Shortcode', 'installment-manager'); ?></h5>
                        </div>
                        <div class="card-body">
                            <p><?php echo esc_html__('Use this shortcode to display the customer portal on any page or post:', 'installment-manager'); ?></p>
                            <div class="input-group mb-3">
                                <input type="text" id="im-shortcode" class="form-control" value="[installment_customer_portal]" readonly>
                                <button class="btn btn-outline-primary" type="button" id="im-copy-shortcode">
                                    <i class="bi bi-clipboard me-1"></i><?php echo esc_html__('Copy', 'installment-manager'); ?>
                                </button>
                            </div>
                            <div class="form-text"><?php echo esc_html__('This shortcode will display the customer portal where users can view and manage their installment plans.', 'installment-manager'); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Currency Settings -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="bi bi-currency-exchange me-2"></i><?php echo esc_html__('Currency Settings', 'installment-manager'); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="im_currency" class="form-label"><?php echo esc_html__('Currency', 'installment-manager'); ?></label>
                                <select name="im_currency" id="im_currency" class="form-select">
                                    <?php foreach ($currencies as $code => $currency_data) : ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($currency, $code); ?>>
                                            <?php echo esc_html($currency_data['name'] . ' (' . $currency_data['symbol'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text"><?php echo esc_html__('Select the currency to use for all transactions.', 'installment-manager'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="bi bi-info-circle-fill me-2"></i><?php echo esc_html__('Help & Information', 'installment-manager'); ?></h5>
                        </div>
                        <div class="card-body">
                            <p><?php echo esc_html__('These settings affect how prices and amounts are displayed throughout the plugin.', 'installment-manager'); ?></p>
                            <p><?php echo esc_html__('After changing the currency, all new plans will use the selected currency. Existing plans will not be affected.', 'installment-manager'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Currency Management -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="bi bi-cash-coin me-2"></i><?php echo esc_html__('Currency Management', 'installment-manager'); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive mb-3">
                                <table class="table table-bordered table-hover" id="im-currencies-table">
                                    <thead class="table-light">
                                        <tr>
                                            <th><?php echo esc_html__('Code', 'installment-manager'); ?></th>
                                            <th><?php echo esc_html__('Name', 'installment-manager'); ?></th>
                                            <th><?php echo esc_html__('Symbol', 'installment-manager'); ?></th>
                                            <th class="text-end"><?php echo esc_html__('Actions', 'installment-manager'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($currencies as $code => $currency_data) : ?>
                                            <tr data-code="<?php echo esc_attr($code); ?>">
                                                <td><?php echo esc_html($code); ?></td>
                                                <td><?php echo esc_html($currency_data['name']); ?></td>
                                                <td><?php echo esc_html($currency_data['symbol']); ?></td>
                                                <td class="text-end">
                                                    <button type="button" class="btn btn-sm btn-outline-primary im-edit-currency">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-outline-danger im-delete-currency">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <button type="button" class="btn btn-success" id="im-add-currency">
                                <i class="bi bi-plus-circle me-1"></i><?php echo esc_html__('Add New Currency', 'installment-manager'); ?>
                            </button>
                            <input type="hidden" name="im_currencies" id="im_currencies" value='<?php echo esc_attr(json_encode($currencies)); ?>'>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Methods -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="bi bi-credit-card me-2"></i><?php echo esc_html__('Payment Methods', 'installment-manager'); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive mb-3">
                                <table class="table table-bordered table-hover" id="im-payment-methods-table">
                                    <thead class="table-light">
                                        <tr>
                                            <th><?php echo esc_html__('Code', 'installment-manager'); ?></th>
                                            <th><?php echo esc_html__('Name', 'installment-manager'); ?></th>
                                            <th class="text-end"><?php echo esc_html__('Actions', 'installment-manager'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($payment_methods as $code => $name) : ?>
                                            <tr data-code="<?php echo esc_attr($code); ?>">
                                                <td><?php echo esc_html($code); ?></td>
                                                <td><?php echo esc_html($name); ?></td>
                                                <td class="text-end">
                                                    <button type="button" class="btn btn-sm btn-outline-primary im-edit-payment-method">
                                                        <i class="bi bi-pencil-square"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-outline-danger im-delete-payment-method">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <button type="button" class="btn btn-success" id="im-add-payment-method">
                                <i class="bi bi-plus-circle me-1"></i><?php echo esc_html__('Add New Payment Method', 'installment-manager'); ?>
                            </button>
                            <input type="hidden" name="im_payment_methods" id="im_payment_methods" value='<?php echo esc_attr(json_encode($payment_methods)); ?>'>
                        </div>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="bi bi-save me-2"></i><?php echo esc_html__('Save Settings', 'installment-manager'); ?>
            </button>
        </form>
    </div>
</div>

<!-- Currency Modal -->
<div class="modal fade" id="im-currency-modal" tabindex="-1" aria-labelledby="im-currency-modal-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="im-currency-modal-label"><?php echo esc_html__('Add/Edit Currency', 'installment-manager'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo esc_attr(esc_html__('Close', 'installment-manager')); ?>"></button>
            </div>
            <div class="modal-body">
                <form id="im-currency-form">
                    <input type="hidden" id="im-currency-action" value="add">
                    <input type="hidden" id="im-currency-original-code" value="">

                    <div class="mb-3">
                        <label for="im-currency-code" class="form-label"><?php echo esc_html__('Currency Code', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="im-currency-code" required maxlength="3" placeholder="<?php echo esc_attr(esc_html__('e.g. USD', 'installment-manager')); ?>">
                        <div class="form-text"><?php echo esc_html__('3-letter ISO currency code (e.g. USD, EUR, GBP)', 'installment-manager'); ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="im-currency-name" class="form-label"><?php echo esc_html__('Currency Name', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="im-currency-name" required placeholder="<?php echo esc_attr(esc_html__('e.g. US Dollar', 'installment-manager')); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="im-currency-symbol" class="form-label"><?php echo esc_html__('Currency Symbol', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="im-currency-symbol" required placeholder="<?php echo esc_attr(esc_html__('e.g. $', 'installment-manager')); ?>">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo esc_html__('Cancel', 'installment-manager'); ?></button>
                <button type="button" class="btn btn-primary" id="im-save-currency"><?php echo esc_html__('Save', 'installment-manager'); ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Payment Method Modal -->
<div class="modal fade" id="im-payment-method-modal" tabindex="-1" aria-labelledby="im-payment-method-modal-label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="im-payment-method-modal-label"><?php echo esc_html__('Add/Edit Payment Method', 'installment-manager'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo esc_attr(esc_html__('Close', 'installment-manager')); ?>"></button>
            </div>
            <div class="modal-body">
                <form id="im-payment-method-form">
                    <input type="hidden" id="im-payment-method-action" value="add">
                    <input type="hidden" id="im-payment-method-original-code" value="">

                    <div class="mb-3">
                        <label for="im-payment-method-code" class="form-label"><?php echo esc_html__('Payment Method Code', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="im-payment-method-code" required placeholder="<?php echo esc_attr(esc_html__('e.g. visa', 'installment-manager')); ?>">
                        <div class="form-text"><?php echo esc_html__('Unique code for the payment method (lowercase, no spaces)', 'installment-manager'); ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="im-payment-method-name" class="form-label"><?php echo esc_html__('Payment Method Name', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="im-payment-method-name" required placeholder="<?php echo esc_attr(esc_html__('e.g. Visa/Mastercard', 'installment-manager')); ?>">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo esc_html__('Cancel', 'installment-manager'); ?></button>
                <button type="button" class="btn btn-primary" id="im-save-payment-method"><?php echo esc_html__('Save', 'installment-manager'); ?></button>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Copy shortcode functionality
    $('#im-copy-shortcode').on('click', function() {
        var shortcodeInput = document.getElementById('im-shortcode');
        shortcodeInput.select();
        document.execCommand('copy');

        // Change button text temporarily
        var $btn = $(this);
        var originalHtml = $btn.html();
        $btn.html('<i class="bi bi-check-circle me-1"></i><?php echo esc_js(__('Copied!', 'installment-manager')); ?>');

        setTimeout(function() {
            $btn.html(originalHtml);
        }, 2000);
    });

    // Initialize Bootstrap modals
    var currencyModal = new bootstrap.Modal(document.getElementById('im-currency-modal'));
    var paymentMethodModal = new bootstrap.Modal(document.getElementById('im-payment-method-modal'));

    // Currency Management
    $('#im-add-currency').on('click', function() {
        $('#im-currency-action').val('add');
        $('#im-currency-original-code').val('');
        $('#im-currency-code').val('').prop('disabled', false);
        $('#im-currency-name').val('');
        $('#im-currency-symbol').val('');
        $('#im-currency-modal-label').text('<?php echo esc_js(__('Add New Currency', 'installment-manager')); ?>');
        currencyModal.show();
    });

    $('.im-edit-currency').on('click', function() {
        var $row = $(this).closest('tr');
        var code = $row.data('code');
        var currencies = {};

        try {
            currencies = JSON.parse($('#im_currencies').val());
        } catch (e) {
            console.error('Error parsing currencies JSON:', e);
            alert('<?php echo esc_js(__('Error loading currency data. Please refresh the page and try again.', 'installment-manager')); ?>');
            return;
        }

        $('#im-currency-action').val('edit');
        $('#im-currency-original-code').val(code);
        $('#im-currency-code').val(code).prop('disabled', true);
        $('#im-currency-name').val(currencies[code].name);
        $('#im-currency-symbol').val(currencies[code].symbol);
        $('#im-currency-modal-label').text('<?php echo esc_js(__('Edit Currency', 'installment-manager')); ?>');
        currencyModal.show();
    });

    $('.im-delete-currency').on('click', function() {
        if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this currency?', 'installment-manager')); ?>')) {
            return;
        }

        var $row = $(this).closest('tr');
        var code = $row.data('code');
        var currencies = {};

        try {
            currencies = JSON.parse($('#im_currencies').val());
        } catch (e) {
            console.error('Error parsing currencies JSON:', e);
            alert('<?php echo esc_js(__('Error loading currency data. Please refresh the page and try again.', 'installment-manager')); ?>');
            return;
        }

        // Check if this is the currently selected currency
        if ($('#im_currency').val() === code) {
            alert('<?php echo esc_js(__('You cannot delete the currently selected currency. Please select a different currency first.', 'installment-manager')); ?>');
            return;
        }

        // Remove from currencies object
        delete currencies[code];

        // Update hidden input
        $('#im_currencies').val(JSON.stringify(currencies));

        // Remove row from table
        $row.remove();
    });

    $('#im-save-currency').on('click', function() {
        // Form validation
        var form = document.getElementById('im-currency-form');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        var action = $('#im-currency-action').val();
        var originalCode = $('#im-currency-original-code').val();
        var code = $('#im-currency-code').val().toUpperCase();
        var name = $('#im-currency-name').val();
        var symbol = $('#im-currency-symbol').val();
        var currencies = {};

        try {
            currencies = JSON.parse($('#im_currencies').val());
        } catch (e) {
            console.error('Error parsing currencies JSON:', e);
            alert('<?php echo esc_js(__('Error loading currency data. Please refresh the page and try again.', 'installment-manager')); ?>');
            return;
        }

        // Validate code format
        if (!/^[A-Z]{3}$/.test(code)) {
            alert('<?php echo esc_js(__('Currency code must be exactly 3 uppercase letters.', 'installment-manager')); ?>');
            return;
        }

        // Check for duplicate code
        if (action === 'add' && currencies[code]) {
            alert('<?php echo esc_js(__('A currency with this code already exists.', 'installment-manager')); ?>');
            return;
        }

        // Update currencies object
        if (action === 'edit' && originalCode !== code) {
            delete currencies[originalCode];
        }

        currencies[code] = {
            name: name,
            symbol: symbol
        };

        // Update hidden input
        $('#im_currencies').val(JSON.stringify(currencies));

        // Update table
        if (action === 'add') {
            var newRow = '<tr data-code="' + code + '">' +
                '<td>' + code + '</td>' +
                '<td>' + name + '</td>' +
                '<td>' + symbol + '</td>' +
                '<td class="text-end">' +
                '<button type="button" class="btn btn-sm btn-outline-primary im-edit-currency"><i class="bi bi-pencil-square"></i></button> ' +
                '<button type="button" class="btn btn-sm btn-outline-danger im-delete-currency"><i class="bi bi-trash"></i></button>' +
                '</td>' +
                '</tr>';
            $('#im-currencies-table tbody').append(newRow);
        } else {
            var $row = $('tr[data-code="' + originalCode + '"]');
            $row.attr('data-code', code);
            $row.find('td:eq(0)').text(code);
            $row.find('td:eq(1)').text(name);
            $row.find('td:eq(2)').text(symbol);
        }

        // Update currency dropdown
        var $currencySelect = $('#im_currency');
        var currentValue = $currencySelect.val();

        // If editing the currently selected currency, update the value
        if (action === 'edit' && originalCode === currentValue) {
            currentValue = code;
        }

        $currencySelect.empty();
        $.each(currencies, function(currencyCode, currencyData) {
            var option = new Option(currencyData.name + ' (' + currencyData.symbol + ')', currencyCode);
            $currencySelect.append(option);
        });

        $currencySelect.val(currentValue);

        // Close modal
        currencyModal.hide();

        // Reattach event handlers
        $('.im-edit-currency').off('click').on('click', function() {
            var $row = $(this).closest('tr');
            var code = $row.data('code');
            var currencies = {};

            try {
                currencies = JSON.parse($('#im_currencies').val());
            } catch (e) {
                console.error('Error parsing currencies JSON:', e);
                alert('<?php echo esc_js(__('Error loading currency data. Please refresh the page and try again.', 'installment-manager')); ?>');
                return;
            }

            $('#im-currency-action').val('edit');
            $('#im-currency-original-code').val(code);
            $('#im-currency-code').val(code).prop('disabled', true);
            $('#im-currency-name').val(currencies[code].name);
            $('#im-currency-symbol').val(currencies[code].symbol);
            $('#im-currency-modal-label').text('<?php echo esc_js(__('Edit Currency', 'installment-manager')); ?>');
            currencyModal.show();
        });

        $('.im-delete-currency').off('click').on('click', function() {
            if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this currency?', 'installment-manager')); ?>')) {
                return;
            }

            var $row = $(this).closest('tr');
            var code = $row.data('code');
            var currencies = {};

            try {
                currencies = JSON.parse($('#im_currencies').val());
            } catch (e) {
                console.error('Error parsing currencies JSON:', e);
                alert('<?php echo esc_js(__('Error loading currency data. Please refresh the page and try again.', 'installment-manager')); ?>');
                return;
            }

            // Check if this is the currently selected currency
            if ($('#im_currency').val() === code) {
                alert('<?php echo esc_js(__('You cannot delete the currently selected currency. Please select a different currency first.', 'installment-manager')); ?>');
                return;
            }

            // Remove from currencies object
            delete currencies[code];

            // Update hidden input
            $('#im_currencies').val(JSON.stringify(currencies));

            // Remove row from table
            $row.remove();
        });
    });

    // Payment Method Management
    $('#im-add-payment-method').on('click', function() {
        $('#im-payment-method-action').val('add');
        $('#im-payment-method-original-code').val('');
        $('#im-payment-method-code').val('').prop('disabled', false);
        $('#im-payment-method-name').val('');
        $('#im-payment-method-modal-label').text('<?php echo esc_js(__('Add New Payment Method', 'installment-manager')); ?>');
        paymentMethodModal.show();
    });

    $('.im-edit-payment-method').on('click', function() {
        var $row = $(this).closest('tr');
        var code = $row.data('code');
        var paymentMethods = {};

        try {
            paymentMethods = JSON.parse($('#im_payment_methods').val());
        } catch (e) {
            console.error('Error parsing payment methods JSON:', e);
            alert('<?php echo esc_js(__('Error loading payment method data. Please refresh the page and try again.', 'installment-manager')); ?>');
            return;
        }

        $('#im-payment-method-action').val('edit');
        $('#im-payment-method-original-code').val(code);
        $('#im-payment-method-code').val(code).prop('disabled', true);
        $('#im-payment-method-name').val(paymentMethods[code]);
        $('#im-payment-method-modal-label').text('<?php echo esc_js(__('Edit Payment Method', 'installment-manager')); ?>');
        paymentMethodModal.show();
    });

    $('.im-delete-payment-method').on('click', function() {
        if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this payment method?', 'installment-manager')); ?>')) {
            return;
        }

        var $row = $(this).closest('tr');
        var code = $row.data('code');
        var paymentMethods = {};

        try {
            paymentMethods = JSON.parse($('#im_payment_methods').val());
        } catch (e) {
            console.error('Error parsing payment methods JSON:', e);
            alert('<?php echo esc_js(__('Error loading payment method data. Please refresh the page and try again.', 'installment-manager')); ?>');
            return;
        }

        // Remove from payment methods object
        delete paymentMethods[code];

        // Update hidden input
        $('#im_payment_methods').val(JSON.stringify(paymentMethods));

        // Remove row from table
        $row.remove();
    });

    $('#im-save-payment-method').on('click', function() {
        // Form validation
        var form = document.getElementById('im-payment-method-form');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        var action = $('#im-payment-method-action').val();
        var originalCode = $('#im-payment-method-original-code').val();
        var code = $('#im-payment-method-code').val().toLowerCase();
        var name = $('#im-payment-method-name').val();
        var paymentMethods = {};

        try {
            paymentMethods = JSON.parse($('#im_payment_methods').val());
        } catch (e) {
            console.error('Error parsing payment methods JSON:', e);
            alert('<?php echo esc_js(__('Error loading payment method data. Please refresh the page and try again.', 'installment-manager')); ?>');
            return;
        }

        // Validate code format
        if (!/^[a-z0-9_-]+$/.test(code)) {
            alert('<?php echo esc_js(__('Payment method code must contain only lowercase letters, numbers, underscores, and hyphens.', 'installment-manager')); ?>');
            return;
        }

        // Check for duplicate code
        if (action === 'add' && paymentMethods[code]) {
            alert('<?php echo esc_js(__('A payment method with this code already exists.', 'installment-manager')); ?>');
            return;
        }

        // Update payment methods object
        if (action === 'edit' && originalCode !== code) {
            delete paymentMethods[originalCode];
        }

        paymentMethods[code] = name;

        // Update hidden input
        $('#im_payment_methods').val(JSON.stringify(paymentMethods));

        // Update table
        if (action === 'add') {
            var newRow = '<tr data-code="' + code + '">' +
                '<td>' + code + '</td>' +
                '<td>' + name + '</td>' +
                '<td class="text-end">' +
                '<button type="button" class="btn btn-sm btn-outline-primary im-edit-payment-method"><i class="bi bi-pencil-square"></i></button> ' +
                '<button type="button" class="btn btn-sm btn-outline-danger im-delete-payment-method"><i class="bi bi-trash"></i></button>' +
                '</td>' +
                '</tr>';
            $('#im-payment-methods-table tbody').append(newRow);
        } else {
            var $row = $('tr[data-code="' + originalCode + '"]');
            $row.attr('data-code', code);
            $row.find('td:eq(0)').text(code);
            $row.find('td:eq(1)').text(name);
        }

        // Close modal
        paymentMethodModal.hide();

        // Reattach event handlers
        $('.im-edit-payment-method').off('click').on('click', function() {
            var $row = $(this).closest('tr');
            var code = $row.data('code');
            var paymentMethods = {};

            try {
                paymentMethods = JSON.parse($('#im_payment_methods').val());
            } catch (e) {
                console.error('Error parsing payment methods JSON:', e);
                alert('<?php echo esc_js(__('Error loading payment method data. Please refresh the page and try again.', 'installment-manager')); ?>');
                return;
            }

            $('#im-payment-method-action').val('edit');
            $('#im-payment-method-original-code').val(code);
            $('#im-payment-method-code').val(code).prop('disabled', true);
            $('#im-payment-method-name').val(paymentMethods[code]);
            $('#im-payment-method-modal-label').text('<?php echo esc_js(__('Edit Payment Method', 'installment-manager')); ?>');
            paymentMethodModal.show();
        });

        $('.im-delete-payment-method').off('click').on('click', function() {
            if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this payment method?', 'installment-manager')); ?>')) {
                return;
            }

            var $row = $(this).closest('tr');
            var code = $row.data('code');
            var paymentMethods = {};

            try {
                paymentMethods = JSON.parse($('#im_payment_methods').val());
            } catch (e) {
                console.error('Error parsing payment methods JSON:', e);
                alert('<?php echo esc_js(__('Error loading payment method data. Please refresh the page and try again.', 'installment-manager')); ?>');
                return;
            }

            // Remove from payment methods object
            delete paymentMethods[code];

            // Update hidden input
            $('#im_payment_methods').val(JSON.stringify(paymentMethods));

            // Remove row from table
            $row.remove();
        });
    });
});
</script>
