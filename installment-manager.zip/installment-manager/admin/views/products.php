<?php
/**
 * Products admin view.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}
?>

<div class="wrap" style="width: 100% !important; max-width: 100% !important; padding: 0 !important; margin: 0 !important;">
    <div class="im-container" style="width: 100% !important; max-width: 100% !important; display: block !important; box-sizing: border-box !important;">
        <div class="im-header mb-4 d-flex justify-content-between align-items-center">
            <h2><i class="bi bi-box-seam me-2"></i><?php echo esc_html__('Products', 'installment-manager'); ?></h2>
            <button id="im-add-product" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i><?php echo esc_html__('Add New Product', 'installment-manager'); ?>
            </button>
        </div>

        <!-- Product Form Card -->
        <div id="im-product-form-container" class="card shadow-sm mb-4" style="display: none !important;">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0" id="im-product-form-title"><i class="bi bi-plus-circle me-2"></i><?php echo esc_html__('Add New Product', 'installment-manager'); ?></h5>
            </div>
            <div class="card-body">
                <form id="im-product-form" class="needs-validation" novalidate>
                    <input type="hidden" id="im-product-id" name="id" value="0">

                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="im-product-name" class="form-label"><?php echo esc_html__('Product Name', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="im-product-name" name="name" required>
                                <div class="invalid-feedback">
                                    <?php echo esc_html__('Please enter a product name.', 'installment-manager'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="im-product-base-price" class="form-label"><?php echo esc_html__('Base Price', 'installment-manager'); ?> <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol()); ?></span>
                                    <input type="number" class="form-control" id="im-product-base-price" name="base_price" step="0.01" min="0" required>
                                    <div class="invalid-feedback">
                                        <?php echo esc_html__('Please enter a valid base price.', 'installment-manager'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="im-product-profit-option" class="form-label"><?php echo esc_html__('Profit Option', 'installment-manager'); ?></label>
                                <select class="form-select" id="im-product-profit-option" name="profit_option">
                                    <option value="fixed"><?php echo esc_html__('Fixed Amount', 'installment-manager'); ?></option>
                                    <option value="percentage"><?php echo esc_html__('Percentage', 'installment-manager'); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="im-product-profit-value" class="form-label"><?php echo esc_html__('Profit Value', 'installment-manager'); ?></label>
                                <div class="input-group">
                                    <span class="input-group-text profit-symbol"><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol()); ?></span>
                                    <input type="number" class="form-control" id="im-product-profit-value" name="profit_value" step="0.01" min="0">
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="mb-3">
                                <label for="im-product-description" class="form-label"><?php echo esc_html__('Description', 'installment-manager'); ?></label>
                                <textarea class="form-control" id="im-product-description" name="description" rows="3"></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4 d-flex justify-content-end">
                        <button type="button" id="im-cancel-product" class="btn btn-secondary me-2">
                            <i class="bi bi-x-circle me-2"></i><?php echo esc_html__('Cancel', 'installment-manager'); ?>
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-2"></i><?php echo esc_html__('Save Product', 'installment-manager'); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Products List Card -->
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-list-ul me-2"></i><?php echo esc_html__('Product List', 'installment-manager'); ?></h5>
            </div>
            <div class="card-body">
                <?php if (empty($products)) : ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i><?php echo esc_html__('No products found.', 'installment-manager'); ?>
                    </div>
                <?php else : ?>
                    <div class="table-responsive" style="width: 100% !important; overflow-x: auto !important;">
                        <table class="table table-striped table-hover" style="width: 100% !important; table-layout: auto !important; min-width: 100% !important;">
                            <thead class="table-light">
                                <tr>
                                    <th><?php echo esc_html__('ID', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Name', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Base Price', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Profit', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Total Price', 'installment-manager'); ?></th>
                                    <th class="text-end"><?php echo esc_html__('Actions', 'installment-manager'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($products as $product) : ?>
                                    <?php
                                    $total_price = $product['base_price'];
                                    if ($product['profit_option'] === 'fixed') {
                                        $total_price += $product['profit_value'];
                                        $profit_display = Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($product['profit_value'], 2);
                                    } else {
                                        $total_price += ($product['base_price'] * $product['profit_value'] / 100);
                                        $profit_display = number_format($product['profit_value'], 2) . '%';
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html($product['id']); ?></td>
                                        <td>
                                            <strong><?php echo esc_html($product['name']); ?></strong>
                                            <?php if (!empty($product['description'])) : ?>
                                                <div class="small text-muted mt-1">
                                                    <?php echo esc_html(wp_trim_words($product['description'], 10)); ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($product['base_price'], 2)); ?></td>
                                        <td><?php echo esc_html($profit_display); ?></td>
                                        <td><?php echo esc_html(Installment_Manager_Helper_Functions::get_currency_symbol() . number_format($total_price, 2)); ?></td>
                                        <td class="text-end">
                                            <button class="btn btn-sm btn-primary im-edit-product" data-id="<?php echo esc_attr($product['id']); ?>">
                                                <i class="bi bi-pencil-square me-1"></i><?php echo esc_html__('Edit', 'installment-manager'); ?>
                                            </button>
                                            <button class="btn btn-sm btn-danger im-delete-product" data-id="<?php echo esc_attr($product['id']); ?>">
                                                <i class="bi bi-trash me-1"></i><?php echo esc_html__('Delete', 'installment-manager'); ?>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Ensure product form is hidden on page load
    $('#im-product-form-container').hide().css('display', 'none !important');

    // Also hide it after a short delay to catch any delayed rendering
    setTimeout(function() {
        $('#im-product-form-container').hide().css('display', 'none !important');
    }, 100);
    // Update profit symbol based on profit option
    function updateProfitSymbol() {
        var profitOption = $('#im-product-profit-option').val();
        if (profitOption === 'percentage') {
            $('.profit-symbol').text('%');
        } else {
            $('.profit-symbol').text('<?php echo esc_js(Installment_Manager_Helper_Functions::get_currency_symbol()); ?>');
        }
    }

    // Initialize profit symbol
    updateProfitSymbol();

    // Update profit symbol when profit option changes
    $('#im-product-profit-option').on('change', updateProfitSymbol);

    // Add new product
    $('#im-add-product').on('click', function() {
        $('#im-product-form-title').html('<i class="bi bi-plus-circle me-2"></i><?php echo esc_js(__('Add New Product', 'installment-manager')); ?>');
        $('#im-product-id').val(0);
        $('#im-product-name').val('');
        $('#im-product-description').val('');
        $('#im-product-base-price').val('');
        $('#im-product-profit-option').val('fixed');
        $('#im-product-profit-value').val('');
        updateProfitSymbol();

        // Reset form validation
        $('#im-product-form').removeClass('was-validated');

        // Show form with animation
        $('#im-product-form-container').css('display', '').fadeIn(300);

        // Scroll to form
        $('html, body').animate({
            scrollTop: $('#im-product-form-container').offset().top - 50
        }, 500);
    });

    // Cancel product form
    $('#im-cancel-product').on('click', function() {
        $('#im-product-form-container').fadeOut(300, function() {
            // After fadeout, ensure it's hidden with !important
            $(this).hide().css('display', 'none !important');

            // Reset form to prevent it from showing on page reload
            $('#im-product-id').val(0);
            $('#im-product-name').val('');
            $('#im-product-description').val('');
            $('#im-product-base-price').val('');
            $('#im-product-profit-option').val('fixed');
            $('#im-product-profit-value').val('');
            $('#im-product-form').removeClass('was-validated');
        });
    });

    // Edit product
    $('.im-edit-product').on('click', function() {
        var productId = $(this).data('id');
        var row = $(this).closest('tr');

        $('#im-product-form-title').html('<i class="bi bi-pencil-square me-2"></i><?php echo esc_js(__('Edit Product', 'installment-manager')); ?>');
        $('#im-product-id').val(productId);
        $('#im-product-name').val(row.find('td:nth-child(2) strong').text());

        // Get description from data attribute or from preview
        var description = row.find('td:nth-child(2) .small').text() || '';
        $('#im-product-description').val($.trim(description));

        // Parse base price
        var basePrice = row.find('td:nth-child(3)').text().replace(/[^0-9.]/g, '');
        $('#im-product-base-price').val(basePrice);

        // Parse profit option and value
        var profitText = row.find('td:nth-child(4)').text();
        if (profitText.indexOf('%') > -1) {
            $('#im-product-profit-option').val('percentage');
            $('#im-product-profit-value').val(profitText.replace(/[^0-9.]/g, ''));
        } else {
            $('#im-product-profit-option').val('fixed');
            $('#im-product-profit-value').val(profitText.replace(/[^0-9.]/g, ''));
        }

        // Update profit symbol
        updateProfitSymbol();

        // Reset form validation
        $('#im-product-form').removeClass('was-validated');

        // Show form with animation
        $('#im-product-form-container').css('display', '').fadeIn(300);

        // Scroll to form
        $('html, body').animate({
            scrollTop: $('#im-product-form-container').offset().top - 50
        }, 500);
    });

    // Delete product - use Bootstrap modal instead of confirm
    $('.im-delete-product').on('click', function() {
        var productId = $(this).data('id');
        var productName = $(this).closest('tr').find('td:nth-child(2) strong').text();

        // Create modal if it doesn't exist
        if ($('#delete-product-modal').length === 0) {
            var modalHtml = `
                <div class="modal fade" id="delete-product-modal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title"><i class="bi bi-exclamation-triangle me-2"></i>${imAdminData.strings.confirmDelete}</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="delete-confirm-message"></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    <i class="bi bi-x-circle me-2"></i><?php echo esc_js(__('Cancel', 'installment-manager')); ?>
                                </button>
                                <button type="button" class="btn btn-danger" id="confirm-delete-product">
                                    <i class="bi bi-trash me-2"></i><?php echo esc_js(__('Delete', 'installment-manager')); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            $('body').append(modalHtml);

            // Handle delete confirmation
            $('#confirm-delete-product').on('click', function() {
                var deleteId = $('#delete-product-modal').data('product-id');

                // Show loading state
                var $btn = $(this);
                var originalHtml = $btn.html();
                $btn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + originalHtml);
                $btn.prop('disabled', true);

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'im_delete_product',
                        id: deleteId,
                        nonce: imAdminData.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            // Hide modal
                            var deleteModal = bootstrap.Modal.getInstance(document.getElementById('delete-product-modal'));
                            deleteModal.hide();

                            // Show error message
                            var errorHtml = `
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-triangle-fill me-2"></i>${response.data.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            `;
                            $('.im-container').prepend(errorHtml);

                            // Reset button
                            $btn.html(originalHtml);
                            $btn.prop('disabled', false);
                        }
                    },
                    error: function() {
                        // Hide modal
                        var deleteModal = bootstrap.Modal.getInstance(document.getElementById('delete-product-modal'));
                        deleteModal.hide();

                        // Show error message
                        var errorHtml = `
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo esc_js(__('An error occurred. Please try again.', 'installment-manager')); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        `;
                        $('.im-container').prepend(errorHtml);

                        // Reset button
                        $btn.html(originalHtml);
                        $btn.prop('disabled', false);
                    }
                });
            });
        }

        // Set product ID and message
        $('#delete-product-modal').data('product-id', productId);
        $('.delete-confirm-message').text('<?php echo esc_js(__('Are you sure you want to delete the product', 'installment-manager')); ?> "' + productName + '"? <?php echo esc_js(__('This action cannot be undone.', 'installment-manager')); ?>');

        // Show modal
        var deleteModal = new bootstrap.Modal(document.getElementById('delete-product-modal'));
        deleteModal.show();
    });

    // Save product with form validation
    $('#im-product-form').on('submit', function(e) {
        e.preventDefault();

        // Check form validity
        if (!this.checkValidity()) {
            e.stopPropagation();
            $(this).addClass('was-validated');
            return;
        }

        // Show loading state
        var $btn = $(this).find('button[type="submit"]');
        var originalHtml = $btn.html();
        $btn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ' + originalHtml);
        $btn.prop('disabled', true);

        var formData = $(this).serializeArray();
        formData.push({name: 'action', value: 'im_save_product'});
        formData.push({name: 'nonce', value: imAdminData.nonce});

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    // Show error message
                    var errorHtml = `
                        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>${response.data.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    `;
                    $('#im-product-form').prepend(errorHtml);

                    // Reset button
                    $btn.html(originalHtml);
                    $btn.prop('disabled', false);

                    // Scroll to error
                    $('html, body').animate({
                        scrollTop: $('#im-product-form').offset().top - 50
                    }, 500);
                }
            },
            error: function() {
                // Show error message
                var errorHtml = `
                    <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i><?php echo esc_js(__('An error occurred. Please try again.', 'installment-manager')); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `;
                $('#im-product-form').prepend(errorHtml);

                // Reset button
                $btn.html(originalHtml);
                $btn.prop('disabled', false);

                // Scroll to error
                $('html, body').animate({
                    scrollTop: $('#im-product-form').offset().top - 50
                }, 500);
            }
        });
    });
});
</script>
