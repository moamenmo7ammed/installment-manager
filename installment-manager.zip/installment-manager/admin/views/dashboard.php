<?php
/**
 * Dashboard admin view.
 *
 * @since      1.0.0
 * @package    Installment_Manager
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}
?>

<div class="wrap">
    <div class="im-container">
        <div class="im-header mb-4">
            <h2><i class="bi bi-speedometer2 me-2"></i><?php echo esc_html__('Installment Manager Dashboard', 'installment-manager'); ?></h2>
        </div>

        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-4 col-lg-2">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <div class="display-5 text-primary mb-2">
                            <i class="bi bi-file-earmark-text"></i>
                        </div>
                        <h5 class="card-title"><?php echo esc_html__('Active Plans', 'installment-manager'); ?></h5>
                        <h3 class="card-text fw-bold" id="im-active-plans"><?php echo esc_html($stats['active_plans']); ?></h3>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-2">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <div class="display-5 text-success mb-2">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                        <h5 class="card-title"><?php echo esc_html__('Total Amount', 'installment-manager'); ?></h5>
                        <h3 class="card-text fw-bold" id="im-total-amount">
                            <?php
                            // Get currency symbol from helper function
                            $currency_symbol = function_exists('get_option') ? Installment_Manager_Helper_Functions::get_currency_symbol() : '$';
                            echo esc_html($currency_symbol . number_format($stats['total_amount'], 2));
                            ?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-2">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <div class="display-5 text-info mb-2">
                            <i class="bi bi-check-circle"></i>
                        </div>
                        <h5 class="card-title"><?php echo esc_html__('Paid Amount', 'installment-manager'); ?></h5>
                        <h3 class="card-text fw-bold" id="im-paid-amount">
                            <?php
                            echo esc_html($currency_symbol . number_format($stats['paid_amount'], 2));
                            ?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-2">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <div class="display-5 text-warning mb-2">
                            <i class="bi bi-hourglass-split"></i>
                        </div>
                        <h5 class="card-title"><?php echo esc_html__('Due Amount', 'installment-manager'); ?></h5>
                        <h3 class="card-text fw-bold" id="im-due-amount">
                            <?php
                            echo esc_html($currency_symbol . number_format($stats['due_amount'], 2));
                            ?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-2">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <div class="display-5 text-primary mb-2">
                            <i class="bi bi-calendar-event"></i>
                        </div>
                        <h5 class="card-title"><?php echo esc_html__('Upcoming', 'installment-manager'); ?></h5>
                        <h3 class="card-text fw-bold" id="im-upcoming-installments"><?php echo esc_html($stats['upcoming_installments']); ?></h3>
                        <small class="text-muted"><?php echo esc_html__('Next 30 days', 'installment-manager'); ?></small>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-lg-2">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <div class="display-5 text-danger mb-2">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                        <h5 class="card-title"><?php echo esc_html__('Overdue', 'installment-manager'); ?></h5>
                        <h3 class="card-text fw-bold" id="im-overdue-installments"><?php echo esc_html($stats['overdue_installments']); ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-4">
            <!-- Charts -->
            <div class="col-lg-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="bi bi-pie-chart-fill me-2"></i><?php echo esc_html__('Payment Progress', 'installment-manager'); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="im-chart-container" style="height: 300px;">
                            <canvas id="im-payment-chart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="col-lg-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="bi bi-graph-up me-2"></i><?php echo esc_html__('Payment Overview', 'installment-manager'); ?></h5>
                    </div>
                    <div class="card-body">
                        <div id="payment-overview-chart" style="height: 300px;"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Plans -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-list-ul me-2"></i><?php echo esc_html__('Recent Plans', 'installment-manager'); ?></h5>
                <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-plans')); ?>" class="btn btn-sm btn-light">
                    <i class="bi bi-eye me-1"></i><?php echo esc_html__('View All', 'installment-manager'); ?>
                </a>
            </div>
            <div class="card-body">
                <?php if (empty($recent_plans)) : ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i><?php echo esc_html__('No plans found.', 'installment-manager'); ?>
                    </div>
                <?php else : ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th><?php echo esc_html__('ID', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Customer', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Product', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Total Amount', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Start Date', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Status', 'installment-manager'); ?></th>
                                    <th><?php echo esc_html__('Actions', 'installment-manager'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_plans as $plan) : ?>
                                    <tr>
                                        <td><?php echo esc_html($plan['id']); ?></td>
                                        <td><?php echo esc_html($plan['customer_name']); ?></td>
                                        <td><?php echo esc_html($plan['product_name']); ?></td>
                                        <td><?php
                                            echo esc_html($currency_symbol . number_format($plan['total_amount'], 2));
                                        ?></td>
                                        <td><?php
                                            // Format date safely
                                            if (function_exists('date_i18n') && function_exists('get_option')) {
                                                echo esc_html(date_i18n(get_option('date_format'), strtotime($plan['start_date'])));
                                            } else {
                                                echo esc_html(date('Y-m-d', strtotime($plan['start_date'])));
                                            }
                                        ?></td>
                                        <td>
                                            <?php
                                            $status_labels = [
                                                'active'    => __('Active', 'installment-manager'),
                                                'completed' => __('Completed', 'installment-manager'),
                                                'cancelled' => __('Cancelled', 'installment-manager'),
                                            ];
                                            $status_classes = [
                                                'active'    => 'primary',
                                                'completed' => 'success',
                                                'cancelled' => 'danger',
                                            ];
                                            $status_class = isset($status_classes[$plan['status']]) ? $status_classes[$plan['status']] : 'secondary';
                                            $status_label = isset($status_labels[$plan['status']]) ? $status_labels[$plan['status']] : $plan['status'];
                                            ?>
                                            <span class="badge bg-<?php echo esc_attr($status_class); ?>">
                                                <?php echo esc_html($status_label); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=installment-manager-plan-details&id=' . $plan['id'])); ?>" class="btn btn-sm btn-primary">
                                                <i class="bi bi-eye me-1"></i><?php echo esc_html__('View', 'installment-manager'); ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Refresh stats every 60 seconds
    setInterval(function() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'im_get_dashboard_stats',
                nonce: imAdminData.nonce
            },
            success: function(response) {
                if (response.success) {
                    var stats = response.data;

                    $('#im-active-plans').text(stats.active_plans);
                    $('#im-total-amount').text(imAdminData.currency + Number(stats.total_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    $('#im-paid-amount').text(imAdminData.currency + Number(stats.paid_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    $('#im-due-amount').text(imAdminData.currency + Number(stats.due_amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                    $('#im-upcoming-installments').text(stats.upcoming_installments);
                    $('#im-overdue-installments').text(stats.overdue_installments);

                    // Update charts
                    if (window.paymentChart) {
                        window.paymentChart.data.datasets[0].data = [stats.paid_amount, stats.total_amount - stats.paid_amount];
                        window.paymentChart.update();
                    }

                    // Update payment overview chart
                    updatePaymentOverviewChart(stats);
                }
            }
        });
    }, 60000);

    // Initialize payment progress chart
    var ctx = document.getElementById('im-payment-chart').getContext('2d');
    window.paymentChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [
                '<?php echo esc_js(__('Paid', 'installment-manager')); ?>',
                '<?php echo esc_js(__('Remaining', 'installment-manager')); ?>'
            ],
            datasets: [{
                data: [
                    <?php echo esc_js($stats['paid_amount']); ?>,
                    <?php echo esc_js($stats['total_amount'] - $stats['paid_amount']); ?>
                ],
                backgroundColor: [
                    '#4CAF50',
                    '#F44336'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                title: {
                    display: true,
                    text: '<?php echo esc_js(__('Payment Progress', 'installment-manager')); ?>'
                }
            },
            cutout: '70%'
        }
    });

    // Initialize payment overview chart using QuickChart
    function updatePaymentOverviewChart(stats) {
        // Create the chart configuration
        var chartConfig = {
            type: 'bar',
            data: {
                labels: ['<?php echo esc_js(__('Total', 'installment-manager')); ?>', '<?php echo esc_js(__('Paid', 'installment-manager')); ?>', '<?php echo esc_js(__('Due', 'installment-manager')); ?>'],
                datasets: [{
                    label: '<?php echo esc_js(__('Amount', 'installment-manager')); ?>',
                    data: [
                        stats.total_amount || <?php echo esc_js($stats['total_amount']); ?>,
                        stats.paid_amount || <?php echo esc_js($stats['paid_amount']); ?>,
                        stats.due_amount || <?php echo esc_js($stats['due_amount']); ?>
                    ],
                    backgroundColor: ['#4361ee', '#4CAF50', '#F44336']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '<?php echo esc_js(Installment_Manager_Helper_Functions::get_currency_symbol()); ?>' + value;
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '<?php echo esc_js(Installment_Manager_Helper_Functions::get_currency_symbol()); ?>' + context.raw.toFixed(2);
                            }
                        }
                    }
                }
            }
        };

        // Convert the configuration to a JSON string
        var chartConfigStr = JSON.stringify(chartConfig);

        // Create the QuickChart URL
        var quickChartUrl = 'https://quickchart.io/chart?c=' + encodeURIComponent(chartConfigStr) + '&w=500&h=300';

        // Update the chart container with the image
        $('#payment-overview-chart').html('<img src="' + quickChartUrl + '" class="img-fluid" alt="Payment Overview Chart">');
    }

    // Initial call to create the payment overview chart
    updatePaymentOverviewChart(<?php echo json_encode($stats); ?>);
});
</script>
